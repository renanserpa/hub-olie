# Olie Atlas Network – Atlas Geral de Camadas & Documentos (v2)

> Este arquivo é o **mapa-mestre** das camadas, agentes, stack e docs
> do ecossistema que estamos desenhando (Agents Hub + OlieHub + futuros projetos).  
> Ele não substitui os `.md` individuais – apenas **indexa e organiza** tudo.

---

## 0. Núcleo Conceitual do Atlas & do Agents Hub

### 0.1. Visão Geral do Agents Hub

- **`agents-hub-overview.md`**  
  Descreve o que é o **Agents Hub** (meta-sistema), como ele organiza:
  - ideias → projetos → sistemas/produtos → agentes → melhorias,
  - relação com o OlieHub como primeiro grande caso de uso,
  - fluxo IDEIA → PROJETO → SISTEMA → AGENTES → IDEIAS (ciclo contínuo).

### 0.2. Núcleo de Agentes & Governança

- **`agents-core-and-catalysts.md`**  
  Define o **núcleo de agentes** do Atlas:
  - GOD Ideas Agent (visão suprema),
  - Master Catalyst (catalisador de ideias & design),
  - Architect & Orchestrator (Arquiteto de Agentes),
  - núcleo de agentes técnicos (Systems Architect, CodeAssistantAI, EngenheiroDeDados, IntegratorAI, AuditorDeSistema etc.),
  - hierarquia GOD → Catalyst → Architect → Camadas de agentes especializados,
  - processo padrão para **criar novos agentes** (`agents/<nome>.md`).

### 0.3. Mapa de Camadas de Agentes

- **`agents-map-overview.md`**  
  Mapa visual/textual de todas as **camadas de agentes**:
  - Cognitiva,
  - Técnica,
  - Criativa Visual,
  - Audiovisual & Story,
  - Musical & Áudio,
  - Educação & Conhecimento,
  - Games & Gamificação,
  - Marketing & Análise,
  - UX & Experiência,
  - Multimodal / Experimental.

### 0.4. Índice de Camadas de Agentes por Domínio

- **`agents-domain-layers-index.md`**  
  Índice rápido que diz:
  - para cada **tipo de trabalho** (técnico, visual, story, música, educação, games, marketing, UX, multimodal),
  - **qual arquivo de camada** usar (ex.: `agents-technical-architecture-layer.md` para stack/código),
  - e quando ativar cada família de agentes.

### 0.5. Modelo Conceitual do Agents Hub

- **`agents-hub-data-model-conceptual.md`**  
  Modelo de dados conceitual do Hub:
  - `ideas`, `projects`, `systems`, `agents`, `layers`, `artifacts`,
  - relações entre ideias, projetos, agentes e documentos de arquitetura/execução,
  - visão de futuro para salvar histórico, decisões e backlogs.

### 0.6. Documentos de Cultura & Processo

- **`ecosystem-glossary.md`** – Glossário de termos (projetos, agentes, camadas, stack).  
- **`knowledge-architecture.md`** – Como o conhecimento é organizado (docs, pastas, links).  
- **`project-lifecycle.md`** – Ciclo de vida de um projeto (ideia → discovery → design → build → evolução).  
- **`playbooks-new-project.md`** – Passo a passo para iniciar um novo projeto dentro do Atlas.  
- **`prompt-kits.md`** – Kits de prompts prontos para Catalyst, Code Assistant, DB Agent etc.  
- **`interaction-guidelines.md`** – Como o GPT/agents devem conversar com o usuário (tom, limites, perguntas).  
- **`naming-conventions.md`** – Convenções de nomes para arquivos, agentes, tabelas, branches etc.  
- **`stack-links.md`** – Links de documentação oficial (Supabase, Vercel, Gemini, OpenAI, etc.).

---

## 1. Camadas de Agentes (por Domínio)

Estas camadas descrevem **famílias de agentes** focados em domínios específicos.

### 1.1. Camada Cognitiva – Ideia & Direção

- **`agents-cognitive-layer.md`**  
  Responde **“o que faz sentido construir, para quem, e por quê?”**  
  Agentes principais (exemplos):

  - CatalisadorDeIdeias  
  - ArquitetoSupremo  
  - AtlasAI (Router)  
  - PersonaAI  
  - StrategyAI  
  - VisionAI  
  - PromptArchitectAI  

### 1.2. Camada de Arquitetura Técnica

- **`agents-technical-architecture-layer.md`**  
  Traduz visão em **solução técnica** (stack, módulos, banco, APIs).  
  Agentes principais (exemplos):

  - AI Systems Architect Generator / Systems Architect / ArchitectAI  
  - EngenheiroDeDados / DataEngineerAI  
  - IntegratorAI  
  - WebAppDevAI  
  - AuditorDeSistema  
  - EspecialistaRLS_RBAC  
  - CodeAssistantAI  
  - APIConnectorAI  
  - TestAutomationAI  
  - DeployManagerAI  

### 1.3. Camada Criativa Visual

- **`agents-creative-visual-layer.md`**  
  Identidade visual, UI, mockups, 3D e texturas.  
  Agentes principais (exemplos):

  - VisualDesignerAI  
  - UXBuilderAI (lado visual)  
  - TextileAI / PatternAI  
  - 3DDesignerAI / 3DModelAI  
  - SceneComposerAI  
  - ProductMockupAI  
  - StyleTransferAI  

### 1.4. Camada Audiovisual / Story Crew

- **`agents-audiovisual-story-layer.md`**  
  Narração, roteiro, direção visual, vídeo, som e emoção.  
  Agentes principais (exemplos):

  - NarradorAI / NarratorAI  
  - DialogueCoachAI  
  - WorldBuilderAI  
  - CharacterDesignerAI  
  - VisualDirectorAI / DirectorAI  
  - ScriptWriterAI / StoryWriterAI  
  - VideoCreatorAI  
  - SoundDirectorAI  
  - EmotionArchitectAI  
  - CinematicComposerAI  

### 1.5. Camada Musical & Áudio

- **`agents-musical-audio-layer.md`**  
  Música, trilhas, batidas, voz e mix/master.  
  Agentes principais (exemplos):

  - MusicProducerAI  
  - SoundComposerAI / ComposerAI  
  - BeatMakerAI  
  - VocalSynthAI / VoiceAI / VoiceCloneAI  
  - MixMasterAI  
  - LyricistAI  

### 1.6. Camada de Conhecimento & Educação

- **`agents-learning-layer.md`**  
  Ensinar, resumir, transformar docs em trilhas de aprendizado.  
  Agentes principais (exemplos):

  - CurriculumAI  
  - ResearchAI  
  - EduTechAI  
  - ContentSummarizerAI  
  - TeacherAI / TutorAI  
  - IndustrialProcessAI  
  - DataAnalystAI (lado educacional)  
  - QuizMakerAI  

### 1.7. Camada Games & Gamificação

- **`agents-games-layer.md`**  
  Jogos, experiências interativas e gamificação.  
  Agentes principais (exemplos):

  - GameDesignerAI  
  - GameStoryAI  
  - LevelDesignerAI  
  - AIBehaviorAI  
  - GameDevAI  
  - GamificationAI  
  - SimulationAI  

### 1.8. Camada de Impacto, Marketing & Análise

- **`agents-marketing-analytics-layer.md`**  
  Como o produto aparece no mundo, cresce e é medido.  
  Agentes principais (exemplos):

  - MarketingAI  
  - CopyMasterAI  
  - BrandDesignerAI (lado estratégico)  
  - CommunityAI  
  - SEOOptimizerAI  
  - AnalyticsAI  
  - BusinessPlannerAI  
  - InvestorPitchAI  
  - LegalAdvisorAI (sempre como rascunho, não conselho jurídico real).

### 1.9. Camada de UX & Experiência

- **`ux-layer-experiencia.md`**  
  Foca em **experiência do usuário ponta a ponta**:
  - jornadas,
  - fluxos,
  - navegação,
  - microcopy,
  - acessibilidade,
  - pesquisa com usuário.  
  Agentes principais (exemplos):

  - JourneyMapperAI / JourneyAI  
  - FlowDesignerAI  
  - InformationArchitectAI  
  - UXResearchAI  
  - InteractionAI  
  - MicrocopyAI  
  - AccessibilityAI  
  - ConsistencyGuardianAI  

### 1.10. Camada Multimodal / Experimental

- **`multimodal-agents-experimental-layer.md`**  
  Agentes que combinam **texto + imagem + áudio + vídeo** (camada explicitamente experimental).  
  Agentes principais (exemplos):

  - ImageSenseAI  
  - VideoSenseAI  
  - StoryboardMultimodalAI  
  - AudioSenseAI  
  - VoiceOverDirectorAI  
  - MultimodalOrchestratorAI  
  - PrototypeXR_AI  

---

## 2. Camadas de Infraestrutura & Plataforma

Estas camadas definem **stack, dados, segurança, automação, observabilidade e deploy**.

### 2.1. Backend Layer – Open Source Stack

- **`backend-layer-open-source-stack.md`**  
  Stack base de backend:

  - Supabase (Postgres + Auth + Storage + Realtime),
  - Vercel Functions / Deno Deploy,
  - tRPC / APIs REST,
  - Prisma / Drizzle ORM,
  - NextAuth/Auth.js (quando aplicável).

### 2.2. Data Management Layer – Dados, Logs e Armazenamento

- **`data-management-layer.md`**  
  Como armazenamos arquivos, logs e buscas:

  - Supabase Storage,
  - OpenPanel/Logto (logs/auditoria),
  - Redis/Valkey (cache/filas),
  - Meilisearch (busca),
  - PgBackRest / backups.

### 2.3. Database & Automation Layer – Banco & Automação

- **`database-automation-layer.md`**  
  Liga modelo de dados a migrações e automações SQL:

  - Schema Manager,
  - Migration Runner,
  - triggers & funções (ex.: saldo de estoque, lançamentos financeiros),
  - jobs baseados em DB,
  - checagens de consistência.

### 2.4. Security & RBAC Layer – Segurança & Acesso

- **`security-rbac-layer.md`**  
  Quem pode ver/fazer o quê, e como auditamos isso:

  - RLS no Supabase,
  - tabela de roles (`config_roles`) + policies,
  - audit trail (`logs_actions` + triggers),
  - Session Manager (middleware + Auth.js/NextAuth).

### 2.5. No-Code Authentication & Security Layer

- **`nocode-auth-security-layer.md`**  
  Autenticação e segurança com foco em **no-code / low-code**, complementando a camada técnica:

  - Supabase Auth / Auth0 / Clerk (login pronto, social login),
  - políticas simples de acesso (roles macro),
  - verificação e recuperação (email, magic link, OTP),
  - proteção básica contra abuso (rate limiting, captcha).

### 2.6. Observability Layer – Monitoramento & Logs

- **`observability-layer.md`**  
  Como vemos o que está acontecendo:

  - OpenTelemetry + Prometheus (métricas),
  - Grafana CE (dashboards),
  - Sentry (erros),
  - Umami (analytics de uso).

### 2.7. Intelligence & AI Integration Layer

- **`intelligence-ai-integration-layer.md`**  
  Cola de IA do ecossistema:

  - AI Gateway (OpenAI, Gemini),
  - orquestração (LangChain.js, LangGraph, CrewAI),
  - Vector DB (Supabase Vector, Weaviate CE),
  - Job Scheduler (BullMQ + Redis).

### 2.8. API & Integrações – Atlas, Google & Apps

- **`api-integrations-atlas-google-apps-layer.md`**  
  Integrações externas principais:

  - Google Drive / Sheets,
  - AtlasAI / CrewAI APIs,
  - WhatsApp / Telegram (Omnichannel),
  - Email (Resend, Mailpit),
  - CMS (Payload, Strapi).

### 2.9. Automação de IA – Backend Inteligente

- **`automation-ai-backend-layer.md`**  
  Processos de IA que rodam “por trás”:

  - AutoDocs, AutoSchemas, AutoAgents, AutoAudit, AutoDeploy,
  - OrchestratorAI, SchedulerAI, WatchdogAI,
  - ReportBuilderAI, ComplianceCheckerAI, CleanupAI, PatternMinerAI.

### 2.10. Dev Tools & Ambiente Local

- **`dev-tools-local-env-layer.md`**  
  Como devs e agentes técnicos trabalham localmente:

  - VS Code,
  - Docker / Docker Compose,
  - Supabase CLI,
  - Vitest/Jest, ESLint, Prettier,
  - Node version managers (nvm/fnm/volta),
  - padrão de `dev-environment.md` por projeto.

### 2.11. Deploy & Infra – Gratuita / Low-Cost

- **`deploy-infra-free-layer.md`**  
  Como colocar projetos no ar usando **Vercel, Supabase e serviços free/low-cost**:

  - Vercel (frontend/fullstack host),
  - Supabase (DB/Auth/Storage),
  - Resend (emails),
  - Sentry (erros),
  - Umami (analytics),
  - GitHub Actions / Vercel Cron para jobs leves,
  - boas práticas para começar no free tier e evoluir conforme uso.

### 2.12. IA & Mídia – Integração de IA e Conteúdo Multimídia

- **`ia-media-integration-layer.md`**  
  Conecta IA com pipelines de mídia (texto ↔ imagem ↔ áudio ↔ vídeo ↔ 3D):

  - fluxos com FlowiseAI / n8n,
  - geração de imagens (Stable Diffusion, Leonardo etc.),
  - vídeo (Pika, Runway, outros serviços),
  - música (Suno, Udio etc.),
  - 3D (Poly.cam, Three.js, Blender API),
  - orquestração de pipelines de conteúdo (roteiro → assets → vídeo → publicação).

---

## 3. Como usar este Atlas na prática

### 3.1. Para o Agents Hub

- Usar este arquivo como **mapa-mestre** ao:

  - criar blueprints de novos agentes,
  - definir novas camadas ou subcamadas,
  - conectar projetos a stacks e camadas específicas.

- Cada **projeto** dentro do Agents Hub idealmente terá docs mínimos como:

  - `backend-stack.md`
  - `data-management.md`
  - `security-rbac.md`
  - `auth-nocode.md` (quando aplicável)
  - `observability.md`
  - `ai-integration.md`
  - `integrations.md`
  - `automation-ai-backend.md`
  - `dev-environment.md`
  - `database-automation.md`
  - `deploy-infra.md`
  - `ux-layer.md`
  - `agents-used.md` (quais agentes principais atuam naquele projeto)

### 3.2. Para o OlieHub

- O OlieHub é um **caso de uso real** dentro desse Atlas.
- Podemos marcar, em docs específicos do OlieHub:

  - quais partes dessa arquitetura já estão implementadas,
  - quais estão em piloto / parcial,
  - quais fazem parte de roadmap (ex.: v1.0, v2.0 etc.).

### 3.3. Para novos projetos

- Ao iniciar um novo sistema (app, jogo, site, ERP, agente especializado):

  1. Passar pela **Camada Cognitiva + Master Catalyst** para definir visão e escopo.  
  2. Escolher quais **camadas técnicas e de agentes** serão usadas na v1.  
  3. Criar os docs mínimos para aquele projeto (stack, dados, segurança, UX, automação).  
  4. Registrar no Agents Hub:

     - o projeto,
     - os agentes envolvidos,
     - as camadas ativas,
     - os artefatos gerados (blueprints, diagramas, flows).

---

## 4. Próximos passos sugeridos

1. **Subir todos esses `.md` na base de conhecimento** do Catalyst / Agents Hub.  
2. Criar, dentro do Agents Hub, um módulo “Atlas” que liste essas camadas de forma navegável.  
3. Definir um primeiro **projeto-piloto completamente mapeado** (OlieHub é o candidato natural).  
4. Começar a criar os **blueprints individuais de agentes** (em `agents/*.md`) usando estas camadas como referência.  
5. Evoluir este Atlas sempre que:
   - novas camadas forem criadas,
   - agentes importantes forem adicionados,
   - stack/infra mudar de forma relevante.

Este arquivo é o “mapa da cidade”.  
Os `.md` individuais são os bairros e as ruas detalhadas.  
E os agentes são os habitantes que vão fazer tudo isso ganhar vida. 🧠🏙️

# Core & Catalyst Agents – Núcleo de Agentes do Atlas

> Este documento reúne os **agentes centrais** do ecossistema Olie / Agents Hub:
> - GOD Ideas Agent (visão suprema),
> - Master Catalyst (catalisador de ideias e design),
> - Architect & Orchestrator (Arquiteto de Agentes),
> - Núcleo de agentes técnicos principais (Core Code & Systems),
> - Regras e hierarquia para **criar novos agentes** de forma consistente.

Ele consolida e resume o conteúdo de:
- `god-ideas-agent.md`
- `catalyst-agent.md`
- `core-code-assistant.md`
- `agents-core.md`
- `agents-architect-agent.md`
- `agents-catalysts-hierarchy-and-creation.md`

---

## 1. GOD Ideas Agent – Visão Suprema

**Papel:**  
Representa o “usuário GOD” – a entidade que enxerga **todo o ecossistema** de projetos, produtos e agentes.
Ele não executa tarefas técnicas; ele guarda e explicita:

- a visão macro (por quê estamos fazendo isso?),
- objetivos de longo prazo,
- prioridades entre projetos,
- princípios e limites (éticos, técnicos, de negócio).

**Responsabilidades principais:**

1. Manter um **“livro de visão”**:
   - manifesto de propósito do ecossistema,
   - mapa de grandes projetos e linhas de evolução.
2. Servir como **fonte de verdade** para o Catalyst Agent:
   - quando houver dúvida de direção, o Catalyst consulta a visão do GOD,
   - registra novas decisões estratégicas.
3. Guardar decisões “irreversíveis”:
   - mudanças profundas de stack,
   - mudança de foco de produto,
   - decisões de descontinuar projetos ou agentes.

---

## 2. Master Catalyst Agent – Catalisador de Ideias & Design

**Papel:**  
É o agente responsável por transformar **ideias brutas** em algo **claramente especificado**, antes de virar código.
Ele não codifica; ele:

- faz perguntas,
- organiza requisitos,
- desenha fluxos, entidades e interfaces,
- propõe arquiteturas conceituais,
- gera blueprints e kits de prompts para outros agentes.

**Saídas típicas do Master Catalyst:**

- `project-brief.md` – resumo do projeto (problema, público, solução, escopo).  
- `architecture-outline.md` – visão em alto nível de módulos, dados, integrações.  
- `agents-blueprint.md` – lista de agentes necessários para aquele projeto.  
- `prompt-kits-<projeto>.md` – prompts padrão para Code Assistant, DB Agent, etc.

**Regras de atuação:**

1. Sempre começa **perguntando** (não assumindo) – clarifica contexto, objetivo, restrições.  
2. Evita “pular para código” – fica na camada de **design, arquitetura e planejamento**.  
3. Sempre registra:
   - o que foi decidido,
   - o que ainda é dúvida,
   - próximos passos.

---

## 3. Architect & Orchestrator – Arquiteto de Agentes

**Papel:**  
É o “**Arquiteto de Agentes**” – pensa o **ecossistema de agentes** como um sistema em si:

- define tipos e camadas de agentes,
- desenha como eles se comunicam,
- garante que não haja sobreposição excessiva ou lacunas críticas,
- ajuda a criar novos agentes a partir de padrões.

**Responsabilidades principais:**

1. Manter o **mapa de agentes** (Agents Map):  
   - camadas (Cognitiva, Técnica, Criativa, Story, Musical, Educação, Games, Marketing, etc.),  
   - agentes centrais de cada camada,  
   - links entre agentes e projetos.

2. Definir **padrões de agente**:  
   para cada novo agente, especificar:

   - Nome e propósito,
   - Entrada esperada (inputs),
   - Saídas (artefatos, decisões, documentos),
   - Limites (o que NÃO faz),
   - Relações (quem chama, quem ele chama, com quem conversa).

3. Orquestrar a evolução do catálogo:
   - revisar agentes redundantes,
   - propor fusões ou divisões,
   - garantir que as mudanças fiquem registradas.

---

## 4. Núcleo de Agentes Técnicos (Core Code & Systems)

Estes são os agentes “de chão técnico”, que executam a visão e os blueprints do Catalyst e do Architect.

### 4.1. Systems Architect / ArchitectAI

- Traduz **visão de produto** em **arquitetura técnica** concreta:
  - escolhe stack (Next.js / Supabase / etc.),
  - define módulos de backend e frontend,
  - modela entidades principais (modelo de dados inicial),
  - desenha as integrações de alto nível (APIs, filas, jobs).

### 4.2. CodeAssistantAI (Core Code Assistant)

- Ajuda a **escrever e refatorar código** seguindo os blueprints:
  - cria arquivos, componentes, hooks, serviços,
  - melhora legibilidade, testes, tipagem,
  - sugere padrões de arquitetura (DDD, modularização, etc.).
- Deve sempre se guiar pelos documentos de:
  - arquitetura,
  - modelo de dados,
  - prompt kits,
  - guidelines de stack.

### 4.3. DB / EngenheiroDeDados

- Cuida de **modelo de dados e SQL**:
  - desenha esquemas (tabelas, relacionamentos, índices),
  - escreve migrações,
  - propõe triggers e funções,
  - sugere políticas RLS (Security & RBAC).

### 4.4. IntegratorAI

- Focado em **integrações externas**:
  - APIs de pagamento, ERPs, WhatsApp/Telegram, Google, etc.
  - desenha contratos de API,
  - trata erros, timeouts e re-tentativas,
  - garante que credenciais e segredos sejam tratados com cuidado.

### 4.5. AuditorDeSistema

- Agente de **auditoria técnica**:
  - revisa código, queries, políticas,
  - identifica riscos de segurança, performance, consistência,
  - gera relatórios e recomendações.

### 4.6. APIConnectorAI

- Especialista em **conectar APIs específicas** a projetos:
  - gera clientes tipados,
  - desenha “adapters” para que APIs externas fiquem internas limpas,
  - documenta endpoints disponíveis e usos recomendados.

### 4.7. TestAutomationAI

- Cuida de **testes automatizados**:
  - sugere suites de teste,
  - gera testes unitários e de integração,
  - ajuda a definir estratégias de CI.

### 4.8. DeployManagerAI

- Ajuda em **deploy & infra**:
  - Vercel, Supabase, GitHub Actions, etc.,
  - define pipelines básicos,
  - sugere checagens de saúde pós-deploy.

> Observação: os nomes exatos podem variar nos arquivos de camada técnica,  
> mas este documento serve como visão agregada do **núcleo técnico**.

---

## 5. Hierarquia e Criação de Novos Agentes

Inspirado em `agents-catalysts-hierarchy-and-creation.md`.

### 5.1. Hierarquia básica

1. **GOD Ideas Agent**
   - Fonte de visão suprema e decisões macro.

2. **Master Catalyst Agent**
   - Converte visão em projetos e blueprints.

3. **Architect & Orchestrator**
   - Desenha o ecossistema de agentes e sua colaboração.

4. **Camadas de agentes especializados**
   - Técnica (arquitetura, código, dados, integrações),
   - Criativa (visual, audiovisual, música),
   - UX & Experiência,
   - Educação,
   - Games,
   - Marketing & Análise,
   - Multimodal / Experimental.

5. **Agentes auxiliares / de suporte**
   - DB tools, DevOps helpers, observabilidade, automação de IA, etc.

### 5.2. Processo padrão para criar um novo agente

1. **Definir o problema / necessidade**  
   - O que está faltando?
   - Há sobreposição com algum agente existente?

2. **Passar pelo Master Catalyst**  
   - Refinar a ideia do agente,
   - Clarificar contexto, inputs, saídas, limites.

3. **Passar pelo Architect & Orchestrator**  
   - Encaixar o agente numa camada e categoria,
   - Definir relações com agentes já existentes,
   - Evitar duplicação de papéis.

4. **Criar o blueprint do agente** (`agents/<nome-do-agente>.md`)  
   - Nome canônico,
   - Objetivo,
   - Inputs / Outputs,
   - Responsabilidades,
   - Limites (o que não faz),
   - Exemplos de uso,
   - Relações (quem chama / quem ele chama).

5. **Registrar no Agents Hub**  
   - Linkar o agente a projetos relevantes,
   - Marcar status (experimental, estável, desativado),
   - Documentar histórico de mudanças.

---

## 6. Como este núcleo se conecta às Camadas de Agentes

- As **camadas de agentes** (Técnica, Criativa, Story, Música, Educação, UX, Games, Marketing, Multimodal) detalham
  grupos específicos de agentes com foco em domínios.

- O presente documento define o **núcleo de governança e execução**:
  - quem decide a visão (GOD),
  - quem transforma visão em blueprint (Master Catalyst),
  - quem desenha o ecossistema de agentes (Architect & Orchestrator),
  - e quais são os agentes técnicos “base” para implementação.

Na prática, todo novo projeto deveria começar com:

1. GOD Ideas Agent → visão macro.  
2. Master Catalyst → briefing + arquitetura conceitual + agentes necessários.  
3. Architect & Orchestrator → encaixar agentes no atlas + evitar duplicações.  
4. Agentes Técnicos → implementação guiada (código, dados, integrações, UX etc.).

Este arquivo é a “espinha dorsal” dos agentes do Atlas.
Os demais arquivos de camada detalham cada família de agentes em profundidade.


# Index – Camadas de Agentes por Domínio (Bloco C)

> Este arquivo é um índice rápido das **camadas de agentes por domínio**.
> Ele não substitui os `.md` individuais – apenas ajuda o GPT a localizar
> qual arquivo ler para cada tipo de trabalho.

---

## 1. Camada Técnica – Arquitetura & Engenharia

**Arquivo:** `agents-technical-architecture-layer.md`  

Foca em agentes que cuidam de **arquitetura técnica, código, dados, integrações e deploy**, por exemplo:

- Systems Architect / ArchitectAI  
- CodeAssistantAI  
- EngenheiroDeDados / DB  
- IntegratorAI  
- AuditorDeSistema  
- APIConnectorAI  
- TestAutomationAI  
- DeployManagerAI  

Use esta camada quando o assunto for: **stack, backend, frontend, banco, APIs, CI/CD**.

---

## 2. Camada Criativa Visual

**Arquivo:** `agents-creative-visual-layer.md`  

Agentes ligados a **identidade visual, UI, mockups, texturas, 3D e produto visual**, por exemplo:

- VisualDesignerAI  
- UXBuilderAI (lado visual)  
- BrandDesignerAI (quando aplicado à parte visual)  
- TextileAI / PatternAI  
- 3DDesignerAI (visual)  
- ProductMockupAI  

Use esta camada quando o assunto for: **design visual, telas, branding visual, produtos físicos digitais**.

---

## 3. Camada Audiovisual & Story

**Arquivo:** `agents-audiovisual-story-layer.md`  

Agentes que trabalham com **história, narrativa, vídeo, direção e emoção**, por exemplo:

- NarradorAI / NarratorAI  
- ScriptWriterAI / StoryWriterAI  
- WorldBuilderAI / CharacterDesignerAI  
- VisualDirectorAI / DirectorAI  
- VideoCreatorAI  
- EmotionArchitectAI  
- CinematicComposerAI (na intersecção com música)  

Use esta camada quando o assunto for: **roteiro, vídeos, histórias, cenas, impacto emocional**.

---

## 4. Camada Musical & Áudio

**Arquivo:** `agents-musical-audio-layer.md`  

Agentes especializados em **trilha, batida, voz, mix/master**, por exemplo:

- MusicProducerAI  
- SoundComposerAI / ComposerAI  
- BeatMakerAI  
- VocalSynthAI / VoiceAI / VoiceCloneAI  
- MixMasterAI  
- LyricistAI  

Use esta camada quando o assunto for: **música, trilha, voz, podcast, efeitos sonoros**.

---

## 5. Camada de Conhecimento & Educação

**Arquivo:** `agents-learning-layer.md`  

Agentes focados em **aprender, ensinar, organizar conhecimento**, por exemplo:

- CurriculumAI  
- ResearchAI  
- EduTechAI  
- ContentSummarizerAI  
- TeacherAI / TutorAI  
- IndustrialProcessAI  
- DataAnalystAI (lado educacional)  
- QuizMakerAI  

Use esta camada quando o assunto for: **cursos, trilhas de aprendizado, resumos, materiais didáticos**.

---

## 6. Camada de Jogos & Gamificação

**Arquivo:** `agents-games-layer.md`  

Agentes dedicados a **jogos, simulações e gamificação**, por exemplo:

- GameDesignerAI  
- GameStoryAI  
- LevelDesignerAI  
- AIBehaviorAI  
- GameDevAI  
- GamificationAI  
- SimulationAI  

Use esta camada quando o assunto for: **game design, mecânicas de jogo, loops de engajamento, simulações**.

---

## 7. Camada de Marketing, Impacto & Análise

**Arquivo:** `agents-marketing-analytics-layer.md`  

Agentes voltados para **crescimento, comunicação, posicionamento e análise de negócio**, por exemplo:

- MarketingAI  
- CopyMasterAI  
- BrandDesignerAI (lado estratégico)  
- CommunityAI  
- SEOOptimizerAI  
- AnalyticsAI  
- BusinessPlannerAI  
- InvestorPitchAI  
- LegalAdvisorAI (como rascunho, não conselho jurídico real)  

Use esta camada quando o assunto for: **campanhas, funis, copy, análise de resultados, estratégia de negócio**.

---

## 8. Camada de UX & Experiência

**Arquivo:** `ux-layer-experiencia.md`  

Agentes focados em **experiência do usuário ponta a ponta**, por exemplo:

- JourneyMapperAI / JourneyAI  
- FlowDesignerAI  
- InformationArchitectAI  
- UXResearchAI  
- InteractionAI  
- MicrocopyAI  
- AccessibilityAI  
- ConsistencyGuardianAI  

Use esta camada quando o assunto for: **jornada, fluxos, navegação, microcopy, acessibilidade, pesquisa com usuário**.

---

## 9. Camada Multimodal / Experimental

**Arquivo:** `multimodal-agents-experimental-layer.md`  

Agentes que lidam com **texto + imagem + áudio + vídeo** de forma integrada, por exemplo:

- ImageSenseAI  
- VideoSenseAI  
- StoryboardMultimodalAI  
- AudioSenseAI  
- VoiceOverDirectorAI  
- MultimodalOrchestratorAI  
- PrototypeXR_AI  

Use esta camada quando o assunto for: **análise ou geração multimodal, protótipos XR, experiências ricas**.

---

## Como o GPT deve usar este índice

1. Quando o usuário falar de **um tipo de trabalho**, o GPT pode:
   - identificar a camada mais relacionada,
   - consultar mentalmente o arquivo dessa camada,
   - escolher os agentes mais adequados.

2. Quando for projetar **novos agentes**, usar este índice para:
   - ver se já existe uma camada adequada,
   - evitar duplicações (reusar ou estender agentes existentes),
   - manter a organização coerente com o Atlas.

Este índice é apenas um mapa rápido.
Os detalhes de cada agente estão em seus respectivos arquivos de camada.

# Agents Hub – Modelo de Dados Conceitual (v1)

> Este documento descreve o modelo de dados **conceitual** do Agents Hub.  
> Não é SQL definitivo, e sim um mapa de entidades, relações e intenções.
> O objetivo é servir de base para:
> - o Catalyst Agent projetar features,
> - o Core Code Assistant gerar código,
> - e o GOD user visualizar o “esqueleto” do hub.

---

## 1. Visão Geral

O Agents Hub gerencia quatro eixos principais:

1. **Projetos** – coisas que queremos construir ou já existem (sistemas, produtos, apps).
2. **Agentes** – agentes de IA e suas versões (CORE + específicos por projeto).
3. **Ideias / Backlog** – ideias, iniciativas, melhorias, experimentos.
4. **Conversas / Contextos** – pontos de contexto importantes (anotações, decisões, links para chats).

Além disso, no futuro podem existir:

- **Tasks / Work Items** – tarefas derivadas das ideias,
- **Links Externos** – conexões com GitHub, Notion, etc.,
- **Users / Roles** – GOD user, colaboradores, etc.

Por enquanto, focamos no **núcleo mínimo**: `projects`, `agents`, `agent_versions`, `ideas`, `conversations`.

---

## 2. Entidade: Project

Representa um projeto/sistema/produto dentro do Hub.

### Conceito

- Um **Project** pode ser:
  - um sistema como o OlieHub,
  - um site,
  - um app mobile,
  - um jogo,
  - um “produto interno” (ex.: plataforma de relatórios),
  - ou até um “meta projeto” (como o próprio Agents Hub).

### Campos (conceituais)

- `id` – identificador único (UUID).
- `name` – nome do projeto (ex.: “OlieHub”, “Agents Hub”).
- `slug` – identificador amigável (ex.: `oliehub`, `agents-hub`).
- `description` – descrição curta/longa do projeto.
- `status` – estágio (ex.: `idea`, `discovery`, `planning`, `active`, `on_hold`, `archived`).
- `type` – tipo de projeto (ex.: `product`, `internal_tool`, `experiment`, `content`).
- `stack_summary` – texto livre/JSON com resumo da stack principal (ex.: “React + Supabase + Vercel”).  
- `created_at` / `updated_at` – timestamps.
- `owner_id` (opcional) – referência ao usuário/GOD responsable (futuro).

### Relações principais

- Um **Project** pode ter muitas **Ideas** ligadas a ele.
- Um **Project** pode ter muitos **Agents** (especializações dos agents core).
- Um **Project** pode ter muitas **Conversations** relevantes (decisões, discussões).

---

## 3. Entidade: Agent

Representa um agente (template ou especializado) registrado no Hub.

### Conceito

- Um **Agent** pode ser:
  - um agente CORE (global),
  - uma especialização por projeto (ex.: `oliehub-code-assistant`),
  - um agente criativo específico,
  - um agente de ops, suporte, etc.

### Campos (conceituais)

- `id` – identificador único (UUID).
- `agent_key` – identificador lógico/slug (ex.: `catalyst-agent`, `god-ideas-agent`, `core-code-assistant`, `oliehub-code-assistant`).
- `name` – nome exibido (ex.: “Catalyst Agent”, “OlieHub Code Assistant”).
- `scope` – escopo lógico:
  - `global` (template),
  - `project` (ligado a um projeto específico),
  - `experimental`.
- `project_id` (nullable) – referência a `Project` quando for específico de um projeto.
- `base_agent_id` (nullable) – referência a outro `Agent` quando este for derivado (ex.: OlieHub Code Assistant derivado do Core Code Assistant).
- `role` – descrição textual do papel principal.
- `status` – `active`, `experimental`, `deprecated`.
- `tags` – lista de tags (ex.: `code`, `ideas`, `ops`, `creative`).
- `current_version_id` (nullable) – referência para a versão atual (na tabela `agent_versions`).
- `created_at` / `updated_at`.

### Relações principais

- Um **Agent** pode ter várias **AgentVersions** (histórico).
- Um **Agent** pode estar ligado a um **Project** (quando específico).
- Um **Agent** pode estar relacionado a muitas **Ideas** (ideias que pedem alteração/criação desse agente).

---

## 4. Entidade: AgentVersion

Representa uma versão específica do blueprint de um agente.

### Conceito

- Cada vez que redesenhamos um agente (mudança de escopo, role, tools, etc.), criamos uma nova **AgentVersion**.
- Isso facilita histórico e comparação entre versões.

### Campos (conceituais)

- `id` – identificador único (UUID).
- `agent_id` – referência ao `Agent` ao qual pertence.
- `version_label` – string de versão (ex.: `1.0.0`, `1.1.0`, `2.0.0`).
- `changelog` – resumo das mudanças desta versão (texto).
- `blueprint_md_url` ou `blueprint_ref` – referência para o arquivo `.md` do blueprint (pode ser URL, path lógico, ou storage key).
- `created_at` – quando foi criada.
- `created_by` (opcional) – quem criou (GOD user, outro).

### Relações principais

- Pertence a um **Agent** (N:1).
- Pode ser referenciada por **Ideas** que sugerem evoluções daquele agente.

---

## 5. Entidade: Idea

Representa qualquer ideia / melhoria / iniciativa em potencial.

### Conceito

- É a unidade básica de pensamento no backlog:
  - pode ser uma feature,
  - uma melhoria de UX,
  - uma correção/refactor,
  - um novo agente,
  - um experimento,
  - um conteúdo (site, material, campanha).

### Campos (conceituais)

- `id` – identificador único (UUID).
- `title` – título curto e claro (ex.: “Agente de Design para OlieHub”).
- `description` – descrição detalhada da ideia.
- `type` – categoria (ex.: `feature`, `improvement`, `refactor`, `agent`, `experiment`, `content`, `ops`).
- `project_id` (nullable) – referência a `Project` (ou null se for global).
- `related_agent_id` (nullable) – referência a `Agent`, se a ideia for sobre um agente específico.
- `status` – estágio da ideia:
  - `draft`,
  - `triage`,
  - `ready_for_design`,
  - `in_design`,
  - `ready_for_implementation`,
  - `in_progress`,
  - `done`,
  - `discarded`.
- `impact_estimate` (nullable) – texto ou enum simples (ex.: `low`, `medium`, `high`, `very_high`).
- `effort_estimate` (nullable) – texto ou enum simples (ex.: `xs`, `s`, `m`, `l`, `xl`).
- `priority_hint` (nullable) – campo livre ou enum.
- `origin` – origem da ideia (ex.: `god_user`, `ops_agent`, `support`, `user_feedback`, `experiment`).
- `source_reference` (nullable) – link ou ID para conversa/documento onde a ideia surgiu.
- `tags` – lista de tags (módulos, tecnologias, temas).
- `created_at` / `updated_at`.
- `created_by` (opcional) – quem criou.

### Relações principais

- Uma **Idea** pode estar ligada a um **Project** (ou não).
- Pode estar ligada a um **Agent** (ideia sobre design/ajuste de agente).
- Pode ter relação com uma ou mais **Conversations** (discussões onde foi falada).
- Pode, no futuro, ser ligada a **Tasks** e **Issues** externas (GitHub, Jira, etc.).

---

## 6. Entidade: Conversation

Representa um contexto de conversa ou decisão relevante.

### Conceito

- Não precisa ser uma transcrição completa.
- Pode ser um “bloco de contexto” com:
  - resumo da conversa,
  - links para chats externos (ChatGPT, Gemini, etc.),
  - decisões tomadas,
  - próximos passos.

### Campos (conceituais)

- `id` – identificador único (UUID).
- `project_id` (nullable) – referência a `Project` (se a conversa for sobre um projeto específico).
- `title` – título (ex.: “Discussão inicial sobre o Agents Hub”).
- `summary` – resumo das decisões e pontos importantes.
- `source_type` – ex.: `chatgpt`, `gemini`, `meeting`, `doc`.
- `source_link` (nullable) – link externo (ex.: URL de conversa, doc, reunião).
- `related_idea_ids` (opcional, lista) – referência a ideas que surgiram ali (pode ser modelado via tabela de junção).
- `created_at` / `updated_at`.
- `created_by` (opcional).

### Relações principais

- Uma **Conversation** pode estar ligada a um **Project**.
- Pode estar ligada a várias **Ideas** (N:N).
- Serve como “âncora de contexto” para entender de onde surgiram decisões e backlog.

---

## 7. Relações Resumidas

- **Project 1:N Ideas**
- **Project 1:N Agents**
- **Agent 1:N AgentVersions**
- **Agent 1:N Ideas** (quando a ideia é sobre um agente)
- **Project 1:N Conversations**
- **Conversation N:N Ideas** (via tabela de junção `conversation_ideas`)

### Tabelas auxiliares sugeridas (conceituais)

- `conversation_ideas`
  - `conversation_id`
  - `idea_id`

No futuro (não obrigatório na v1):

- `tasks` – tarefas derivadas de ideias.
- `external_links` – links para GitHub issues, PRs, etc.
- `users` / `members` – pessoas que interagem com o hub.

---

## 8. Cenários de Uso Típicos

### 8.1. Cadastrar um novo projeto

1. Criar registro em `projects` com nome, descrição, stack, status.
2. Criar agentes específicos derivados do CORE (ex.: `oliehub-code-assistant`) em `agents`.
3. Registrar a conversa de inception em `conversations`.

### 8.2. Registrar uma ideia nova

1. Criar `idea` com título, descrição, tipo, origem.
2. Se já tiver projeto: preencher `project_id`.
3. Se for sobre um agente: preencher `related_agent_id`.

### 8.3. Evoluir uma ideia para “pronta para design”

1. Atualizar `status` da `idea` para `ready_for_design`.
2. O GOD Ideas Agent pode sugerir encaminhar ao Catalyst.

### 8.4. Versionar um agente

1. Criar novo registro em `agent_versions` com referência ao `agent_id` e `version_label`.
2. Atualizar `agents.current_version_id` para apontar para a nova versão.

---

## 9. Próximos Passos

1. O Catalyst Agent pode:
   - propor ajustes nesse modelo conceitual conforme surgirem necessidades,
   - ajudar a priorizar quais entidades/tabelas entrarão na v1 do banco (Supabase).

2. Quando formos para o nível SQL:
   - mapear essas entidades para tabelas concretas,
   - decidir tipos de dados,
   - definir RLS (quando for o momento),
   - criar views/relatórios necessários.

3. Integrar isso com os blueprints de agentes CORE:
   - GOD Ideas Agent trabalhando com `ideas`,
   - Catalyst Agent com `projects`, `agents`, `ideas`,
   - Core Code Assistant com o que for definido como parte do código do Agents Hub.

---
# Agents Hub – Visão Geral Conceitual

> Este documento descreve o **Hub Genérico de Projetos, Agentes e Ideias**  
> (NÃO é o OlieHub em si – o OlieHub será apenas um dos primeiros projetos a viver dentro deste Hub).

---

## 1. O que é o Agents Hub?

O **Agents Hub** é um sistema genérico para organizar:

- **Ideias** → que podem virar
- **Projetos** → que podem virar
- **Sistemas / Produtos / Apps** → que geram
- **Apresentações, materiais, conteúdo, agentes de IA e melhorias contínuas**.

Ele funciona como um **“cérebro organizador de projetos e agentes”**, independente da tecnologia usada dentro de cada projeto.

O OlieHub é apenas um **primeiro caso de uso** dentro deste Hub – um projeto entre vários.

---

## 2. Objetivos principais do Agents Hub

1. **Centralizar Ideias**
   - Guardar ideias vindas de qualquer lugar (conversas, documentos, insights espontâneos).
   - Evitar que boas ideias se percam em chats soltos ou arquivos espalhados.

2. **Evoluir Ideias em Projetos**
   - Marcar quando uma ideia virou um projeto concreto.
   - Relacionar ideias derivadas, versões, pivotagens e forks.

3. **Conectar Projetos a Sistemas / Produtos**
   - Ligar projetos a repositórios (GitHub, etc.).
   - Ligar projetos a sistemas em produção (deploys, domínios, APIs).

4. **Orquestrar Agentes de IA**
   - Cadastrar agentes (técnicos, criativos, operacionais, analíticos).
   - Definir blueprints de cada agente (goals, escopo, inputs/outputs, integrações).
   - Permitir reuso de agentes entre projetos.

5. **Gerenciar Backlog e Melhorias**
   - Backlog central de ideias por projeto ou global.
   - Ligações entre ideias → tarefas → PRs → releases.
   - Histórico de decisões: o que foi feito, o que foi descartado, o que permanece em estudo.

6. **Servir como memória estratégica**
   - Saber quais projetos existem, quais morreram, quais estão ativos.
   - Saber quais agentes existem e em que são bons.
   - Usar o histórico como base para novos projetos e novas versões.

---

## 3. Diferença entre Agents Hub e OlieHub

- **Agents Hub**
  - É o sistema meta, genérico.
  - Gerencia projetos de qualquer tipo (ERPs, apps, sites, jogos, bots, etc.).
  - Gerencia agentes de IA e ideias de forma abstrata.
  - O foco é **orquestração de conhecimento, projetos e agentes**.

- **OlieHub**
  - É um projeto específico dentro do Agents Hub.
  - É um ERP / plataforma de operações para o Ateliê Olie (manufatura + varejo).
  - Tem seu próprio banco (Supabase), módulos (Pedidos, Produção, Estoque...).
  - Vai ser um dos **primeiros “clientes”** do Agents Hub, usado como laboratório real.

Em resumo:
- O **Agents Hub** é o “sistema dos sistemas e agentes”.  
- O **OlieHub** é um desses sistemas, e será o piloto principal.

---

## 4. Fluxo macro: da ideia à melhoria contínua

1. **Ideia nasce**
   - Pode surgir em conversa com um agente (Catalyst, por exemplo), numa reunião, num insight do GOD user.
   - É registrada no Agents Hub como uma **Idea**, com contexto mínimo (título, descrição, tags, origem).

2. **Ideia vira Projeto**
   - Quando decidida como “vale investir”, ela é promovida a **Project**.
   - São definidos:
     - objetivos,
     - stakeholders,
     - tecnologias iniciais sugeridas,
     - primeiros agentes envolvidos (ex.: Catalyst + Code Assistant).

3. **Projeto vira Sistema / Produto**
   - O projeto ganha um repositório (GitHub) e começa a ser implementado.
   - O Agents Hub registra:
     - links de repositórios,
     - ambientes (dev, staging, prod),
     - status (inception, build, beta, production, maintenance).

4. **Sistema gera materiais e agentes**
   - A partir do sistema, são criados:
     - **apresentações**, materiais de venda, documentação,
     - **agentes especializados** (ex.: Support Agent, Ops Agent, Code Agent para aquele sistema),
     - **conteúdo** (site, posts, vídeos, etc.).

5. **Melhorias e ideias retornam ao Hub**
   - Novas ideias de features, refactors, integrações e agentes voltam como **Ideas** ligadas ao projeto.
   - O Agents Hub as registra, relaciona e permite priorização.
   - O ciclo continua: IDEIA → PROJETO → SISTEMA → AGENTES/CONTEÚDO → IDEIAS.

---

## 5. Tipos de agentes previstos no ecossistema

O Agents Hub não é só para apps técnicos. Ele também abrange agentes criativos.

Exemplos de categorias:

1. **Agentes Técnicos**
   - Code Assistants (GitHub + Supabase + Vercel)
   - DB/SQL Assistants
   - DevOps/Infra Assistants
   - Test/QA Assistants

2. **Agentes de Produto & Arquitetura**
   - Catalyst Agent (ideias, design, planejamento)
   - Requirements/Docs Agent
   - Roadmap/Prioritização Agent

3. **Agentes Criativos**
   - Design UI/UX Agent (telas, flows, componentes)
   - Visual Content Agent (posts, catálogos, imagens)
   - Video/Script Agent (roteiros, storytelling)
   - Game/Experience Agent (jogos, interações)
   - Music/Audio Agent (identidade sonora, trilhas simples)

4. **Agentes Operacionais & Suporte**
   - Support Agent (FAQ, orientação, troubleshooting)
   - Ops Agent (monitoramento, alertas, análises operacionais)
   - Analytics Agent (dashboards, insights, relatórios)

O Agents Hub será o lugar onde tudo isso é **descrito, versionado, conectado e reaproveitado**.

---

## 6. Papel do Catalyst Agent dentro do Agents Hub

O **Catalyst Agent** é o “primeiro agente oficial” do ecossistema, com papel de:

- Entrevistar o GOD user e stakeholders.
- Transformar ideias em:
  - especificações de sistemas,
  - blueprints de agentes,
  - planos de implementação.
- Sugerir onde e como registrar:
  - projetos,
  - agentes,
  - ideias,
  - conversas importantes.

O Catalyst não implementa nada diretamente; ele é o **designer/arquitetor** que alimenta o Agents Hub de forma organizada.

---

## 7. Próximos passos (conceituais)

1. **Definir modelo de dados conceitual do Agents Hub**
   - Entidades principais:
     - `projects`
     - `agents`
     - `agent_versions`
     - `ideas`
     - `conversations` (metadados)
     - (futuramente) `tasks`, `links externos` etc.

2. **Desenhar UX do GOD user**
   - Painel de visão geral:
     - quantos projetos, quantos agentes, quantas ideias, status.
   - Tela de detalhe de projeto com:
     - ideias ligadas,
     - agentes usados,
     - links de repositório e produção.
   - Tela de cadastro/edição de agentes (blueprints).

3. **Escolher primeiro projeto piloto dentro do Hub**
   - O **OlieHub** é um forte candidato para ser o primeiro projeto formalmente registrado.

4. **Começar a escrever blueprints de agentes**
   - Catalyst Agent (já iniciado);
   - Próximos: Code Assistant genérico, Agents Hub Manager, GOD Ideas Agent, etc.

---

## 8. Lembrete importante

- O **Agents Hub** é genérico, multi-projeto, multi-agente.  
- O **OlieHub** é um desses projetos, um estudo de caso real para provar o valor do Hub.  
- Tudo que for criado para o OlieHub (agentes, fluxos, melhorias) deve, idealmente, aparecer como conhecimento reaproveitável dentro do Agents Hub.

# Agents Map Overview – Visão dos Principais Agentes (v1)

> Este documento resume os principais agentes CORE e como eles se conectam.
> Serve como mapa rápido para o GOD user e como referência para os próprios agentes.

---

## 1. Principais Agentes CORE

### 1. Catalyst Agent (Master)

- **Papel:** transformar ideias em requisitos, arquitetura e planos de implementação.
- **Escopo:** global (multi-projeto).
- **Quando acionar:**
  - quando uma ideia estiver madura para virar módulo/sistema,
  - quando precisar redesenhar um fluxo existente,
  - quando quiser um plano em etapas.

### 2. GOD Ideas & Backlog Agent

- **Papel:** capturar, organizar e priorizar ideias.
- **Escopo:** global (mas consegue filtrar por projeto).
- **Quando acionar:**
  - para despejar ideias soltas,
  - para estruturar backlog,
  - para decidir o que está pronto para design (Catalyst).

### 3. Agents Architect & Orchestrator (God of Agents)

- **Papel:** arquiteto-chefe de agentes.
- **Escopo:** global.
- **Quando acionar:**
  - quando você tiver ideia de novo agente,
  - quando quiser saber quais agentes usar em um novo projeto,
  - quando o catálogo de agentes estiver confuso e precisar de limpeza/organização.

### 4. Core Code Assistant

- **Papel:** implementar código e refactors com base em planos já definidos.
- **Escopo:** global (podendo ter versões por projeto).
- **Quando acionar:**
  - quando já houver plano do Catalyst,
  - quando precisar implementar ou refatorar módulos,
  - quando for integrar com Supabase/APIs.

### 5. Docs & Knowledge Agent (conceitual v1)

- **Papel:** transformar decisões e código em documentação organizada.
- **Escopo:** global, com seções por projeto.
- **Quando acionar:**
  - após decisões arquiteturais importantes,
  - após implementações significativas,
  - para criar/atualizar README, overviews, ADRs simples.

### 6. Ops & Analytics Agent (conceitual v1)

- **Papel:** analisar dados de operação e apontar problemas/oportunidades.
- **Escopo:** por projeto (monitorando sistemas específicos).
- **Quando acionar:**
  - quando houver métricas, logs, erros,
  - quando quiser insights sobre performance ou uso.

### 7. Creative Experience Agent (conceitual v1)

- **Papel:** desenhar experiências criativas (UI/UX, conteúdo, roteiros).
- **Escopo:** global, com especializações por projeto.
- **Quando acionar:**
  - para criar ou melhorar telas,
  - para materiais de apresentação,
  - para campanhas, posts, roteiros de vídeo.

---

## 2. Diagrama Textual Simplificado

```text
                 [GOD User]
                     |
                     v
         +--------------------------+
         |      GOD Ideas Agent     |
         |   (ideias & backlog)     |
         +--------------------------+
                     |
          ideias maduras / priorizadas
                     v
         +--------------------------+
         |      Catalyst Agent      |
         | (arquitetura & planos)   |
         +--------------------------+
                     |
           requisitos / planos
                     v
         +--------------------------+
         |    Core Code Assistant   |
         |  (implementação & ref)   |
         +--------------------------+
                     |
               código / mudanças
                     v
         +--------------------------+
         |   Docs & Knowledge Agent |
         |     (docs & decisões)    |
         +--------------------------+
                     |
                docs atualizadas
                     v
         +--------------------------+
         |    Ops & Analytics Agent |
         |  (dados & insights)      |
         +--------------------------+
                     |
      problemas / oportunidades / ideias
                     v
         +--------------------------+
         |      GOD Ideas Agent     |
         +--------------------------+

Paralelamente:
- Sempre que uma ideia envolver AGENTES em si:
  GOD Ideas → Agents Architect & Orchestrator → novos/evoluídos agentes.
- Sempre que for necessário algo visual/marketing/experiência:
  Catalyst / GOD / Code → Creative Experience Agent → materiais & UX.
```

---

## 3. Quem chama quem (resumo)

- **GOD user → GOD Ideas Agent**  
  sempre que surgir algo novo (ideias, problemas, oportunidades).

- **GOD Ideas Agent → Catalyst Agent**  
  quando uma ideia estiver pronta para design/arquitetura.

- **GOD Ideas Agent → Agents Architect**  
  quando a ideia for sobre criar/evoluir agentes.

- **Catalyst Agent → Core Code Assistant**  
  quando já houver plano para ser implementado.

- **Core Code Assistant → Docs Agent**  
  quando uma implementação significativa for concluída.

- **Ops & Analytics Agent → GOD Ideas Agent**  
  quando descobrir problemas/oportunidades na operação.

- **GOD user / Catalyst / Code → Creative Agent**  
  quando precisar de UX, materiais, mensagens, storytelling.

---

## 4. Mapa por Fase do Lifecycle

Voltando ao `project-lifecycle.md`, podemos mapear:

- Fase 0–1 (Insight & Ideias)
  - **Principal:** GOD Ideas Agent
  - Apoio: GOD user, Ops (quando houver dados)

- Fase 2 (Design & Arquitetura)
  - **Principal:** Catalyst Agent (ou Project Catalyst)
  - Apoio: Agents Architect (se envolver novos agentes), Creative Agent (UX), GOD user

- Fase 3 (Planejamento)
  - **Principal:** GOD user + GOD Ideas
  - Apoio: Catalyst, Code Assistant

- Fase 4 (Implementação)
  - **Principal:** Core Code Assistant (e variações)
  - Apoio: Catalyst, Docs Agent

- Fase 5 (Documentação)
  - **Principal:** Docs & Knowledge Agent
  - Apoio: Catalyst, Code

- Fase 6–7 (Operação & Insights)
  - **Principal:** Ops & Analytics Agent
  - Apoio: GOD Ideas, GOD user

- Fase 8 (Evolução)
  - **Principal:** GOD Ideas Agent
  - Apoio: Catalyst, Agents Architect, Ops & Analytics

---

## 5. Como este mapa deve ser usado

- Como **referência rápida**: quando estiver em dúvida sobre qual agente chamar.
- Como base para **telas futuras** do Agents Hub (um “org chart” de agentes).
- Como entrada para o **Agents Architect**, quando for:
  - criar novos agentes,
  - ou reorganizar o catálogo.

Se novos agentes CORE surgirem no futuro, este mapa deve ser atualizado
para manter uma visão clara do “time titular” do ecossistema.
