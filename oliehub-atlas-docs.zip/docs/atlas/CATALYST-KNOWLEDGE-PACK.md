# CatalystAgent – Knowledge Pack (v1)

Este arquivo é o **pacote único de conhecimento** do CatalystAgent.

Ele assume que, junto com ele, existem MAIS 4 documentos de referência:

1. `Núcleo & Atlas.md`  
   – Visão geral do Agents Hub, GOD user, fluxo GOD → GOD Ideas → Catalyst → Code → Ops,  
   – Mapa de fases do lifecycle (ideias, design, implementação, operação, evolução).

2. `core 1_agents.md`  
   – Definição do CORE de agentes (GOD Ideas, Catalyst, Core Code Assistant, Docs, Ops, Creative),  
   – Blueprint padrão de agente (metadados, role, goals, scope, inputs/outputs, tools, limitações),  
   – Exemplos de prompts e de uso por projeto.

3. `Camadas de agentes (Bloco C).md`  
   – Catálogo de famílias de agentes por domínio (técnico, criativo, educação, games, marketing, UX, multimodal),  
   – Quando ativar cada camada, exemplos de uso.

4. `Stack : Infra : IA : Deploy.md`  
   – Stack técnica base (Supabase, Vercel, ORMs, Auth),  
   – Dados, logs, automação de banco, segurança & RBAC, observability, IA & mídia, integrações, dev tools e deploy free/low-cost.

O CatalystAgent deve sempre usar este arquivo como mapa principal  
e consultar mentalmente esses 4 arquivos como “livros de referência” quando precisar de mais detalhe.


# Catalyst Knowledge Pack – Atlas Unificado de Agentes & Stack

> Este arquivo é o **pacote único de conhecimento** do CatalystAgent.  
> Aqui estão: visão do Agents Hub, núcleo de agentes, camadas de agentes por domínio,
> arquitetura de stack (Supabase, Vercel, IA, etc.), segurança, observabilidade,
> automação de IA, IA & mídia, dev tools e fluxo de projeto.

---

## 0. Visão Geral – Agents Hub & Catalyst

### 0.1. O que é o Agents Hub

O **Agents Hub** é o “meta-sistema” que organiza:

- ideias → projetos → sistemas/produtos → agentes → melhorias
- cada projeto pode ter:
  - código (GitHub, deploy),
  - agentes especializados,
  - backlog de ideias e melhorias,
  - histórico de decisões e evoluções.

O Hub guarda:

- **quem** (agentes, usuários),
- **faz o quê** (tarefas, domínios),
- **em qual projeto**,
- com **quais artefatos** (docs, blueprints, prompts, código).

### 0.2. Fluxo macro: da ideia ao sistema

Ciclo típico:

1. **IDEIA**  
   - Intuição, dor, oportunidade.
2. **PROJETO**  
   - A ideia ganha nome, objetivo, escopo inicial.
3. **SISTEMA / PRODUTO**  
   - Arquitetura, módulos, modelo de dados, integrações.
4. **AGENTES + IMPLEMENTAÇÃO**  
   - Code Assistant, DB Agent, UX, etc. implementam.
5. **MELHORIAS / BACKLOG**  
   - Novas ideias a partir do uso real, dados e feedback.

Esse ciclo é contínuo: um sistema maduro gera novas ideias.

### 0.3. Papel do CatalystAgent

O **CatalystAgent** vive na camada de IDEIA / DESIGN / PLANEJAMENTO:

- não implementa código;
- **organiza o caos da ideia**;
- cria:
  - briefs de projeto,
  - arquitetura conceitual,
  - lista de agentes necessários,
  - planos em fases,
  - Prompt Kits para outros agentes.

---

## 1. Núcleo de Agentes (Core & Catalysts)

### 1.1. GOD Ideas Agent – Visão Suprema

Papel:

- Representa a visão do “usuário GOD”:
  - propósito do ecossistema,
  - objetivos de longo prazo,
  - prioridades entre projetos,
  - princípios (éticos, técnicos, de negócio).

Responsabilidades:

- Manter um **“livro de visão”** com:
  - manifesto do ecossistema,
  - mapa de grandes projetos.
- Servir como fonte de verdade para o Catalyst:
  - quando há dúvida de direção,
  - registrar decisões estratégicas.
- Guardar decisões “irreversíveis”:
  - grandes mudanças de stack,
  - mudanças de foco de produto,
  - descontinuação de projetos.

### 1.2. Master Catalyst Agent – Catalisador de Ideias & Design

Papel:

- Transforma ideias em projetos claros e prontos para implementação.
- Trabalha ANTES do código.

Saídas típicas:

- `project-brief.md`  
  - problema, público, solução, escopo, riscos.
- `architecture-outline.md`  
  - módulos, dados, integrações em alto nível.
- `agents-blueprint.md`  
  - lista de agentes necessários (por camada).
- `prompt-kits-<projeto>.md`  
  - prompts prontos para Code Assistant, DB Agent, UX, etc.

Regras:

- Sempre começa perguntando, nunca assume demais.
- Não escreve código de produção; foca em design e arquitetura.
- Explicita:
  - assunções,
  - dúvidas abertas,
  - próximos passos.

### 1.3. Architect & Orchestrator – Arquiteto de Agentes

Papel:

- “Arquiteto de Agentes” – pensa o ecossistema de agentes como um sistema:

Responsabilidades:

1. Manter o **mapa de agentes**:
   - camadas (Cognitiva, Técnica, Criativa, Story, Música, Educação, Games, Marketing, UX, Multimodal),
   - agentes principais de cada camada,
   - relações com projetos e sistemas.

2. Definir padrões de agente:
   - Nome e propósito,
   - Entradas e saídas,
   - Limites (o que NÃO faz),
   - Relações (quem chama / quem é chamado).

3. Evoluir o catálogo:
   - evitar redundâncias,
   - propor fusões/divisões,
   - registrar mudanças.

### 1.4. Núcleo de agentes técnicos

Principais:

- **Systems Architect / ArchitectAI**  
  Tradução de visão em arquitetura técnica:
  - escolhe stack (ex.: React/Next + Supabase + Vercel),
  - desenha módulos backend/frontend,
  - modela entidades principais,
  - desenha integrações.

- **CodeAssistantAI**  
  Implementação de código guiado por blueprint:
  - cria arquivos, componentes, hooks, serviços,
  - refatora, melhora tipagem, adiciona testes.

- **EngenheiroDeDados / DB Agent**  
  Modelo de dados e SQL:
  - cria tabelas, relacionamentos, índices,
  - define migrações,
  - sugere triggers/funções,
  - recomenda RLS e policies.

- **IntegratorAI**  
  Integrações externas (pagamentos, ERPs, APIs sociais, etc.):
  - define contratos de API,
  - lida com erros e timeouts,
  - documenta integrações.

- **AuditorDeSistema**  
  Auditoria técnica:
  - segurança,
  - performance,
  - consistência de dados.

- **APIConnectorAI**  
  Conecta APIs específicas em libs reutilizáveis.

- **TestAutomationAI**  
  Estratégia e geração de testes.

- **DeployManagerAI**  
  Pipelines de deploy (Vercel, Supabase, GitHub Actions, etc.).

### 1.5. Hierarquia básica

1. GOD Ideas Agent – visão suprema  
2. Master Catalyst – transforma visão em projeto/arquitetura  
3. Architect & Orchestrator – desenha ecossistema de agentes  
4. Famílias de agentes por camada (Técnica, Criativa, UX, etc.)  
5. Agentes auxiliares (DevTools, Observability, Automation, etc.)

### 1.6. Processo padrão para criar um novo agente

1. **Definir necessidade**  
   - Qual problema ele resolve?
   - Já existe agente parecido?

2. **Passar pelo Master Catalyst**  
   - Refinar objetivo, entradas, saídas e limites.

3. **Passar pelo Architect & Orchestrator**  
   - Encaixar em uma camada,
   - definir relações com outros agentes.

4. **Criar blueprint**  
   - `agents/<nome>.md` com:
     - objetivo, inputs, outputs,
     - limites,
     - exemplos de uso.

5. **Registrar no Hub**  
   - projeto(s) em que atua,
   - status (experimental, estável, deprecated).

---

## 2. Camadas de Agentes por Domínio

### 2.1. Camada Cognitiva – Ideia & Direção

Papel: decidir **o que faz sentido construir**.

Agentes típicos:

- CatalisadorDeIdeias  
- ArquitetoSupremo  
- AtlasAI (router/orquestrador cognitivo)  
- PersonaAI (personas e públicos)  
- StrategyAI (estratégia de produto/negócio)  
- VisionAI (visão de longo prazo)  
- PromptArchitectAI (design de prompts e fluxos de instrução)

---

### 2.2. Camada Técnica – Arquitetura & Engenharia

Arquivo original: `agents-technical-architecture-layer.md`  

Agentes:

- Systems Architect / ArchitectAI  
- AI Systems Architect Generator  
- EngenheiroDeDados / DataEngineerAI  
- WebAppDevAI (fullstack)  
- IntegratorAI  
- AuditorDeSistema  
- EspecialistaRLS_RBAC  
- CodeAssistantAI  
- APIConnectorAI  
- TestAutomationAI  
- DeployManagerAI  

Uso: stack, módulos, banco, APIs, CI/CD.

---

### 2.3. Camada Criativa Visual

Arquivo original: `agents-creative-visual-layer.md`  

Agentes:

- VisualDesignerAI  
- UXBuilderAI (lado visual)  
- BrandDesignerAI (visual)  
- TextileAI / PatternAI  
- 3DDesignerAI / 3DModelAI  
- SceneComposerAI  
- ProductMockupAI  
- StyleTransferAI  

Uso: identidade visual, UI, telas, texturas, mockups, produtos.

---

### 2.4. Camada Audiovisual & Story

Arquivo original: `agents-audiovisual-story-layer.md`  

Agentes:

- NarradorAI / NarratorAI  
- DialogueCoachAI  
- WorldBuilderAI  
- CharacterDesignerAI  
- VisualDirectorAI / DirectorAI  
- ScriptWriterAI / StoryWriterAI  
- VideoCreatorAI  
- SoundDirectorAI  
- EmotionArchitectAI  
- CinematicComposerAI  

Uso: roteiros, histórias, vídeos, narrativa, emoção.

---

### 2.5. Camada Musical & Áudio

Arquivo original: `agents-musical-audio-layer.md`  

Agentes:

- MusicProducerAI  
- SoundComposerAI / ComposerAI  
- BeatMakerAI  
- VocalSynthAI / VoiceAI / VoiceCloneAI  
- MixMasterAI  
- LyricistAI  

Uso: trilhas, batidas, voz, mixagem, músicas para jogos/apps/campanhas.

---

### 2.6. Camada de Conhecimento & Educação

Arquivo original: `agents-learning-layer.md`  

Agentes:

- CurriculumAI  
- ResearchAI  
- EduTechAI  
- ContentSummarizerAI  
- TeacherAI / TutorAI  
- IndustrialProcessAI  
- DataAnalystAI (educacional)  
- QuizMakerAI  

Uso: cursos, trilhas educacionais, resumos de docs, quizzes, materiais de treinamento.

---

### 2.7. Camada de Games & Gamificação

Arquivo original: `agents-games-layer.md`  

Agentes:

- GameDesignerAI  
- GameStoryAI  
- LevelDesignerAI  
- AIBehaviorAI  
- GameDevAI  
- GamificationAI  
- SimulationAI  

Uso: game design, loops de engajamento, simulações e sistemas gamificados.

---

### 2.8. Camada de Marketing & Análise

Arquivo original: `agents-marketing-analytics-layer.md`  

Agentes:

- MarketingAI  
- CopyMasterAI  
- BrandDesignerAI (estratégico)  
- CommunityAI  
- SEOOptimizerAI  
- AnalyticsAI  
- BusinessPlannerAI  
- InvestorPitchAI  
- LegalAdvisorAI (rascunho; não substitui advogado real)

Uso: campanhas, funis, posicionamento, métricas, análise de negócio.

---

### 2.9. Camada de UX & Experiência

Arquivo original: `ux-layer-experiencia.md`  

Agentes:

- JourneyMapperAI / JourneyAI  
- FlowDesignerAI  
- InformationArchitectAI  
- UXResearchAI  
- InteractionAI  
- MicrocopyAI  
- AccessibilityAI  
- ConsistencyGuardianAI  

Uso: jornada ponta a ponta, fluxos, navegação, microcopy, acessibilidade, pesquisa com usuário.

---

### 2.10. Camada Multimodal / Experimental

Arquivo original: `multimodal-agents-experimental-layer.md`  

Agentes:

- ImageSenseAI  
- VideoSenseAI  
- StoryboardMultimodalAI  
- AudioSenseAI  
- VoiceOverDirectorAI  
- MultimodalOrchestratorAI  
- PrototypeXR_AI  

Uso: análise/geração com texto + imagem + áudio + vídeo, protótipos XR.  
Status: **experimental** (atenção a custo, privacidade, maturidade de modelos).

---

## 3. Stack Técnica & Infraestrutura

### 3.1. Backend Layer – Open Source Stack

- **DB & Backend-as-a-Service:** Supabase  
  - Postgres gerenciado  
  - Auth (email, magic link, OAuth)  
  - Storage (arquivos)  
  - Realtime  
  - Edge Functions

- **Frontend / Fullstack:**  
  - React / Next.js / Vite  
  - Tailwind / Design System

- **APIs & ORMs:**  
  - tRPC ou REST  
  - Prisma / Drizzle

- **Auth avançada:**  
  - Auth.js / NextAuth (quando necessário)

---

### 3.2. Data Management Layer

- Supabase Storage (imagens, docs, anexos).  
- Redis/Valkey (cache, filas leves).  
- Meilisearch (busca full-text).  
- Logs de app (via Observability Layer).  
- Backups (PgBackRest / supabase backups).

Uso: garantir que arquivos, conteúdo e logs estejam organizados e acessíveis.

---

### 3.3. Database & Automation Layer

- **Schema Manager**  
  - desenho do modelo de dados (tabelas, relações, índices).

- **Migration Runner**  
  - migrações versionadas (Prisma Migrate, Drizzle, SQL).

- **Triggers & Funções**  
  - ex.: atualizar `inventory_balances` ao inserir em `inventory_movements`,  
  - criar `finance_receivable` ao confirmar um pedido.

- **Jobs baseados em DB**  
  - tabelas `jobs` / `scheduled_tasks`,
  - workers que rodam tarefas periódicas.

- **Data Quality Checks**  
  - queries para encontrar inconsistências,
  - views de auditoria.

---

### 3.4. Security & RBAC + No-Code Auth

**Security & RBAC (técnico):**

- RLS no Supabase.  
- Tabela `config_roles` + policies.  
- Audit trail em `logs_actions` + triggers.  
- Session Manager (middleware/Auth.js).

**No-Code Auth & Security:**

- Supabase Auth / Clerk / Auth0 etc. (telas prontas, social login).  
- Roles simples (admin/user/guest).  
- Verificação e recuperação (email, magic link, OTP).  
- Proteção básica (rate limiting, captcha, filtros de IP).

Uso:  
- MVPs e demos podem usar auth no-code simples;  
- produção séria deve usar RBAC técnico robusto + audit trail.

---

### 3.5. Observability Layer

- OpenTelemetry + Prometheus – métricas.  
- Grafana – dashboards.  
- Sentry – erros.  
- Umami – analytics de uso web.

Objetivo: ver o que está acontecendo, detectar erros cedo, entender uso.

---

### 3.6. Intelligence & AI Integration

- **AI Gateway**  
  - centraliza acesso a OpenAI, Gemini e outros modelos.

- **Orquestração de IA**  
  - LangChain.js  
  - LangGraph  
  - CrewAI

- **Vector DB**  
  - Supabase Vector  
  - Weaviate CE (opcional)

- **Job Scheduler**  
  - BullMQ + Redis

Uso: agentes podem fazer retrieval, pipelines de IA, fluxos multi-step.

---

### 3.7. IA & Mídia – Integração com conteúdo multimídia

- Pipelines com FlowiseAI / n8n / Make.  
- Geração de imagem: Stable Diffusion, Leonardo etc.  
- Geração/edição de vídeo: Pika, Runway etc.  
- Música: Suno, Udio etc.  
- 3D: Poly.cam, Three.js, Blender API.

Fluxos típicos:

- “roteiro → capturas → vídeo tutorial → thumb → publicação”.  
- “aula em texto → slides → vídeo narrado → quiz”.

---

### 3.8. API & Integrações

- Google Drive / Sheets.  
- AtlasAI / CrewAI APIs.  
- WhatsApp / Telegram (omnichannel).  
- Email (Resend, Mailpit).  
- CMS (Payload, Strapi).  

Uso: conectar sistemas do ecossistema a ferramentas externas.

---

### 3.9. Dev Tools & Ambiente Local

- VS Code.  
- Docker / Docker Compose.  
- Supabase CLI (local).  
- Node (nvm/fnm/volta).  
- Vitest/Jest, ESLint, Prettier.

Recomendação: cada projeto ter um `dev-environment.md` documentando setup local.

---

### 3.10. Deploy & Infra Free / Low-Cost

- Vercel (hosting frontend/fullstack).  
- Supabase (DB/Auth/Storage).  
- Resend (emails).  
- Sentry (erros).  
- Umami (analytics).  
- GitHub Actions / Vercel Cron (jobs leves).

Uso: permitir que novos projetos sejam lançados com custo quase zero, evoluindo para planos pagos conforme necessidade.

---

## 4. Processo de Projeto & Uso de Prompts

### 4.1. Ciclo de Projeto (simplificado)

1. **Discovery com CatalystAgent**  
   - entender ideia, problema, público, contexto,
   - gerar `project-brief.md`.

2. **Arquitetura Conceitual**  
   - módulos, dados, integrações,
   - mapear camadas de agentes envolvidas.

3. **Definição de Agentes & Blueprints**  
   - quais agentes já existentes serão usados,  
   - quais novos precisam ser criados.

4. **Plano em Fases**  
   - Fase 1 (MVP), Fase 2, Fase 3…  
   - cada fase com entregas claras.

5. **Prompt Kits**  
   - prompts específicos para:
     - Code Assistant (implementação),
     - DB Agent (modelo de dados/migrações),
     - UX Agents (fluxos/jornadas),
     - outros especialistas.

6. **Entrega & Evolução**  
   - usar observability + feedback para gerar novas ideias,  
   - reabrir ciclo no CatalystAgent.

### 4.2. Exemplos de Prompt Kits (esqueleto)

- **Para Code Assistant:**  
  - contexto do projeto,  
  - módulos/arquivos-alvo,  
  - padrão de código e stack.

- **Para DB Agent:**  
  - entidades, relações, regras de negócio,  
  - tipos de consulta que serão necessárias,  
  - preocupações de performance/segurança.

- **Para UX / Visual:**  
  - personas, jornadas, principais tarefas,  
  - tom de marca, referências visuais.

---

Este arquivo é o **pacote único de conhecimento** do CatalystAgent.  
Ele descreve o mapa (Atlas), os agentes, as camadas e a stack base.

O CatalystAgent deve:

- usar este conhecimento como referência,
- nunca “inventar stack aleatória” quando já existe padrão,
- sempre transformar ideias em projetos claros, arquiteturas coerentes e planos executáveis por outros agentes.
