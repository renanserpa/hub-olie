# Ecosystem Glossary – Agents Hub & Projects

> Glossário de termos que usamos no ecossistema de agentes, projetos e sistemas.
> Serve para humanos e agentes terem o mesmo vocabulário.

---

## Papéis Humanos

### GOD user
Pessoa “dona” da visão e da estratégia. Decide:
- quais projetos existem,
- quais agentes devem ser criados/usados,
- prioridades e direção geral.

Pode falar com qualquer agente, mas idealmente segue os playbooks do Agents Hub.

### Stakeholder
Qualquer pessoa interessada em um projeto (cliente, usuário final, time interno, etc.).

### Dev / Engenheiro
Pessoa responsável por:
- revisar e aplicar código gerado pelos agentes,
- criar integrações, infra, pipelines, etc.

---

## Estruturas do Ecossistema

### Agents Hub
Sistema meta onde:
- registramos projetos,
- registramos agentes (CORE e específicos),
- guardamos ideias/backlog,
- estruturamos conhecimento (docs, domínios),
- acompanhamos a evolução dos agentes.

É o “hub de projetos, agentes e ideias”.

### Projeto (Project)
Uma iniciativa concreta:
- pode ser um sistema (ex.: OlieHub),
- um produto digital,
- um site,
- um app,
- ou uma ferramenta interna.

Tem:
- objetivos,
- stack técnica,
- agentes associados,
- backlog de ideias.

### Sistema / Produto / App
Implementação concreta de um projeto:
- código,
- deploy,
- usuários reais.

### Domínio
Área de conhecimento do mundo real ligada a um projeto.
Exemplos:
- ateliê de costura (manufatura sob demanda),
- financeiro,
- educação,
- logística.

---

## Agentes e Camadas

### Agente
Qualquer “persona de IA” com:
- papel definido,
- objetivos claros,
- escopo específico,
- entradas/saídas típicas.

Exemplos:
- Catalyst Agent,
- Core Code Assistant,
- GOD Ideas Agent,
- Ops & Analytics Agent,
- Creative Experience Agent.

### CORE de Agentes
Conjunto de agentes “base” que podem apoiar qualquer projeto.
Exemplos:
- Catalyst Agent (ideias & arquitetura),
- Core Code Assistant (implementação),
- GOD Ideas Agent (backlog),
- Docs & Knowledge Agent (documentação),
- Ops & Analytics Agent (insights),
- Creative Experience Agent (design & conteúdo).

### Project Catalyst
Versão especializada do Catalyst para um projeto específico.
Exemplo:
- `agents-hub-catalyst-agent`,
- `oliehub-catalyst-agent`.

### Agents Architect & Orchestrator (God of Agents)
Agente responsável por:
- pensar a arquitetura do ecossistema de agentes,
- definir novos agentes,
- evitar duplicação,
- sugerir quais agentes usar em cada projeto.

---

## Documentos & Estruturas de Conhecimento

### Blueprint de Agente
Documento `.md` que descreve um agente:
- metadados (id, name, scope, version, status),
- role (papel),
- goals (objetivos),
- scope / out_of_scope,
- inputs / outputs,
- ferramentas / integrações,
- notas de segurança,
- exemplos de prompts,
- ideias de evolução.

### Knowledge / Conhecimento
Conjunto de arquivos com:
- visão de projetos,
- domínios (ex.: manufatura de ateliê),
- stack técnica,
- padrões,
- playbooks de interação.

### Playbook
Documento que descreve um fluxo/roteiro de trabalho.
Exemplos:
- como iniciar um novo projeto,
- como criar um novo módulo,
- como criar um novo agente.

### ADR (Architecture Decision Record) simplificado
Registro de uma decisão de arquitetura importante.
Contém:
- contexto,
- decisão,
- alternativas,
- consequências.

---

## Ideias, Backlog e Trabalho

### Idea / Ideia
Unidade básica de pensamento no backlog.
Pode ser:
- nova feature,
- melhoria,
- refactor,
- novo agente,
- experimento,
- conteúdo.

### Backlog
Lista organizada de ideias/iniciativas:
- com status (rascunho, pronto para design, em progresso…),
- com prioridade,
- ligada a projeto(s).

### Task / Tarefa
Trabalho mais granular derivado de ideias.
Exemplo:
- implementar endpoint X,
- ajustar layout Y,
- criar doc Z.

---

## Tecnologias (Resumo conceitual)

### Supabase
Backend-as-a-Service com Postgres, Auth, Realtime, Storage, Functions.

### Vercel
Plataforma de deploy de frontends e funções serverless/edge.

### Gemini / Google AI
Modelos de linguagem usados para diversos agentes (code, análise, criativos, etc.).

### GitHub
Repositórios de código, issues, PRs, automações de CI/CD.

### React / Vite / TypeScript / Tailwind
Stack típica de frontends:
- React para UI,
- Vite para build/dev,
- TypeScript para tipagem,
- Tailwind para estilos.

---

## Vocabulário de Fluxos

### Ideia → Projeto → Sistema
Fluxo natural:
1. Ideia nasce (GOD user ou agente).
2. Ideia é organizada (GOD Ideas Agent).
3. Vira Projeto (quando ganha foco e escopo).
4. Vira Sistema (quando ganha código, deploy e usuários).

### v1 / MVP
Primeira versão utilizável de um sistema/módulo/feature/agent.
Foco em:
- resolver o essencial,
- aprender rápido,
- evitar overengineering.

### Refactor
Reorganização de código/arquitetura sem mudar (muito) o comportamento visível.
Objetivo:
- deixar mais limpo,
- reduzir bugs,
- facilitar novas features.

---

## Outros Termos Úteis

### Módulo
Parte de um sistema com foco próprio:
- ex.: módulo de pedidos, módulo de produção, módulo de billing.

### Frente
Conjunto de trabalhos/ideias organizados por tema ou área:
- ex.: frente de UX, frente de performance, frente de integrações.

### Time de agentes
Conjunto de agentes que atuam juntos em um projeto ou fluxo:
- ex.: Catalyst + Code + Docs + Creative em um novo módulo.

Se surgirem novos termos recorrentes, este glossário deve ser atualizado.

# Interaction Guidelines – Como Conversar com os Agentes

> Este documento define como o GOD user (e futuros usuários) devem interagir com o
> ecossistema de agentes para obter o melhor resultado.

Ele também serve para que os próprios agentes entendam o “estilo de trabalho” esperado.

---

## 1. Princípios Gerais

1. **Sempre dar contexto mínimo**
   - Projeto em questão (ex.: Agents Hub, OlieHub, outro).
   - Objetivo da conversa (ex.: nova feature, refactor, agente novo).
   - Fase aproximada (ideia, design, implementação, operação).

2. **Trabalhar em etapas**
   - Evitar pedir “faça tudo de uma vez”.
   - Preferir:
     - entender → perguntar → planejar → executar.

3. **Permitir perguntas dos agentes**
   - É desejável que agentes como o Catalyst perguntem antes de propor soluções.
   - Perguntas ajudam a evitar suposições erradas.

4. **Evitar misturar muitos objetivos numa mesma mensagem**
   - Melhor separar:
     - conversa de ideação,
     - conversa de design,
     - conversa de implementação.

5. **Confirmar entendimento em pontos críticos**
   - Se o resultado de uma decisão é grande (alterar arquitetura, criar novo agente),
     - pedir um resumo de entendimento,
     - revisar antes de seguir.

---

## 2. Quando usar qual agente

### 2.1. GOD Ideas & Backlog Agent

Use quando:
- Quer despejar ideias soltas.
- Quer estruturar backlog.
- Quer priorizar ideias.
- Quer ver quais ideias estão prontas para design.

### 2.2. Agents Architect & Orchestrator

Use quando:
- A ideia envolve **novos agentes** ou mudança em agentes existentes.
- Quer saber qual “time de agentes” usar em um novo projeto.
- Quer organizar/limpar o catálogo de agentes.

### 2.3. Catalyst Agent (ou Project Catalyst)

Use quando:
- A ideia está madura o suficiente para virar:
  - módulo,
  - sistema,
  - fluxo,
  - ou pacote de features.
- Você quer:
  - requisitos claros,
  - arquitetura proposta,
  - plano em etapas.

### 2.4. Core Code Assistant

Use quando:
- Já existe um plano claro (do Catalyst ou de você).
- Quer implementar uma etapa específica.
- Quer refatorar código seguindo diretrizes.
- Quer integrar algo com Supabase / APIs.

### 2.5. Docs & Knowledge Agent

Use quando:
- Quer gerar ou atualizar documentação.
- Quer registrar decisões tomadas.
- Quer resumos para onboarding.

### 2.6. Ops & Analytics Agent

Use quando:
- Tem dados, métricas, logs.
- Quer entender gargalos e oportunidades técnicas/operacionais.

### 2.7. Creative Experience Agent

Use quando:
- Precisa de:
  - telas e UX,
  - textos de marketing,
  - roteiros,
  - materiais de apresentação,
  - ideias visuais/sonoras.

---

## 3. Estrutura sugerida de mensagens

### 3.1. Moldura básica

Ao iniciar uma conversa sobre um tema novo com um agente, use algo como:

```text
Projeto: [nome do projeto, ou "multi-projeto"]

Objetivo principal desta conversa:
[ex.: desenhar um novo módulo, organizar backlog, criar um agente, etc.]

Contexto rápido:
[2–5 frases explicando a situação]

O que eu quero de você agora:
[ex.: me fazer perguntas, organizar requisitos, propor arquitetura, etc.]
```

### 3.2. Exemplo para Catalyst

```text
Projeto: Agents Hub

Objetivo desta conversa:
Desenhar o módulo de cadastro e visualização de projetos.

Contexto rápido:
Já definimos o modelo conceitual de projects/agents/ideas.
Agora quero uma tela e fluxo para CRUD de projects, com boa UX.

O que eu quero de você agora:
1) Reescrever o que você entendeu.
2) Me fazer 5–8 perguntas.
3) Depois das respostas, propor requisitos, arquitetura front/back e um plano em etapas.
```

### 3.3. Exemplo para Core Code Assistant

```text
Projeto: Agents Hub
Stack: React + Vite + TS + Supabase

Contexto:
O Catalyst já propôs o plano abaixo para o módulo de projects:
[cole o plano]

Escopo desta etapa:
Implementar apenas o Step 1: listar projetos existentes em uma página.

O que eu quero de você agora:
1) Dizer quais arquivos pretende criar/editar.
2) Sugerir a estrutura básica dos componentes/hooks/services.
3) Implementar o Step 1.
4) No final, listar os arquivos alterados e resumir o que foi feito.
```

---

## 4. Boas práticas de uso contínuo

1. **Guardar prompts que funcionaram bem**
   - Sempre que uma interação der muito certo, salvar aquele prompt em `prompt-kits.md`.

2. **Referenciar documentos de conhecimento**
   - Ex.: “Conforme `agents-hub-data-model-conceptual.md`…”,  
     ou “Use o glossário em `ecosystem-glossary.md` para manter a mesma linguagem.”

3. **Evitar depender da memória da conversa para decisões críticas**
   - Quando uma decisão for importante:
     - peça para o Docs Agent gerar um ADR ou um resumo e salve em markdown.

4. **Fechar ciclos**
   - Se algo foi só planejado, marcar como tal.
   - Se foi implementado, pedir para o Docs Agent atualizar as docs e para o Ops Agent observar.

---

## 5. O que os agentes devem esperar de você (GOD user)

- Clareza sobre:
  - qual projeto,
  - qual objetivo,
  - qual horizonte (v1, v2, longo prazo).

- Disponibilidade para:
  - responder perguntas,
  - escolher entre opções,
  - aprovar planos antes de implementar.

- Input honesto sobre:
  - o que ficou bom,
  - o que precisa melhorar,
  - quais estilos de resposta funcionam melhor para você.

---

## 6. O que você pode esperar dos agentes

- Que perguntem quando o contexto não estiver claro.
- Que proponham alternativas e expliquem trade-offs.
- Que dividam o trabalho em etapas pequenas e rastreáveis.
- Que atualizem ou apontem para os documentos corretos quando fizerem algo importante.

---

## 7. Atualizações futuras

Estas diretrizes podem ser refinadas conforme:

- novos agentes entrarem no ecossistema,
- você identificar padrões de interação que funcionam muito bem,
- ou notar comportamentos que valem ser reforçados (ou evitados).

Sempre que ajustar este documento, considere também atualizar `prompt-kits.md`
com novos exemplos concretos.

# Arquitetura de Conhecimento – Agents Hub & Projetos (v1)

> Este documento define **como organizar o conhecimento** dentro do ecossistema:
> - por projeto,
> - por domínio (ex.: manufatura, costura, bordado),
> - por agente,
> - e como reaproveitar isso em novos projetos.

A ideia é que, com o tempo, o Agents Hub se torne uma **grande biblioteca estruturada**, onde:
- cada projeto contribui com conhecimento específico,
- cada domínio (ex.: ateliê de costura) vira um “pacote de conhecimento”,
- e os agentes sabem como usar esse material.

---

## 1. Tipos de Conhecimento no Ecossistema

Vamos considerar quatro camadas principais de conhecimento:

1. **Conhecimento Global (Core / Plataforma)**
   - conceitos que se aplicam a vários projetos:
     - arquitetura de agentes,
     - modelo de dados do Agents Hub,
     - stack de tecnologias (Supabase, Vercel, Gemini, etc.),
     - padrões de prompts (prompt-kits),
     - boas práticas de desenvolvimento, UX, ops.

2. **Conhecimento de Projeto**
   - documentação específica de cada projeto/sistema:
     - visão geral do produto,
     - módulos,
     - fluxos,
     - decisões de arquitetura,
     - integrações,
     - backlog relevante.

3. **Conhecimento de Domínio**
   - conhecimento do “mundo real” para o qual o sistema existe:
     - no caso do OlieHub:
       - manufatura sob demanda,
       - operação de ateliê,
       - tipos de máquinas,
       - etapas de produção,
       - papéis (costureira, bordadeira, logística, etc.).
     - em outro projeto, poderia ser:
       - educação, saúde, logística, finanças, etc.

4. **Conhecimento de Agente**
   - blueprints e materiais específicos para cada agente:
     - escopo, responsabilidades,
     - tipos de entrada/saída,
     - integrações,
     - exemplos de uso,
     - dicas de como conversar com esse agente.

---

## 2. Estrutura Sugerida de Pastas / Arquivos

Uma forma simples e escalável de organizar isso em um repositório (ou área de knowledge) é:

```text
knowledge/
  stack-links.md                  # Tecnologias globais do ecossistema
  prompt-kits.md                  # Kits de prompts globais
  agents-hub-overview.md          # Visão geral do Agents Hub
  agents-hub-data-model-conceptual.md
  agents-core.md                  # Core de agentes
  agents-architect-agent.md
  catalyst-agent.md
  god-ideas-agent.md
  core-code-assistant.md
  ... (outros blueprints globais)

  projects/
    oliehub/
      oliehub-overview.md         # Visão geral do OlieHub
      oliehub-architecture.md     # Módulos, fluxos, integrações
      oliehub-status-roadmap.md   # Fases, versões, backlog macro
      domain/
        atelier-manufacturing-overview.md
        sewing-machines-basics.md
        embroidery-machines-basics.md
        production-workflow-atelier.md
        quality-control-atelier.md
      agents/
        oliehub-catalyst-agent.md
        oliehub-code-assistant.md
        oliehub-ops-agent.md
        ... (quando existirem)
      prompts/
        oliehub-specific-prompts.md
        oliehub-support-scenarios.md

    agents-hub/
      agents-hub-overview.md      # já existe, pode ser referenciado aqui
      agents-hub-ux-ideas.md
      agents-hub-roadmap.md
      agents-hub-agents-mapping.md

    outro-projeto/
      ...

```

Isso permite:

- separar claramente o que é **global** do que é **por projeto**;
- dentro de cada projeto, separar:
  - visão do sistema,
  - domínio do negócio,
  - agentes daquele projeto,
  - prompts específicos.

---

## 3. Conhecimento de Domínio – Exemplo: Ateliê / OlieHub

Quando o OlieHub estiver mais maduro, podemos ter um pacote de domínio, por exemplo:

### 3.1. `atelier-manufacturing-overview.md`

- visão geral da operação de um ateliê:
  - tipos de produto,
  - fluxo de pedido → produção → expedição,
  - principais papéis (costureira, bordadeira, cortador, etc.).

### 3.2. `sewing-machines-basics.md`

- tipos de máquinas de costura,
- capacidades,
- limitações,
- manutenção básica,
- como isso impacta:
  - tempo de produção,
  - qualidade,
  - restrições técnicas.

### 3.3. `embroidery-machines-basics.md`

- tipos de máquinas de bordado,
- bastidores, fios, tipos de ponto,
- tempos por área de bordado,
- como isso dialoga com:
  - cadastro de produtos,
  - capacidade produtiva,
  - filas de produção.

### 3.4. `production-workflow-atelier.md`

- passo a passo da produção:
  - receber pedido,
  - confirmação de arte,
  - preparação de aviamentos/tecidos,
  - costura,
  - bordado,
  - inspeção,
  - embalagem,
  - expedição.

Tudo isso vira **base de conhecimento** não só para o OlieHub, mas para:

- futuros sistemas de manufatura personalizados,
- agentes especialistas em operações de ateliê,
- agentes de planejamento de capacidade, etc.

---

## 4. Como os Agentes Usam esse Conhecimento

### 4.1. Catalyst Agent

- Quando desenha módulos de produção para o OlieHub (ou sistemas similares), pode:
  - consultar os arquivos de domínio (`atelier-manufacturing-overview.md`, etc.),
  - entender restrições reais (máquinas, tempos, qualidade),
  - propor fluxos e dados mais aderentes à realidade.

### 4.2. GOD Ideas Agent

- Pode usar conhecimento de domínio para:
  - enriquecer ideias (ex.: “essa ideia afetaria o fluxo de costura e bordado?”),
  - sugerir tags e classificações (ex.: `produção`, `logística`, `máquinas`).

### 4.3. Core Code Assistant

- Usa esse conhecimento mais indiretamente:
  - ao implementar features descritas pelo Catalyst, sabe que existem conceitos de domínio que precisam ser respeitados (campos, regras, validações).

### 4.4. Creative Experience Agent

- Pode usar o pacote de domínio para:
  - criar telas, materiais, textos e imagens que falem a linguagem do ateliê,
  - produzir catálogos, apresentações e materiais comerciais para o Ateliê Olie,
  - gerar conteúdos que façam sentido para o público final (clientes do ateliê).

### 4.5. Ops & Analytics Agent

- Pode usar domínio para interpretar métricas:
  - taxa de retrabalho,
  - tempo médio de produção por tipo de peça,
  - gargalos por tipo de máquina,
  - sazonalidade de pedidos.

---

## 5. Reuso em Outros Projetos

O grande benefício de organizar o conhecimento assim é o **reaproveitamento**:

- O conhecimento de **manufatura de ateliê** pode ser útil em:
  - outros ERPs de produção,
  - sistemas de planejamento de capacidade,
  - chatbots de suporte para operadores.

- O conhecimento de **stack técnica** (Supabase, Vercel, etc.) já está em `stack-links.md`,
  - e pode ser usado por qualquer projeto que compartilhe essas tecnologias.

- O conhecimento sobre **padrões de agentes** (agents-core, blueprints) é global,
  - e toda vez que um novo projeto nasce, ele já parte dessa base.

---

## 6. Boas Práticas para Criar Novos Documentos de Conhecimento

1. **Um arquivo = um tema claro**
   - Evitar documentos gigantes com tudo misturado.
   - Melhor ter vários arquivos menores bem nomeados.

2. **Nomear de forma explícita**
   - `atelier-manufacturing-overview.md` (claro e descritivo),
   - em vez de `anotacoes-aleatorias.md`.

3. **Sempre incluir:**
   - contexto (onde isso se aplica),
   - termos importantes (glossário mínimo),
   - exemplos práticos.

4. **Tagging / referências internas**
   - no começo do documento, referenciar outros arquivos relevantes:
     - “Relacionado a: `oliehub-overview.md`, `stack-links.md`…”


5. **Pensar nos agentes como leitores**
   - Escrever de forma que um agente (Catalyst, Creative, Ops) consiga usar aquilo.
   - Explicar conceitos-chave e relações com o sistema.

---

## 7. Próximos Passos Práticos

1. **Para o Agents Hub:**
   - Já temos vários arquivos globais (core de agentes, modelo de dados, stack, prompt-kits).
   - Próximo passo é criar:
     - `agents-hub-ux-ideas.md` (ideias de UX do próprio hub),
     - `agents-hub-roadmap.md` (fases de entrega).

2. **Para o OlieHub (quando focarmos nele):**
   - Criar pelo menos:
     - `oliehub-overview.md` (já existe em parte, podemos consolidar),
     - `atelier-manufacturing-overview.md`,
     - `sewing-machines-basics.md`,
     - `embroidery-machines-basics.md`,
     - `production-workflow-atelier.md`.

3. **Para cada novo projeto:**
   - criar uma pastinha em `knowledge/projects/<nome-do-projeto>/`,
   - começar com `overview.md` + uma pasta `domain/`,
   - deixar os agentes ajudarem a detalhar.

Este documento serve como referência para você (GOD user) e para o **Agents Architect / Catalyst**,  
quando forem decidir **como e onde** guardar o próximo pedaço de conhecimento que nascer.

# Naming Conventions – Projects, Agents, Files & Knowledge

> Este documento define convenções de nomes para manter o ecossistema organizado,
> facilitar reuso entre projetos e ajudar agentes a criarem coisas de forma consistente.

---

## 1. Projetos

### 1.1. Slug de Projeto

- Formato: `kebab-case`
- Exemplo:
  - `agents-hub`
  - `oliehub`
  - `marketing-portal`
  - `atelier-ops`

`slug` deve ser curto, descritivo e estável ao longo do tempo.

### 1.2. Nome Amigável

- Pode ter espaços e letras maiúsculas.
- Exemplos:
  - “Agents Hub”
  - “OlieHub Ops Platform”
  - “Portal de Marketing”

---

## 2. Agentes

### 2.1. ID lógico de agente (`agent_key`)

- Formato: `kebab-case` com sufixo `-agent` quando fizer sentido.
- Exemplo:
  - `catalyst-agent`
  - `god-ideas-agent`
  - `core-code-assistant`
  - `agents-architect-agent`
  - `creative-experience-agent`

### 2.2. Agentes específicos de projeto

- Formato sugerido: `<project-slug>-<role>-agent`
- Exemplos:
  - `oliehub-catalyst-agent`
  - `oliehub-code-assistant`
  - `agents-hub-catalyst-agent`

Quando fizer sentido, o agente específico de projeto deve ter um campo `base_agent_id`
apontando para o agente CORE do qual ele deriva.

### 2.3. Nome exibido

- Formato mais humano, ex.:
  - “Catalyst Agent”
  - “GOD Ideas & Backlog Agent”
  - “OlieHub Code Assistant”

---

## 3. Arquivos de Knowledge

### 3.1. Estrutura básica

Sugestão de organização:

```text
knowledge/
  stack-links.md
  prompt-kits.md
  ecosystem-glossary.md
  project-lifecycle.md
  naming-conventions.md
  interaction-guidelines.md
  knowledge-architecture.md
  agents-hub-overview.md
  agents-hub-data-model-conceptual.md
  agents-core.md
  ...

  agents/
    catalyst-agent.md
    god-ideas-agent.md
    core-code-assistant.md
    agents-architect-agent.md
    ...

  projects/
    <project-slug>/
      <project-slug>-overview.md
      <project-slug>-architecture.md
      <project-slug>-status-roadmap.md
      domain/
        ... (arquivos de domínio)
      agents/
        <project-slug>-catalyst-agent.md
        <project-slug>-code-assistant.md
        ... (outros)
      prompts/
        <project-slug>-specific-prompts.md
```

### 3.2. Padrão de nomes para arquivos

- Visão geral de um projeto:
  - `<project-slug>-overview.md`
- Arquitetura de um projeto:
  - `<project-slug>-architecture.md`
- Roadmap / status de um projeto:
  - `<project-slug>-status-roadmap.md`

- Arquivo de domínio:
  - `atelier-manufacturing-overview.md`
  - `sewing-machines-basics.md`
  - `embroidery-machines-basics.md`

- Blueprint de agente:
  - `<agent-key>.md`
  - Ex.: `catalyst-agent.md`, `god-ideas-agent.md`, `core-code-assistant.md`

- Playbooks:
  - `playbooks-new-project.md`
  - `playbooks-new-module.md`
  - `playbooks-new-agent.md`

---

## 4. Código (visão geral)

Cada projeto pode ter suas particularidades, mas recomenda-se um padrão geral:

### 4.1. Pastas principais (frontend React/Vite)

- `src/components/` – componentes de UI.
- `src/pages/` – páginas/rotas da aplicação.
- `src/hooks/` – hooks reutilizáveis.
- `src/contexts/` – contexts (React Context API).
- `src/services/` – chamadas a APIs, lógica de integração (Supabase, HTTP, etc.).
- `src/lib/` – helpers, clientes (ex.: `supabaseClient`).
- `src/types/` – tipos TypeScript compartilhados.
- `src/styles/` – estilos globais, se necessário.

### 4.2. Nomes de componentes React

- PascalCase para componentes:
  - `MainLayout`, `LoginPage`, `ProjectList`, `IdeaBoard`.
- arquivos `.tsx` com o mesmo nome do componente principal.

### 4.3. Nomes de hooks

- `use<Nome>` em camelCase:
  - `useProjects`, `useIdeas`, `useAuth`, `useSupabaseClient`.

### 4.4. Nomes de serviços

- `*Service.ts` ou nomes específicos claros:
  - `projectService.ts`, `ideaService.ts`, `authService.ts`.

---

## 5. Banco de Dados (conceitual)

Embora o SQL possa variar, alguns padrões de nomes ajudam:

- Tabelas em `snake_case`:
  - `projects`, `agents`, `agent_versions`, `ideas`, `conversations`.
- Colunas:
  - `created_at`, `updated_at` para timestamps,
  - `project_id`, `agent_id`, etc. para FKs,
  - enums textuais simples para `status`, `type` etc.

---

## 6. Como os agentes devem usar estas convenções

### 6.1. Catalyst Agent

- Ao propor novos módulos/arquivos:
  - usar convenções de nomes sugeridas aqui,
  - sugerir paths alinhados (`src/hooks/useX`, `knowledge/projects/<slug>/...`).

### 6.2. Core Code Assistant

- Ao criar arquivos de código:
  - seguir convenções de pasta e nomes,
  - evitar criar múltiplos estilos misturados.

### 6.3. Docs & Knowledge Agent

- Ao criar novos arquivos de conhecimento:
  - usar prefixos claros,
  - seguir a estrutura `knowledge/`,
  - evitar nomes genéricos como `anotacoes.md`.

### 6.4. Agents Architect

- Ao gerar novos blueprints:
  - respeitar a convenção de IDs (`agent_key`),
  - salvar como `<agent-key>.md`,
  - apontar no cadastro lógico (`agents.agent_key`).

---

## 7. Ajustes e Evolução

Estas convenções podem evoluir, mas:
- mudanças devem ser raras,
- e idealmente registradas em um ADR (decisão) simples.

Sempre que uma convenção mudar:
- atualizar este documento,
- informar os agentes (por exemplo, via comentário em uma conversa),
- ajustar futuras criações para seguirem o padrão novo.

# Playbook – Novo Projeto no Agents Hub (v1)

> Roteiro passo a passo para criar um **novo projeto** dentro do ecossistema
> e já conectá-lo ao time de agentes.

Este playbook é para o GOD user, mas os agentes podem usá-lo como referência de fluxo.

---

## 1. Definir a ideia base do projeto

**Objetivo:** ter uma descrição clara o suficiente para ser registrada como projeto.

1. Fale com o **GOD Ideas & Backlog Agent**:
   - Descreva a ideia em texto livre.
   - Diga se ela é:
     - um produto novo,
     - um sistema interno,
     - uma evolução grande de algo existente.

2. Peça a ele para:
   - estruturar a ideia,
   - sugerir tipo (produto, internal tool, experimento),
   - indicar se está pronta para virar projeto.

3. Se a ideia for aprovada como projeto:
   - defina um nome amigável,
   - e um `slug` seguindo `naming-conventions.md`.

**Saída:**  
- Uma `idea` marcada como base de um novo `project`.

---

## 2. Registrar o Projeto no Agents Hub

**Objetivo:** criar o registro conceitual do projeto.

1. Criar (ou pedir para um agente descrever) os campos principais de `projects`:
   - `name`,
   - `slug`,
   - `description`,
   - `type` (`product`, `internal_tool`, `experiment`),
   - `status` inicial (ex.: `discovery` ou `planning`),
   - stack sugerida (ex.: “React + Supabase + Vercel”).

2. Criar/atualizar o arquivo de knowledge do projeto:
   - `knowledge/projects/<project-slug>/<project-slug>-overview.md`

   Conteúdo mínimo:
   - visão geral,
   - objetivos,
   - público-alvo,
   - problemas que resolve,
   - MVP desejado.

3. (Opcional) Registrar a conversa de inception em `conversations`:
   - título,
   - resumo,
   - link para chat/doc.

**Saída:**  
- Registro inicial em `projects` (conceitual ou já em banco).
- Arquivo `<project-slug>-overview.md` criado.

---

## 3. Definir o time inicial de agentes do projeto

**Objetivo:** escolher quais agentes vão atuar na v1 do projeto.

1. Falar com o **Agents Architect & Orchestrator**:

   ```text
   Tenho um novo projeto chamado [nome / slug].
   Aqui está o overview: [resumo ou link].
   Me ajude a definir o time inicial de agentes para este projeto,
   com base no nosso CORE.
   ```

2. O Agents Architect deve sugerir:
   - uso de:
     - GOD Ideas Agent (sempre),
     - Project Catalyst (derivado do Master),
     - Code Assistant específico do projeto (derivado do Core),
     - Docs Agent (global ou específico),
     - Creative Agent (se fizer sentido),
     - Ops Agent (quando houver operação real).
   - se necessário, propor novos agentes específicos.

3. Criar (ou ao menos planejar) blueprints:
   - `knowledge/projects/<project-slug>/agents/<project-slug>-catalyst-agent.md`
   - `knowledge/projects/<project-slug>/agents/<project-slug>-code-assistant.md`
   - etc.

**Saída:**  
- Lista de agentes do projeto.
- Blueprints iniciais criados ou planejados.

---

## 4. Desenhar o MVP com o Catalyst

**Objetivo:** transformar a ideia em um MVP claro e viável.

1. Falar com o **Catalyst Agent** (ou Project Catalyst, se já existir):

   - Enviar:
     - overview do projeto,
     - objetivo do MVP,
     - restrições (tempo, orçamento, stack).

   - Pedir:
     1. Reescrever entendimento.
     2. Fazer perguntas.
     3. Propor:
        - escopo da v1,
        - módulos principais,
        - fluxos essenciais,
        - modelo de dados de alto nível,
        - plano em etapas.

2. Revisar o plano junto com o GOD user.

3. Se necessário, iterar até ficar “bom o suficiente” para começar.

**Saída:**  
- Specification inicial do MVP,
- plano em etapas (Step 1, Step 2…).

---

## 5. Criar o esqueleto técnico do projeto

**Objetivo:** preparar o terreno para implementação (repositório, stack, etc.).

1. Criar repositório (GitHub ou outro) com nome baseado no `slug`.
2. Definir stack base (se ainda não estiver definida):
   - ex.: React + Vite + TS + Supabase + Tailwind + Vercel.
3. Pedir ajuda ao **Core Code Assistant** (ou agent específico) para:
   - gerar a estrutura inicial do projeto,
   - configurar supabase client,
   - organizar pastas conforme `naming-conventions.md`,
   - criar arquivos de exemplo (App, layout, etc.).

**Saída:**  
- Projeto inicial criado,
- pronto para começar a implementar as etapas do plano.

---

## 6. Executar a v1 em pequenos ciclos

**Objetivo:** implementar a v1 do projeto iterando com segurança.

1. Escolher com o Catalyst / GOD user qual etapa do plano vem primeiro (Step 1).
2. Para cada etapa:
   - detalhar o escopo,
   - chamar o Code Assistant,
   - implementar,
   - revisar código,
   - testar (manual/automático),
   - documentar mudanças (Docs Agent),
   - se aplicável, ajustar fluxos.

3. Evitar:
   - pular entre muitas etapas sem fechar nenhuma,
   - implementar coisas fora do escopo da v1.

**Saída:**  
- Módulos do MVP ganhando vida passo a passo.

---

## 7. Preparar para operação e evolução

**Objetivo:** garantir que o projeto não morra logo após a v1.

1. Envolver o **Ops & Analytics Agent** quando houver dados reais:
   - log de erros,
   - métricas de uso,
   - tempos de resposta,
   - feedback de usuários.

2. Transformar insights em novas ideias:
   - passar para o GOD Ideas Agent,
   - organizar backlog,
   - planejar v1.1, v2, etc.

3. Atualizar:
   - docs do projeto,
   - status/roadmap.

**Saída:**  
- Projeto em ciclo de evolução contínua,
- pronto para acumular conhecimento e melhorias.

---

## 8. Resumo do fluxo em forma curta

```text
1) Ideia → GOD Ideas Agent
2) Virou projeto → registrar em projects + overview.md
3) Time de agentes → Agents Architect
4) MVP & arquitetura → Catalyst (ou Project Catalyst)
5) Esqueleto técnico → Code Assistant
6) Implementação em etapas → Code + Docs + (Creative/Ops)
7) Observação, insights → Ops Agent
8) Novas ideias → GOD Ideas Agent (ciclo)
```

Este playbook pode ser refinado conforme usarmos em projetos reais.

# Project Lifecycle – Do Insight ao Sistema em Produção

> Este documento descreve como uma ideia se transforma em:
> - Projeto,
> - Sistema/App,
> - Produto em evolução contínua,
> usando o ecossistema de agentes do Agents Hub.

---

## 1. Fases do Ciclo de Vida

### Fase 0 – Insight / Semente de Ideia

**Entrada:**  
- Um pensamento, reclamação, oportunidade, pergunta.
- Pode vir do GOD user, de um stakeholder, de dados (Ops), de outro agente.

**Agente principal:**  
- GOD Ideas & Backlog Agent

**Atividades típicas:**
- Capturar a ideia (texto solto, lista, resumo).
- Estruturar a ideia em um registro com título, descrição, tipo, origem.
- Ligar a um projeto existente (se já existir) ou marcar como “global”.
- Definir status inicial (ex.: `draft` ou `triage`).

**Saída:**  
- `Idea` registrada no Agents Hub.

---

### Fase 1 – Clarificação & Priorização

**Entrada:**  
- Lista de `ideas` (algumas relacionadas, outras soltas).

**Agente principal:**  
- GOD Ideas & Backlog Agent

**Agentes de apoio:**  
- GOD user (decisão),
- Ops & Analytics Agent (dados, quando existirem).

**Atividades típicas:**
- Agrupar ideias por tema/projeto.
- Remover duplicadas / unir parecidas.
- Estimar impacto (qualitativo).
- Estimar esforço (grosso modo).
- Sugerir prioridade.

**Saída:**  
- Ideias com status mais maduro (por ex.: `ready_for_design` para as priorizadas).
- Lista de “candidatas” à próxima fase.

---

### Fase 2 – Design & Arquitetura (Projeto / Módulo / Sistema)

**Entrada:**  
- Ideia com status `ready_for_design`.

**Agente principal:**  
- Catalyst Agent (global) ou Project Catalyst (para um projeto específico).

**Agentes de apoio:**  
- Agents Architect & Orchestrator (se envolver novos agentes),
- GOD user (alinhamento),
- eventualmente Creative Agent (se UX/visual for parte grande da ideia).

**Atividades típicas:**
- Entrevistar o GOD user / stakeholders (perguntas).
- Clarificar objetivo, restrições, usuários, contexto.
- Propor:
  - requisitos funcionais principais,
  - requisitos não funcionais relevantes,
  - fluxos de alto nível,
  - arquitetura (entidades, módulos, serviços, integrações).
- Definir **plano em etapas** (Step 1, 2, 3…).

**Saída:**  
- Especificação de módulo/sistema/projeto (em markdown).
- Plano em etapas de implementação.

---

### Fase 3 – Planejamento de Execução

**Entrada:**  
- Plano em etapas gerado pelo Catalyst.

**Agentes principais:**
- GOD user / PO
- (Facultativo) GOD Ideas Agent para quebrar etapas em itens de backlog.

**Agentes de apoio:**  
- Core Code Assistant (consulta sobre esforço técnico),
- Docs & Knowledge Agent (preparo de docs iniciais).

**Atividades típicas:**
- Escolher o que entra na v1 / MVP.
- Definir ordem de execução das etapas.
- Quebrar etapas em tasks (quando for útil).
- Preparar repositório, ambientes e ferramentas.

**Saída:**  
- Lista de etapas/tarefas acordadas para implementação.
- Definição clara de “escopo da v1”.

---

### Fase 4 – Implementação

**Entrada:**  
- Etapas definidas (Step 1, Step 2, etc.).
- Contexto do repositório e da stack.

**Agente principal:**  
- Core Code Assistant (ou versão por projeto).

**Agentes de apoio:**  
- Catalyst Agent (para dúvidas de design),
- Docs & Knowledge Agent (para registrar decisões),
- Creative Agent (para UI/UX/visuais).

**Atividades típicas:**
- Implementar features em pequenos passos.
- Criar/editar arquivos conforme padrões do projeto.
- Tratar erros, estados de loading, feedbacks.
- Manter rastreabilidade (o que foi feito, onde, por quê).

**Saída:**  
- Código funcional,
- Módulos/fluxos implementados,
- Branches/PRs prontos para revisão humana.

---

### Fase 5 – Documentação & Alinhamento

**Entrada:**  
- Código implementado,
- Decisões de design que foram tomadas no caminho.

**Agente principal:**  
- Docs & Knowledge Agent

**Agentes de apoio:**  
- Catalyst (contexto de arquitetura),
- Core Code Assistant (detalhes técnicos).

**Atividades típicas:**
- Gerar/atualizar:
  - READMEs,
  - docs de módulos,
  - resumos de fluxos,
  - ADRs simplificados (decisões importantes).
- Facilitar onboarding de novos devs/stakeholders.

**Saída:**  
- Documentação atualizada,
- Registro das decisões relevantes.

---

### Fase 6 – Deploy & Operação

**Entrada:**  
- Versão pronta para ser posta em uso (ambiente de testes ou produção).

**Agentes principais:**
- Dev/DevOps humano,
- futuramente: agente de infra/DevOps (a ser definido).

**Agente de apoio:**  
- Ops & Analytics Agent (para observar comportamento).

**Atividades típicas:**
- Deploy em ambientes (dev, staging, prod).
- Configuração de env vars, secrets, etc.
- Configuração de monitoramento e logging.

**Saída:**  
- Sistema em uso,
- Telemetria e logs disponíveis.

---

### Fase 7 – Observação & Insights

**Entrada:**  
- Sistema em uso,
- Dados, logs, métricas, feedback de usuários.

**Agente principal:**  
- Ops & Analytics Agent

**Agentes de apoio:**  
- GOD Ideas Agent (para transformar insights em ideias),
- Catalyst (para repensar arquitetura se necessário).

**Atividades típicas:**
- Ler métricas de uso,
- Identificar gargalos e erros,
- Apontar oportunidades de melhoria,
- Gerar relatórios e resumos para o GOD user.

**Saída:**  
- Insights,
- Problemas identificados,
- Recomendações de melhorias → novas ideias para o backlog.

---

### Fase 8 – Evolução Contínua

**Entrada:**  
- Novas ideias derivadas da operação e do uso.

**Agentes principais:**  
- GOD Ideas Agent,
- Catalyst Agent,
- Agents Architect (quando envolver agentes).

**Atividades típicas:**
- Repetir o ciclo:
  - refinar ideias,
  - redesenhar módulos,
  - criar/evoluir agentes,
  - refatorar código,
  - melhorar UX, documentação, etc.

**Saída:**  
- Releases sucessivas,
- Sistemas e agentes cada vez mais maduros.

---

## 2. Ciclo em Forma Resumida

```text
Insight
  ↓
Idea registrada (GOD Ideas)
  ↓
Clarificação & Priorização
  ↓
Design & Arquitetura (Catalyst)
  ↓
Planejamento de Execução
  ↓
Implementação (Code Assistant)
  ↓
Documentação (Docs Agent)
  ↓
Deploy & Operação
  ↓
Observação & Insights (Ops Agent)
  ↓
Novas Ideias
  ↓
(recomeça)
```

---

## 3. Como usar este documento

- Como referência para o GOD user entender “em que fase estamos”.
- Como mapa para os agentes:
  - GOD Ideas sabe onde entra,
  - Catalyst sabe quando deve ser acionado,
  - Code Assistant sabe que não é “o primeiro da fila”,
  - Ops Agent sabe que alimenta o ciclo.
- Como base para dashboards futuros do próprio Agents Hub (ex.: status dos projetos por fase).

# Kits de Prompts – Catalyst Agent & Ecossistema OlieHub

Este arquivo reúne **modelos de prompts** reutilizáveis para:
- conversar com o **Catalyst Agent** (ideias, módulos, agentes, integrações);
- acionar um **Code Assistant** (ligado ao GitHub/Supabase);
- acionar um **DB/SQL Assistant**;
- acionar agentes **criativos** (design, conteúdo, mídia).

A ideia é padronizar o fluxo:
IDEIA → Catalyst (planeja) → Code/DB/Creative Agents (executam).

---

## 1. Prompts-base para o Catalyst Agent

### 1.1. Novo módulo ou feature em um sistema existente

Use quando quiser desenhar um novo módulo/feature (ex.: CRM do OlieHub).

```text
Quero desenhar um novo módulo em um sistema existente.

Sistema: [nome do sistema, ex.: OlieHub]  
Tecnologias principais: [ex.: React + Vite + Supabase + Tailwind]  
Contexto rápido: [2–4 frases sobre o sistema atual]

Módulo/feature desejado(a):
- Nome: [ex.: CRM simples de clientes]
- Objetivo principal: [ex.: ter uma visão dos clientes, histórico de pedidos e tags de segmentação]
- Usuários que vão usar: [ex.: time de vendas e atendimento]
- Problemas que quero resolver: [liste em bullets]

Por favor:
1. Reescreva com suas palavras o que você entendeu.  
2. Me faça de 5 a 8 perguntas para clarificar objetivo, fluxos principais, dados necessários e restrições.  
3. Depois das minhas respostas, organize os requisitos, proponha arquitetura/fluxos e faça um plano em etapas.  
4. No final, sugira 3 a 5 melhorias extras que eu poderia considerar.
```

---

### 1.2. Novo sistema / app do zero

```text
Quero desenhar um novo sistema/app do zero.

Nome (provisório): [ex.: Hub de Projetos, Agentes e Ideias]  
Visão geral (rápida): [2–5 frases]  
Quem vai usar: [perfis de usuário, ex.: GOD user, devs, PMs]  
Problemas que quero resolver: [lista em bullets]

Por favor:
1. Reescreva com suas palavras o que você entendeu sobre esse sistema.  
2. Me faça de 5 a 10 perguntas para clarificar escopo, tipos de usuário, dados centrais, integrações e o que é sucesso para a v1.  
3. Depois das respostas, monte um resumo de requisitos + proposta de módulos principais + plano de fases.  
4. Liste também 3 a 5 ideias de agentes que poderiam nascer junto com esse sistema.
```

---

### 1.3. Novo AGENTE (Agent Blueprint)

```text
Quero desenhar um **novo agente de IA**.

Nome (provisório): [ex.: OlieHub Ops Agent]  
Projeto ao qual pertence: [ex.: OlieHub]  
Objetivo principal: [ex.: ajudar operadores a acompanhar OPs, estoque e prazos]  

Contexto rápido do projeto:
[2–4 frases]

Por favor:
1. Reescreva com suas palavras o que você entendeu sobre esse agente.  
2. Me faça 5 a 8 perguntas para definir melhor:
   - escopo,
   - o que ele pode/não pode fazer,
   - quais entradas/saídas ele terá,
   - com quais APIs/sistemas ele deve falar.  
3. Depois das respostas, produza um **Agent Blueprint** completo com:
   - name, id, project, role, goals,
   - scope, out_of_scope,
   - inputs, outputs,
   - ferramentas/integrações,
   - safety/constraints,
   - 2–5 example_prompts,
   - ideias de evolução (v2, v3...).  
4. No final, sugira onde esse agent poderia ser salvo (ex.: arquivo `.md` em `agents/`) e como ele poderia ser reutilizado em outros projetos.
```

---

### 1.4. Revisão / Redesign de um fluxo existente

```text
Quero revisar e melhorar um fluxo que já existe em um sistema.

Sistema: [ex.: OlieHub]  
Módulo/fluxo: [ex.: Pedidos → Produção → Estoque]  
Problemas que estou percebendo hoje:
- [ex.: estados confusos]
- [ex.: usuários se perdem nas telas]
- [ex.: carece de visibilidade de prazos]

Tenho materiais para te mandar: [descreva se vai enviar prints, diagramas, trechos de código, etc.]

Por favor:
1. Me diga que tipo de material seria mais útil para você entender esse fluxo (e.g. diagrama, prints, descrição passo a passo).  
2. Depois que eu te mandar, reescreva o fluxo atual com suas palavras, identifique pontos confusos e proponha uma versão melhorada de:
   - estados,
   - eventos,
   - telas,
   - mensagens de erro e feedback.  
3. No final, proponha um plano de implementação em etapas + 3 a 5 melhorias futuras.
```

---

## 2. Prompts-base para Code Assistant (ligado a GitHub / Supabase)

> Estes prompts são pensados para serem usados em um **Code Assistant com acesso ao repositório** e, idealmente, ao Supabase.

### 2.1. Implementar módulo a partir do plano do Catalyst

```text
Contexto:
Estou trabalhando no projeto [nome do projeto, ex.: OlieHub ou Agents Hub].  
Stack: [ex.: React + Vite + TypeScript + Supabase + Tailwind].

Abaixo está o plano gerado pelo Catalyst Agent para o módulo [nome do módulo].  
[COLE AQUI o resumo de requisitos + arquitetura + plano em etapas]

Sua missão:
- Implementar APENAS a etapa [número da etapa, ex.: Step 1] deste plano.  
- Trabalhar diretamente nos arquivos do repositório (criar/editar conforme necessário).  
- Manter o estilo de código e padrões do projeto.

Regras:
- Não mude comportamento crítico fora do escopo da etapa.  
- Se precisar criar novos arquivos, siga a organização sugerida pelo Catalyst (pastas, nomes).  
- Se tiver dúvidas sobre requisitos, comente no código de forma clara (TODO: ...).

Por favor:
1. Me diga quais arquivos pretende criar/editar.  
2. Aplique as mudanças.  
3. No final, liste os arquivos alterados e um resumo do que foi feito.
```

---

### 2.2. Refatorar um módulo seguindo diretrizes do Catalyst

```text
Contexto:
Catalyst Agent sugeriu refatorar o módulo [nome do módulo] para [motivo da refatoração].

Resumo das diretrizes de refactor do Catalyst:
[COLE AQUI as recomendações principais]

Sua missão:
- Aplicar essas diretrizes ao código atual.  
- Melhorar legibilidade, separação de responsabilidades e tipagem (se usar TypeScript).  
- Não alterar regras de negócio essenciais, a não ser que isso faça parte do plano.

Por favor:
1. Examine os arquivos envolvidos e diga onde estão os maiores problemas.  
2. Proponha rapidamente uma estratégia de refactor (arquivos, componentes, hooks, serviços).  
3. Aplique o refactor.  
4. Liste os arquivos modificados e descreva as melhorias principais.
```

---

### 2.3. Aplicar SQL sugerido pelo Catalyst (com cuidado)

> Para ser usado com um agente de desenvolvimento/DB, mas SEM autorizar mudanças cegas.

```text
Contexto:
Catalyst Agent sugeriu as seguintes mudanças de banco para [nome do projeto].  
[COLE AQUI o SQL ou o modelo conceitual que ele propôs]

Sua missão:
- Revisar esses comandos SQL.  
- Verificar se eles se encaixam no schema atual do Supabase/Postgres.  
- Sugerir ajustes se necessário (renomes, índices, constraints, RLS).

Regras:
- NÃO executar nada automaticamente.  
- NÃO assumir que as tabelas estão vazias; considere dados existentes.

Por favor:
1. Analise o SQL e diga o que ele faz, em linguagem simples.  
2. Aponte possíveis riscos (ex.: perda de dados, conflitos de chave, migração lenta).  
3. Se necessário, proponha uma versão revisada do SQL, com comentários explicando cada bloco.  
4. Liste passos manuais recomendados para aplicar isso em ambiente real (dev/staging/prod).
```

---

## 3. Prompts-base para agentes criativos (design, conteúdo, mídia)

> Estes são prompts para agentes focados em design, marketing, mídia, etc.  
> Idealmente, esses agentes também terão seus próprios blueprints.

### 3.1. Design de landing page / site para um projeto

```text
Quero criar o design de uma **landing page** para um projeto chamado [nome do projeto].

Contexto do projeto:
[Explique o que o projeto faz em 3–6 frases]

Público-alvo: [ex.: donos de pequenos ateliês, PMEs, etc.]  
Tom/estilo desejado: [ex.: profissional, acolhedor, moderno, minimalista]

Por favor:
1. Proponha a estrutura da landing page em seções (hero, benefícios, features, depoimentos, CTA, etc.).  
2. Sugira textos de exemplo para cada seção (títulos, subtítulos, bullets).  
3. Sugira referências de estilo visual (cores, tipografia, imagens) compatíveis com a identidade do projeto.  
4. Se possível, sugira como isso poderia ser traduzido em componentes (ex.: usando Tailwind/React).
```

---

### 3.2. Kit de comunicação visual para um novo sistema

```text
Estou criando um novo sistema chamado [nome].

Descrição rápida:
[2–4 frases]

Quero um **kit de comunicação visual inicial** com:
- paleta de cores (com HEX sugeridos),
- tipografia (famílias e onde usar),
- estilo de ícones,
- estilo de ilustrações/fotos,
- 2–3 sugestões de logos conceituais (descritas em texto).

Por favor:
1. Descreva 2 ou 3 direções de identidade visual possíveis (ex.: “moderno-tech”, “artesanal-premium”, etc.).  
2. Para cada direção, proponha paleta + tipografia + estilo de ícones/imagens.  
3. Dê exemplos de como isso se traduziria na UI (botões, cards, tabelas, formulários).
```

---

### 3.3. Materiais de divulgação (posts, apresentações, etc.)

```text
Quero criar materiais de divulgação para [projeto/sistema].

Contexto do projeto:
[2–4 frases]

Público-alvo: [descreva]  
Canais principais: [ex.: Instagram, LinkedIn, Email]

Por favor:
1. Sugira 5 ideias de posts (título + descrição + call to action).  
2. Sugira 3 ideias de carrosséis ou sequências (passo a passo, storytelling, bastidores, etc.).  
3. Sugira um roteiro básico para uma apresentação de 5–10 slides explicando o projeto.  
4. Opcional: sugira um roteiro curto (30–60s) de vídeo para apresentar o sistema.
```

---

## 4. Como evoluir este kit de prompts

- Sempre que um fluxo funcionar bem (por exemplo, Catalyst → Code Assistant → resultado bom), copie esse prompt e salve aqui.  
- Organize por categorias: Catalyst, Code, DB, Criativo, Ops, etc.  
- Crie, no futuro, **blueprints de agentes** específicos para cada tipo de prompt (“Code Assistant do OlieHub”, “Agente de Design do Hub”, etc.).  
- Use este arquivo como base para treinar/ajustar novos agentes ou GPTs personalizados.

# Tech Stack & Docs – OlieHub & Agents Hub

Este arquivo lista tecnologias que usamos hoje e outras que fazem sentido estratégico para o ecossistema:
- OlieHub (ERP / Ops Platform)
- Hub de Projetos, Agentes e Ideias
- Agentes técnicos (código, dados, infra)
- Agentes criativos (design, conteúdo, mídia)

Use este arquivo como mapa de referência rápida para documentação oficial.

---

## 1. Plataforma Core de Dados & Backend

### Supabase

**Papel:** Backend principal (Postgres, Auth, Realtime, Storage, Edge Functions) para OlieHub e, possivelmente, para o Hub de Agentes/Projetos.

- Site: https://supabase.com/
- Docs gerais: https://supabase.com/docs
- Database / Postgres: https://supabase.com/database
- Auth: https://supabase.com/docs/guides/auth
- Realtime: https://supabase.com/docs/guides/realtime
- Storage: https://supabase.com/docs/guides/storage
- Edge Functions: https://supabase.com/docs/guides/functions

### Node.js

**Papel:** Runtime JavaScript/TypeScript para scripts, funções backend, ferramentas de automação e CLIs.

- Docs: https://nodejs.org/api/

### GitHub

**Papel:** Repositórios de código, issues, PRs, CI/CD, gatilho para Code Assistants.

- REST API docs: https://docs.github.com/en/rest
- Conteúdo de repositórios (arquivos, diretórios): https://developer.github.com/v3/repos/contents/

### Vercel

**Papel:** Deploy de frontends (React/Vite/Next), edge functions, hospedagem dos apps web e possivelmente endpoints de agentes.

- Docs gerais: https://vercel.com/docs

---

## 2. Frontend & UI

### React

**Papel:** Biblioteca principal de UI para OlieHub, Hub de Agentes e futuros apps (painéis, CRMs, etc.).

- Site / Docs: https://react.dev/
- Quick Start (moderno): https://react.dev/learn

### Vite

**Papel:** Ferramenta de build/dev para os frontends (especialmente React + TS).

- Site / Docs: https://vite.dev/

### Tailwind CSS

**Papel:** Design system utilitário (base do AtlasUI), acelera layout responsivo e estilização de painéis complexos.

- Site / Docs: https://tailwindcss.com/
- Guia (incluindo Vite): https://tailwindcss.com/docs

### React Native & Expo (futuro mobile)

**Papel:** Opção para apps mobile nativos (operacional, dashboards, etc.), compartilhando lógica com o stack React.

- React Native docs: https://reactnative.dev/docs/getting-started
- React Native tutorial: https://reactnative.dev/docs/tutorial
- Expo docs: https://docs.expo.dev/
- Expo platform: https://expo.dev/

---

## 3. AI / LLMs / Agentes

### Google AI / Gemini

**Papel:** Modelos de linguagem principais para agentes (código, análise, criativos), via Google AI Studio e Gemini API.

- Gemini API docs (geral): https://ai.google.dev/gemini-api/docs
- API reference: https://ai.google.dev/api
- AI Studio Quickstart: https://ai.google.dev/gemini-api/docs/ai-studio-quickstart
- Gemini Cookbook (exemplos): https://github.com/google-gemini/cookbook

### OpenAI (ChatGPT / API) – complementar

**Papel:** Alternativa e complemento de LLMs (para testes, comparação de agentes, ou integração específica).

- Portal docs: https://platform.openai.com/docs
- API reference: https://platform.openai.com/docs/api-reference/introduction

### Vercel AI SDK (futuro)

**Papel:** Framework para integrar LLMs (Gemini, OpenAI, etc.) em apps React/Next/Vite com streaming, tools, RAG, etc.

- Docs: https://ai-sdk.dev/docs/introduction

---

## 4. Mensageria, Social & Omnichannel

### WhatsApp Business / Cloud API (Meta)

**Papel:** Integração com WhatsApp para comunicação com clientes (pedidos, suporte, automações alinhadas à política atual da plataforma).

- Visão geral da plataforma: https://developers.facebook.com/docs/whatsapp/
- Cloud API (principal): https://developers.facebook.com/docs/whatsapp/cloud-api/
- Developer Hub: https://business.whatsapp.com/developers/developer-hub

*(Importante: seguir sempre as políticas atuais da Meta para uso da API, especialmente quanto a chatbots e finalidades permitidas.)*

### Instagram APIs (Meta)

**Papel:** Integrações de marketing, ingestão de mensagens/comentários, insights de campanhas, etc.

- Visão geral de APIs: https://developers.facebook.com/products/instagram/apis/
- Instagram Graph API main: https://developers.facebook.com/docs/instagram-platform/
- API Reference: https://developers.facebook.com/docs/instagram-platform/reference/

### Facebook Graph / Meta for Developers (base)

**Papel:** Base para várias integrações (Instagram, WhatsApp, páginas e assets).

- Meta for Developers: https://developers.facebook.com/

---

## 5. Pagamentos & Financeiro

### Stripe

**Papel:** Gateway de pagamento internacional, assinaturas, billing, customer portal (para SaaS, produtos digitais, etc.).

- Docs gerais: https://docs.stripe.com/
- API reference: https://docs.stripe.com/api

### Asaas (Brasil)

**Papel:** Cobrança recorrente, boletos, PIX, gestão de recebíveis para contexto brasileiro.

- Docs API: https://docs.asaas.com/
- Portal desenvolvedores: https://www.asaas.com/desenvolvedores

---

## 6. ERPs Fiscais & Gestão Integrada (Brasil)

### Bling

**Papel:** ERP/fiscal para integração com nota fiscal, estoque, vendas; possível integração com OlieHub para emissão e conciliação.

- Portal dev: https://developer.bling.com.br/
- API pública: https://www.bling.com.br/api-bling

### Tiny ERP

**Papel:** ERP integrado para vendas, estoque, expedição e emissão de NFe, com API REST para sincronia com OlieHub.

- Docs API (geral): https://tiny.com.br/api-docs/api
- Exemplo API v2.0 (expedições): https://tiny.com.br/api-docs/api2-expedicao-obter

---

## 7. Logística & Fretes

### Melhor Envio

**Papel:** Cotações e geração de fretes com múltiplas transportadoras (Brasil), integrado ao fluxo de pedidos do OlieHub.

- Portal docs: https://docs.melhorenvio.com.br/
- Introdução API: https://docs.melhorenvio.com.br/reference/introducao-api-melhor-envio
- Introdução (alternativa): https://docs.melhorenvio.com.br/docs/introducao-a-api

---

## 8. Automação & Orquestração Externa

### n8n

**Papel:** Plataforma de automação de workflows com integrações e nós de AI, útil para conectar OlieHub/Hub a serviços externos sem codar tudo na mão.

- Docs: https://docs.n8n.io/

### Make (antigo Integromat)

**Papel:** Automação visual de processos (integração com CRMs, ERPs, planilhas, etc.).

- Site / Docs principais: https://www.make.com/

### Zapier

**Papel:** Integrações no-code com milhares de apps; útil para disponibilizar “gatilhos” do hub e do OlieHub para usuários finais ou parceiros.

- Developer platform docs: https://zapier.com/developer-platform
- Docs gerais de plataforma: https://developer.zapier.com/

---

## 9. Design, UX, Branding & Conteúdo Criativo

### Figma

**Papel:** Ferramenta central de design de interface, fluxos e prototipagem, cada vez mais integrada com AI e agentes.

- Help Center (PT): https://help.figma.com/hc/pt-br
- Figma Learn / cursos: https://help.figma.com/hc/en-us
- Developer Docs (plugins, APIs): https://developers.figma.com/

### Canva

**Papel:** Criação de materiais de marketing, catálogos, posts, apresentações; potencial integração via Apps SDK e Connect APIs.

- Canva Developers (geral): https://www.canva.com/developers/
- Apps SDK docs: https://www.canva.dev/
- Connect APIs: https://www.canva.dev/docs/connect/
- Data Connectors: https://www.canva.com/developers/build-with-data-connectors/

*(Interessante para agentes criativos gerarem templates, artes e variações.)*

---

## 10. Observabilidade, Logs & Monitoramento

### Sentry

**Papel:** Monitoramento de erros e performance para frontends e backends (React, Node, etc.), importante para OlieHub em produção.

- Docs gerais: https://docs.sentry.io/
- JavaScript SDK: https://docs.sentry.io/platforms/javascript/
- JS SDK repo: https://github.com/getsentry/sentry-javascript

### (Futuro) Logging/Monitoring em Cloud

**Papel:** Uso de ferramentas de logging (por exemplo, Google Cloud Logging, Logtail, etc.) para acompanhar agents, funções e webhooks.

- Google Cloud Operations (Logging/Monitoring) – ponto de partida:
  - https://cloud.google.com/products/operations

---

## 11. Outros Recursos Relevantes

### Templates & Docs Sites

**Papel:** Documentar o ecossistema (apps, agentes, APIs) de forma organizada.

- Nextra Docs Template (Next.js + Vercel): https://vercel.com/templates/next.js/documentation-starter-kit

### Comunidades & Exemplos

- n8n Workflows (exemplos): https://n8n.io/workflows/
- Supabase Examples: https://supabase.com/examples
- Stripe Samples: https://docs.stripe.com/samples

---

## 12. Como usar este arquivo no projeto

Sugestões de uso:

- Manter este arquivo em algo como `docs/stack-links.md` ou `knowledge/stack-links.md`.
- Sempre que uma nova tecnologia entrar no ecossistema (ex.: novo gateway de pagamento, nova API de logística, novo provedor de AI), adicionar:
  - uma breve descrição do papel dela no OlieHub / Hub de Agentes,
  - links principais de documentação.
- Em conversas com agentes (Catalyst, Code Assistant, etc.), referenciar explicitamente:
  - “Conforme stack-links.md, nosso stack de AI hoje é X, Y, Z…”
- Usar este documento como base para painéis internos de “Arquitetura & Stack”.

