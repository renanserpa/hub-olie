# Atlas & Agents – Pacote de Conhecimento

Este diretório contém os artefatos centrais do **Atlas de Agentes** que usamos como
fundação conceitual do ecossistema (GOD / Catalyst / Code Assistant / OlieHub, etc.).

Ele não é específico de um único produto: é a "constituição" de agentes, arquitetura
de conhecimento e processo que o OlieHub herda.

## Como usar dentro do OlieHub

- **Catalyst / GOD / Arquitetura**  
  - `ecosystem-glossary.md` — glossário de termos do ecossistema.  
  - `knowledge-architecture.md` — como o conhecimento é organizado (camadas, packs).  
  - `project-lifecycle.md` — ciclo de vida de projetos dentro do Atlas.  
  - `naming-conventions.md` — convenções de nomes para arquivos, agentes, módulos.  
  - `interaction-guidelines.md` — como conversar com os agentes.

- **Hub de Agentes & Mapa**  
  - `agents-hub-overview.md` — visão geral do Agents Hub.  
  - `agents-map-overview.md` — mapa macro dos agentes e camadas.  
  - `agents-core.md` — definição dos agentes centrais.  
  - `agents-hub-data-model-conceptual.md` — modelo de dados conceitual do Agents Hub.  

- **Agentes específicos**  
  - `catalyst-agent.md` — papel do CatalystAgent.  
  - `god-ideas-agent.md` — papel do GOD Ideas Agent.  
  - `core-code-assistant.md` — papel do Core Code Assistant (usado pelo OlieHub).  
  - `agents-architect-agent.md` — agente arquiteto de sistemas.  
  - `agents-learning-layer.md` — camada de aprendizagem/educação.  
  - `agents-creative-visual-layer.md` — camada criativa visual.  
  - `agents-audiovisual-story-layer.md` — camada audiovisual/narrativa.  
  - `agents-catalysts-hierarchy-and-creation.md` — hierarquia e criação de catalysts.  
  - `core-1-agents.md` — visão adicional dos agentes núcleo.  

- **Playbooks & Prompt Kits**  
  - `playbooks-new-project.md` — playbook para iniciar novos projetos.  
  - `prompt-kits.md` — kits base de prompts (inclusive para OlieHub).  
  - `CATALYST-KNOWLEDGE-PACK.md` — knowledge pack base para Catalyst.  

- **Links & Stack**  
  - `stack-links.md` — links da stack (docs, consoles, etc.).  
  - `stack-infra-ia-deploy.md` — notas de stack/infra/IA/deploy.

- **Materiais em PT-BR (camadas/visão)**  
  - `camadas-de-agentes-bloco-c.md` — visão de camadas de agentes (bloco C).  
  - `cultura-e-processo.md` — pontos de cultura & processo.  
  - `nucleo-e-atlas.md` — visão de núcleo & Atlas.

## Onde referenciar no OlieHub

Dentro dos docs do OlieHub, você pode referenciar este pacote como:

- **Atlas / Agents Pack**: `docs/atlas/`  
- Para o Code Assistant do OlieHub, use especialmente:  
  - `core-code-assistant.md`  
  - `prompt-kits.md`  
  - `playbooks-new-project.md`  
  - `catalyst-agent.md`  
  - `god-ideas-agent.md`  

Nenhum destes arquivos deve afetar o código em runtime: eles são **documentação
estratégica** e base para os agentes que trabalham sobre o repositório.
