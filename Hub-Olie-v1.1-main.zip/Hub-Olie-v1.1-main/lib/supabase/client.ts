import { createClient } from '@supabase/supabase-js';

// Access environment variables using Vite's import.meta.env
// Safely handle cases where import.meta.env might be undefined during initialization
// Casting import.meta to any to avoid TS errors if types aren't perfect
const env = (import.meta as any).env || {};

const supabaseUrl = env.VITE_SUPABASE_URL;
const supabaseAnonKey = env.VITE_SUPABASE_ANON_KEY;

// Export a flag to check if we are in "Mock Mode" (no DB connected)
export const isMockMode = !supabaseUrl || !supabaseAnonKey;

if (isMockMode) {
    console.warn("Aviso: Variáveis de ambiente VITE_SUPABASE_URL e VITE_SUPABASE_ANON_KEY não detectadas. O app rodará em modo MOCK.");
}

// Create a single supabase client for interacting with your database
// We provide fallback strings to prevent the app from crashing on startup if env vars are missing.
// Calls will fail, but the UI will render (likely showing auth errors).
export const supabase = createClient(
    supabaseUrl || 'https://placeholder.supabase.co', 
    supabaseAnonKey || 'placeholder'
);

// Helper to check current session quickly
export const getCurrentUser = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    return user;
};