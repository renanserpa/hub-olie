
# OlieHub - Backlog Fase 1 (MVP Core)

**Objetivo:** Transformar o esqueleto técnico (Fase 0) em um produto utilizável, focando na gestão de clientes, visualização da produção e feedback de usuário.

---

## 1. Épico: Gestão de Clientes (CRM)
**Objetivo:** Permitir o cadastro, edição e listagem de clientes independentemente dos pedidos, para agilizar a venda.

### User Stories
- **US-01:** Como vendedor, quero cadastrar um cliente com nome, telefone e email para selecioná-lo rapidamente em novos pedidos.
- **US-02:** Como vendedor, quero listar meus clientes e buscar por nome.
- **US-03:** Como vendedor, quero editar os dados de contato de um cliente.

### Tarefas por Agente

#### 🤖 DB Agent (Supabase)
- [ ] **Tabela `customers`:**
    - Garantir existência: `id`, `organization_id`, `name`, `email`, `phone`, `created_at`.
    - Indexar `name` para busca.
    - **RLS:** Policy para `select`, `insert`, `update`, `delete` checando `organization_id`.

#### 👨‍💻 Code Agent (Frontend)
- [ ] **Hooks:**
    - `src/modules/crm/hooks/useCustomers.ts`: Fetch com filtro de busca e paginação simples.
    - `src/modules/crm/hooks/useCustomer.ts`: Fetch single by ID.
    - `src/modules/crm/hooks/useUpsertCustomer.ts`: Mutation para criar/editar.
- [ ] **Páginas:**
    - `src/modules/crm/pages/CustomersListPage.tsx`: Tabela com busca e botão "Novo".
    - `src/modules/crm/pages/CustomerFormPage.tsx`: Formulário com validação (React Hook Form + Zod).
- [ ] **Integração Orders:**
    - Atualizar `OrderFormPage` para buscar dados reais da tabela `customers` no dropdown.

#### 🎨 UX/UI Agent
- [ ] Criar **Empty State** para lista de clientes ("Nenhum cliente cadastrado. Adicione o primeiro!").
- [ ] Definir feedback visual de validação nos campos de email/telefone.

---

## 2. Épico: Produção (Kanban Básico)
**Objetivo:** Visualizar o status das Ordens de Produção (OPs) em um quadro visual para gerenciar o chão de fábrica.

### User Stories
- **US-04:** Como gerente de produção, quero que uma OP seja gerada automaticamente (ou com 1 clique) quando um pedido é confirmado.
- **US-05:** Como gerente, quero ver as OPs organizadas em colunas (Planejado, Em Produção, Concluído).
- **US-06:** Como costureira/operador, quero mover um card de "Planejado" para "Em Produção".

### Tarefas por Agente

#### 🤖 DB Agent (Supabase)
- [ ] **Tabela `production_orders`:**
    - Colunas: `id`, `organization_id`, `order_id` (FK), `status` (enum: PLANNED, CUTTING, SEWING, FINISHING, DONE), `priority` (enum: LOW, MEDIUM, HIGH), `notes`.
    - **RLS:** Policies padrão.
- [ ] **Triggers (Opcional/Avançado):**
    - Trigger para criar linha em `production_orders` quando `orders.status` virar `CONFIRMED`. (Ou fazer via Code na Fase 1).

#### 👨‍💻 Code Agent (Frontend)
- [ ] **Hooks:**
    - `src/modules/production/hooks/useProductionOrders.ts`: Fetch agrupado ou filtrado por status.
    - `src/modules/production/hooks/useMoveProductionOrder.ts`: Atualizar status da OP.
- [ ] **Componentes:**
    - `src/modules/production/components/KanbanBoard.tsx`: Layout com colunas flex.
    - `src/modules/production/components/KanbanCard.tsx`: Card mostrando ID do pedido, Cliente e Prioridade.
- [ ] **Páginas:**
    - Atualizar `ProductionPage` para usar o KanbanBoard.

#### 🎨 UX/UI Agent
- [ ] Definir cores para as colunas/badges de status (ex: Cinza -> Azul -> Laranja -> Verde).
- [ ] Design do Card Kanban (compacto, mas legível).

---

## 3. Épico: UX & Feedback (Polimento)
**Objetivo:** Tornar o sistema responsivo e comunicativo, eliminando a sensação de "sistema travado".

### User Stories
- **US-07:** Como usuário, quero ver um feedback claro (sucesso/erro) ao salvar um formulário.
- **US-08:** Como usuário, quero saber quando o sistema está carregando dados.

### Tarefas por Agente

#### 👨‍💻 Code Agent (Frontend)
- [ ] **Toast Notification:**
    - Instalar/Configurar biblioteca de Toasts (ex: `sonner` ou `react-hot-toast`).
    - Criar `src/contexts/ToastContext.tsx` (ou usar provider da lib).
    - Substituir todos os `console.log/alert` atuais por `toast.success()` ou `toast.error()`.
- [ ] **Loading States:**
    - Padronizar Spinner de carregamento em `src/components/shared/Loading.tsx`.
    - Aplicar `disabled={loading}` em todos os botões de submit.
    - Adicionar Skeleton Loading nas tabelas de Orders e Customers.
- [ ] **Tratamento de Erro:**
    - Padronizar mensagens de erro do Supabase (traduzir códigos técnicos para mensagens amigáveis).

---

## 4. Documentação
- [ ] Atualizar `README.md` com instruções de setup das novas tabelas.
- [ ] Documentar fluxo de estados do Pedido -> Produção.

