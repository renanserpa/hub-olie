import React from 'react';
import Joyride, { CallBackProps, STATUS, Step } from 'react-joyride';
import { useApp } from '../contexts/AppContext';

interface OnboardingTourProps {
    run: boolean;
    setRun: (run: boolean) => void;
}

export const OnboardingTour: React.FC<OnboardingTourProps> = ({ run, setRun }) => {
    const { user } = useApp();

    const steps: Step[] = [
        {
            target: 'body',
            placement: 'center',
            content: (
                <div className="text-left">
                    <h3 className="font-bold text-lg mb-2">Bem-vindo ao OlieHub! 👋</h3>
                    <p className="text-sm">Olá, {user?.full_name?.split(' ')[0] || 'Gestor'}. Vamos fazer um tour rápido pelo sistema?</p>
                </div>
            ),
            disableBeacon: true,
        },
        {
            target: '[href="#/orders"]',
            content: 'Aqui você gerencia seus Pedidos. Crie orçamentos, aprove e envie para produção.',
        },
        {
            target: '[href="#/production"]',
            content: 'O coração da fábrica! Transforme pedidos aprovados em Ordens de Produção (OPs).',
        },
        {
            target: '[href="#/inventory"]',
            content: 'Controle seus tecidos, linhas e produtos acabados aqui.',
        }
    ];

    const handleJoyrideCallback = (data: CallBackProps) => {
        const { status } = data;
        const finishedStatuses: string[] = [STATUS.FINISHED, STATUS.SKIPPED];

        if (finishedStatuses.includes(status)) {
            setRun(false);
            // Optional: Save to localStorage that user has seen tour
            localStorage.setItem('oliehub_tour_seen', 'true');
        }
    };

    return (
        <Joyride
            steps={steps}
            run={run}
            continuous
            showSkipButton
            showProgress
            styles={{
                options: {
                    primaryColor: '#2563eb', // blue-600
                    zIndex: 1000,
                },
                tooltipContainer: {
                    textAlign: 'left'
                },
                buttonNext: {
                    backgroundColor: '#2563eb',
                }
            }}
            callback={handleJoyrideCallback}
            locale={{
                back: 'Voltar',
                close: 'Fechar',
                last: 'Vamos lá!',
                next: 'Próximo',
                skip: 'Pular',
            }}
        />
    );
};