import React from 'react';
import { Skeleton } from './Skeleton';

export const Table: React.FC<{ children: React.ReactNode; className?: string }> = ({ children, className = '' }) => (
    <div className={`bg-white shadow-sm rounded-lg border border-gray-200 overflow-hidden ${className}`}>
        <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
                {children}
            </table>
        </div>
    </div>
);

export const TableHeader: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <thead className="bg-gray-50">
        <tr>{children}</tr>
    </thead>
);

export const TableBody: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <tbody className="bg-white divide-y divide-gray-200">
        {children}
    </tbody>
);

export const TableRow: React.FC<React.HTMLAttributes<HTMLTableRowElement>> = ({ children, className = '', ...props }) => (
    <tr className={`hover:bg-gray-50 transition-colors ${className}`} {...props}>
        {children}
    </tr>
);

export const TableHead: React.FC<{ children: React.ReactNode; className?: string; align?: 'left' | 'right' | 'center' }> = ({ 
    children, 
    className = '',
    align = 'left'
}) => (
    <th 
        scope="col" 
        className={`px-6 py-3 text-${align} text-xs font-medium text-gray-500 uppercase tracking-wider ${className}`}
    >
        {children}
    </th>
);

export const TableCell: React.FC<{ children: React.ReactNode; className?: string; align?: 'left' | 'right' | 'center' }> = ({ 
    children, 
    className = '',
    align = 'left'
}) => (
    <td className={`px-6 py-4 whitespace-nowrap text-sm text-${align} ${className}`}>
        {children}
    </td>
);

export const TableEmptyState: React.FC<{ colSpan: number; message: string; children?: React.ReactNode }> = ({ 
    colSpan, 
    message,
    children 
}) => (
    <tr>
        <td colSpan={colSpan} className="px-6 py-10 text-center text-sm text-gray-500">
            <p className="mb-2">{message}</p>
            {children}
        </td>
    </tr>
);

export const TableSkeleton: React.FC<{ columns: number; rows?: number }> = ({ columns, rows = 5 }) => {
    return (
        <>
            {Array.from({ length: rows }).map((_, rowIndex) => (
                <tr key={rowIndex} className="animate-pulse">
                    {Array.from({ length: columns }).map((_, colIndex) => (
                        <td key={colIndex} className="px-6 py-4 whitespace-nowrap">
                            <Skeleton className="h-4 w-full rounded" />
                        </td>
                    ))}
                </tr>
            ))}
        </>
    );
};