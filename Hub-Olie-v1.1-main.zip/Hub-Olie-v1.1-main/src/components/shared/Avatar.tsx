import React from 'react';
import { User } from 'lucide-react';

interface AvatarProps {
    name?: string;
    email?: string;
    src?: string;
    size?: 'sm' | 'md' | 'lg';
    className?: string;
}

export const Avatar: React.FC<AvatarProps> = ({ 
    name, 
    src, 
    size = 'md', 
    className = '' 
}) => {
    const getInitials = (name?: string) => {
        if (!name) return '?';
        const parts = name.split(' ');
        if (parts.length === 1) return parts[0].substring(0, 2).toUpperCase();
        return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
    };

    const sizeClasses = {
        sm: 'h-8 w-8 text-xs',
        md: 'h-10 w-10 text-sm',
        lg: 'h-14 w-14 text-base'
    };

    const baseClasses = "rounded-full flex items-center justify-center font-bold transition-colors relative overflow-hidden";
    const colorClasses = "bg-blue-100 text-blue-700 border border-blue-200";

    if (src) {
        return (
            <img 
                src={src} 
                alt={name || 'Avatar'} 
                className={`${baseClasses} ${sizeClasses[size]} ${className} object-cover`} 
            />
        );
    }

    return (
        <div 
            className={`${baseClasses} ${sizeClasses[size]} ${colorClasses} ${className}`}
            title={name}
        >
            {name ? getInitials(name) : <User className="opacity-50" />}
        </div>
    );
};