import React from 'react';

interface BadgeProps {
    children: React.ReactNode;
    colorClass?: string; // Expects Tailwind classes like "bg-blue-100 text-blue-800"
    variant?: 'default' | 'outline';
    size?: 'sm' | 'md';
}

export const Badge: React.FC<BadgeProps> = ({ 
    children, 
    colorClass = 'bg-gray-100 text-gray-800', 
    variant = 'default',
    size = 'md'
}) => {
    const sizeClasses = size === 'sm' ? 'px-2 py-0.5 text-[10px]' : 'px-2.5 py-0.5 text-xs';
    const baseClasses = "inline-flex items-center rounded-full font-medium";
    
    // If variant is outline, we might want to process the colorClass to extract border color, 
    // but for simplicity in Phase 0, we'll assume colorClass handles the full style or standard outline.
    const outlineClasses = variant === 'outline' ? 'border border-gray-200 bg-white' : colorClass;

    return (
        <span className={`${baseClasses} ${sizeClasses} ${outlineClasses}`}>
            {children}
        </span>
    );
};