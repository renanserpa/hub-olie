import React from 'react';
import { Modal } from './Modal';
import { Button } from './Button';
import { AlertTriangle } from 'lucide-react';

interface ConfirmDialogProps {
    open: boolean;
    onOpenChange: (open: boolean) => void;
    title: string;
    description: string;
    onConfirm: () => void;
    isLoading?: boolean;
    confirmText?: string;
    cancelText?: string;
    variant?: 'danger' | 'primary';
}

export const ConfirmDialog: React.FC<ConfirmDialogProps> = ({
    open,
    onOpenChange,
    title,
    description,
    onConfirm,
    isLoading = false,
    confirmText = 'Confirmar',
    cancelText = 'Cancelar',
    variant = 'danger'
}) => {
    return (
        <Modal 
            open={open} 
            onOpenChange={onOpenChange} 
            title={title}
        >
            <div className="flex flex-col items-center sm:items-start space-y-4">
                {variant === 'danger' && (
                    <div className="mx-auto flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-full bg-red-100 sm:mx-0 sm:h-10 sm:w-10 mb-2">
                        <AlertTriangle className="h-6 w-6 text-red-600" aria-hidden="true" />
                    </div>
                )}
                
                <p className="text-sm text-gray-500 text-center sm:text-left">
                    {description}
                </p>

                <div className="w-full mt-5 sm:mt-4 sm:flex sm:flex-row-reverse gap-3">
                    <Button
                        variant={variant}
                        onClick={() => {
                            onConfirm();
                            // We don't close automatically here to allow loading state handling by parent if needed
                            // But usually we might want to close if not loading. 
                            // For this implementation, parent controls 'open'.
                        }}
                        isLoading={isLoading}
                        className="w-full sm:w-auto"
                    >
                        {confirmText}
                    </Button>
                    <Button
                        variant="secondary"
                        onClick={() => onOpenChange(false)}
                        disabled={isLoading}
                        className="w-full sm:w-auto mt-3 sm:mt-0"
                    >
                        {cancelText}
                    </Button>
                </div>
            </div>
        </Modal>
    );
};