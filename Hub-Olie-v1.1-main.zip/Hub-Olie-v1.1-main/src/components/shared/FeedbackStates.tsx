import React from 'react';
import { AlertCircle, Loader2, FileX } from 'lucide-react';
import { Button } from './Button';

interface LoadingStateProps {
    message?: string;
}

export const LoadingState: React.FC<LoadingStateProps> = ({ message = 'Carregando...' }) => {
    return (
        <div className="flex flex-col items-center justify-center min-h-[300px] p-8 text-center animate-in fade-in duration-500">
            <Loader2 className="h-10 w-10 text-blue-600 animate-spin mb-4" />
            <p className="text-gray-500 font-medium">{message}</p>
        </div>
    );
};

interface ErrorStateProps {
    title?: string;
    message: string;
    onRetry?: () => void;
}

export const ErrorState: React.FC<ErrorStateProps> = ({ 
    title = 'Ocorreu um erro', 
    message, 
    onRetry 
}) => {
    return (
        <div className="flex flex-col items-center justify-center min-h-[300px] p-8 text-center bg-red-50 rounded-lg border border-red-200 animate-in zoom-in-95 duration-300">
            <div className="bg-red-100 p-3 rounded-full mb-4">
                <AlertCircle className="h-8 w-8 text-red-600" />
            </div>
            <h3 className="text-lg font-bold text-red-800 mb-2">{title}</h3>
            <p className="text-sm text-red-600 max-w-md mb-6">{message}</p>
            {onRetry && (
                <Button onClick={onRetry} variant="secondary" className="border-red-200 hover:bg-red-100 text-red-700">
                    Tentar Novamente
                </Button>
            )}
        </div>
    );
};

interface EmptyStateProps {
    icon?: React.ElementType;
    title: string;
    description: string;
    action?: {
        label: string;
        onClick: () => void;
    };
}

export const EmptyState: React.FC<EmptyStateProps> = ({ 
    icon: Icon = FileX, 
    title, 
    description, 
    action 
}) => {
    return (
        <div className="flex flex-col items-center justify-center min-h-[300px] p-12 text-center bg-white rounded-lg border border-dashed border-gray-300">
            <div className="bg-gray-50 p-4 rounded-full mb-4">
                <Icon className="h-10 w-10 text-gray-400" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">{title}</h3>
            <p className="text-sm text-gray-500 max-w-sm mb-6">{description}</p>
            {action && (
                <Button onClick={action.onClick} variant="primary">
                    {action.label}
                </Button>
            )}
        </div>
    );
};