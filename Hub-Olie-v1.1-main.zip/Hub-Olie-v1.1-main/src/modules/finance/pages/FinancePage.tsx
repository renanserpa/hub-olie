import React from 'react';
import { CreditCard, DollarSign } from 'lucide-react';
import { Button } from '../../../components/shared/Button';
import { useNavigate } from 'react-router-dom';

export const FinancePage: React.FC = () => {
    const navigate = useNavigate();

    return (
        <div className="flex flex-col items-center justify-center min-h-[60vh] text-center space-y-6">
            <div className="bg-green-50 p-6 rounded-full">
                <CreditCard size={64} className="text-green-500" />
            </div>
            
            <div className="max-w-md space-y-2">
                <h1 className="text-2xl font-bold text-gray-900">Módulo Financeiro</h1>
                <p className="text-gray-500">
                    Controle de contas a pagar, receber e fluxo de caixa integrado aos pedidos.
                </p>
            </div>

            <div className="grid grid-cols-2 gap-4 w-full max-w-lg">
                <div className="bg-white p-4 border border-gray-200 rounded-lg shadow-sm">
                    <DollarSign className="text-green-600 mb-2" />
                    <h4 className="font-bold text-gray-800 text-sm">Contas a Receber</h4>
                    <p className="text-xs text-gray-500 mt-1">Automático via Pedidos</p>
                </div>
                <div className="bg-white p-4 border border-gray-200 rounded-lg shadow-sm">
                    <CreditCard className="text-red-600 mb-2" />
                    <h4 className="font-bold text-gray-800 text-sm">Contas a Pagar</h4>
                    <p className="text-xs text-gray-500 mt-1">Gestão de compras e custos</p>
                </div>
            </div>

            <Button variant="outline" onClick={() => navigate('/')}>
                Voltar ao Dashboard
            </Button>
        </div>
    );
};