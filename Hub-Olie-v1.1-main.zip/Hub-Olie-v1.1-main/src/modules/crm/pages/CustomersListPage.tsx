import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCustomers } from '../hooks/useCustomers';
import { useDeleteCustomer } from '../hooks/useDeleteCustomer';
import { useDebounce } from '../../../hooks/useDebounce';
import { Button } from '../../../components/shared/Button';
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell, TableEmptyState } from '../../../components/shared/Table';
import { ConfirmDialog } from '../../../components/shared/ConfirmDialog';
import { LoadingState, ErrorState } from '../../../components/shared/FeedbackStates';
import { useToast } from '../../../contexts/ToastContext';
import { Plus, Search, User, Phone, Mail, Trash2, Edit } from 'lucide-react';

export const CustomersListPage: React.FC = () => {
    const navigate = useNavigate();
    const { customers, loading, error, refetch } = useCustomers();
    const { deleteCustomer, deleting } = useDeleteCustomer();
    const { showToast } = useToast();
    
    const [searchTerm, setSearchTerm] = useState('');
    const debouncedSearchTerm = useDebounce(searchTerm, 300);

    // Confirm Dialog State
    const [deleteId, setDeleteId] = useState<string | null>(null);

    const filteredCustomers = useMemo(() => {
        return customers.filter(c => {
            const term = debouncedSearchTerm.toLowerCase();
            return (
                c.name.toLowerCase().includes(term) ||
                (c.email && c.email.toLowerCase().includes(term)) ||
                (c.phone && c.phone.includes(term))
            );
        });
    }, [customers, debouncedSearchTerm]);

    const handleConfirmDelete = async () => {
        if (!deleteId) return;
        try {
            await deleteCustomer(deleteId);
            showToast("Cliente removido.", "success");
            refetch();
        } catch (e) {
            showToast("Erro ao remover cliente.", "error");
        } finally {
            setDeleteId(null);
        }
    };

    if (loading) return <LoadingState message="Carregando clientes..." />;

    if (error) return <ErrorState message={error} onRetry={refetch} />;

    return (
        <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900">Clientes</h1>
                    <p className="text-sm text-gray-500">Gerencie sua base de contatos.</p>
                </div>
                <Button onClick={() => navigate('/customers/new')}>
                    <Plus size={16} className="mr-2" /> Novo Cliente
                </Button>
            </div>

            <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
                <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Search size={16} className="text-gray-400" />
                    </div>
                    <input 
                        type="text" 
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        placeholder="Buscar por nome, email ou telefone..." 
                        className="pl-10 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm h-9 border"
                    />
                </div>
            </div>

            <Table>
                <TableHeader>
                    <TableHead>Nome</TableHead>
                    <TableHead>Contato</TableHead>
                    <TableHead align="right">Ações</TableHead>
                </TableHeader>
                <TableBody>
                    {filteredCustomers.length > 0 ? (
                        filteredCustomers.map(c => (
                            <TableRow key={c.id}>
                                <TableCell>
                                    <div className="flex items-center">
                                        <div className="flex-shrink-0 h-10 w-10 bg-blue-100 rounded-full flex items-center justify-center text-blue-600">
                                            <User size={20} />
                                        </div>
                                        <div className="ml-4">
                                            <div className="text-sm font-medium text-gray-900">{c.name}</div>
                                        </div>
                                    </div>
                                </TableCell>
                                <TableCell className="text-gray-500">
                                    <div className="space-y-1">
                                        {c.email && (
                                            <div className="flex items-center gap-2">
                                                <Mail size={14} /> {c.email}
                                            </div>
                                        )}
                                        {c.phone && (
                                            <div className="flex items-center gap-2">
                                                <Phone size={14} /> {c.phone}
                                            </div>
                                        )}
                                        {!c.email && !c.phone && <span className="italic text-xs">Sem contato</span>}
                                    </div>
                                </TableCell>
                                <TableCell align="right" className="font-medium">
                                    <button 
                                        onClick={() => navigate(`/customers/${c.id}/edit`)}
                                        className="text-blue-600 hover:text-blue-900 mr-4"
                                    >
                                        <Edit size={16} />
                                    </button>
                                    <button 
                                        onClick={() => setDeleteId(c.id)}
                                        className="text-red-600 hover:text-red-900"
                                    >
                                        <Trash2 size={16} />
                                    </button>
                                </TableCell>
                            </TableRow>
                        ))
                    ) : (
                        <TableEmptyState colSpan={3} message={searchTerm ? 'Nenhum cliente encontrado para a busca.' : 'Nenhum cliente cadastrado.'} />
                    )}
                </TableBody>
            </Table>

            <ConfirmDialog
                open={!!deleteId}
                onOpenChange={(open) => !open && setDeleteId(null)}
                title="Excluir Cliente"
                description="Tem certeza que deseja excluir este cliente? Esta ação não pode ser desfeita e pode afetar pedidos vinculados."
                confirmText="Sim, excluir"
                onConfirm={handleConfirmDelete}
                isLoading={deleting}
            />
        </div>
    );
};