import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useUpsertCustomer } from '../hooks/useUpsertCustomer';
import { useCustomer } from '../hooks/useCustomer';
import { Button } from '../../../components/shared/Button';
import { useToast } from '../../../contexts/ToastContext';
import { ChevronLeft, Save } from 'lucide-react';

export const CustomerFormPage: React.FC = () => {
    const { id } = useParams<{ id: string }>();
    const isEditMode = !!id;
    const navigate = useNavigate();
    const { showToast } = useToast();
    
    const { upsertCustomer, saving, error: saveError } = useUpsertCustomer();
    const { customer, loading: loadingCustomer } = useCustomer(id);

    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [phone, setPhone] = useState('');

    useEffect(() => {
        if (customer && isEditMode) {
            setName(customer.name);
            setEmail(customer.email || '');
            setPhone(customer.phone || '');
        }
    }, [customer, isEditMode]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        
        if (!name.trim()) {
            showToast("Nome é obrigatório.", "error");
            return;
        }

        try {
            await upsertCustomer({
                id: isEditMode ? id : undefined,
                name,
                email,
                phone
            });
            showToast(isEditMode ? "Cliente atualizado!" : "Cliente criado!", "success");
            navigate('/customers');
        } catch (e) {
            // Error handled by hook
        }
    };

    if (isEditMode && loadingCustomer) return <div className="p-12 text-center">Carregando...</div>;

    return (
        <div className="max-w-2xl mx-auto space-y-6">
            <div className="flex items-center gap-4">
                <button onClick={() => navigate('/customers')} className="p-2 hover:bg-gray-100 rounded-full text-gray-500">
                    <ChevronLeft size={20} />
                </button>
                <h1 className="text-2xl font-bold text-gray-900">{isEditMode ? 'Editar Cliente' : 'Novo Cliente'}</h1>
            </div>

            {saveError && (
                <div className="bg-red-50 text-red-700 p-4 rounded-md border border-red-200">
                    {saveError}
                </div>
            )}

            <form onSubmit={handleSubmit} className="bg-white p-6 shadow-sm rounded-lg border border-gray-200 space-y-4">
                <div>
                    <label className="block text-sm font-medium text-gray-700">Nome Completo <span className="text-red-500">*</span></label>
                    <input 
                        type="text" 
                        required
                        value={name}
                        onChange={e => setName(e.target.value)}
                        className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                    />
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700">Email</label>
                        <input 
                            type="email" 
                            value={email}
                            onChange={e => setEmail(e.target.value)}
                            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700">Telefone</label>
                        <input 
                            type="text" 
                            value={phone}
                            onChange={e => setPhone(e.target.value)}
                            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                        />
                    </div>
                </div>

                <div className="flex justify-end pt-4">
                    <Button type="submit" isLoading={saving}>
                        <Save size={16} className="mr-2" />
                        Salvar
                    </Button>
                </div>
            </form>
        </div>
    );
};