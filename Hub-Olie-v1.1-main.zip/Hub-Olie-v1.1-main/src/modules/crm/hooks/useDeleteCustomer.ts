import { useState } from 'react';
import { supabase, isMockMode } from '../../../lib/supabase/client';
import { useApp } from '../../../contexts/AppContext';

export const useDeleteCustomer = () => {
    const { organization } = useApp();
    const [deleting, setDeleting] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const deleteCustomer = async (id: string) => {
        if (!organization) return;
        
        setDeleting(true);
        setError(null);

        try {
            if (isMockMode) {
                await new Promise(r => setTimeout(r, 600));
                return true;
            }

            const { error } = await supabase
                .from('customers')
                .delete()
                .eq('id', id)
                .eq('organization_id', organization.id);

            if (error) throw error;
            return true;

        } catch (err: any) {
            console.error("Error deleting customer:", err);
            setError(err.message || "Erro ao excluir cliente.");
            throw err;
        } finally {
            setDeleting(false);
        }
    };

    return { deleteCustomer, deleting, error };
};