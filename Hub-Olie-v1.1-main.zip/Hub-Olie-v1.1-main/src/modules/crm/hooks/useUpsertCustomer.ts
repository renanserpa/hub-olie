import { useState } from 'react';
import { supabase, isMockMode } from '../../../lib/supabase/client';
import { useApp } from '../../../contexts/AppContext';

interface CustomerInput {
    id?: string;
    name: string;
    email?: string;
    phone?: string;
}

export const useUpsertCustomer = () => {
    const { organization } = useApp();
    const [saving, setSaving] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const upsertCustomer = async (input: CustomerInput) => {
        if (!organization) return;
        
        setSaving(true);
        setError(null);

        try {
            if (isMockMode) {
                await new Promise(r => setTimeout(r, 600));
                return { id: input.id || 'new-mock', ...input };
            }

            // Using 'upsert' or 'insert'/'update' based on ID presence
            const payload = {
                organization_id: organization.id,
                name: input.name,
                email: input.email,
                phone: input.phone
            };

            let query;
            if (input.id) {
                 query = supabase
                    .from('customers')
                    .update(payload)
                    .eq('id', input.id)
                    .select()
                    .single();
            } else {
                 query = supabase
                    .from('customers')
                    .insert(payload)
                    .select()
                    .single();
            }

            const { data, error } = await query;

            if (error) throw error;
            return data;

        } catch (err: any) {
            console.error("Error upserting customer:", err);
            setError(err.message || "Erro ao salvar cliente.");
            throw err;
        } finally {
            setSaving(false);
        }
    };

    return { upsertCustomer, saving, error };
};