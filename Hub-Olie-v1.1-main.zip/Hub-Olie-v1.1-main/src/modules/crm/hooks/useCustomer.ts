import { useEffect, useState } from 'react';
import { supabase, isMockMode } from '../../../lib/supabase/client';
import { Customer } from '../../../types';
import { useApp } from '../../../contexts/AppContext';
import { MOCK_CUSTOMERS } from '../../../services/mockData';

export const useCustomer = (id: string | undefined) => {
    const { organization } = useApp();
    const [customer, setCustomer] = useState<Customer | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const fetchCustomer = async () => {
            if (!organization || !id) return;

            setLoading(true);
            setError(null);

            if (isMockMode) {
                setTimeout(() => {
                    const found = MOCK_CUSTOMERS.find(c => c.id === id);
                    if (found) setCustomer(found);
                    else setError("Cliente não encontrado (Mock)");
                    setLoading(false);
                }, 500);
                return;
            }

            try {
                const { data, error } = await supabase
                    .from('customers')
                    .select('*')
                    .eq('id', id)
                    .eq('organization_id', organization.id)
                    .single();

                if (error) throw error;
                setCustomer(data as Customer);
            } catch (err: any) {
                console.error("Error fetching customer:", err);
                setError(err.message || 'Erro ao carregar cliente.');
            } finally {
                setLoading(false);
            }
        };

        fetchCustomer();
    }, [id, organization]);

    return { customer, loading, error };
};