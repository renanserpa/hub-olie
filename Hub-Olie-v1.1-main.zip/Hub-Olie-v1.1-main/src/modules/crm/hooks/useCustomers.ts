import { useEffect, useState } from 'react';
import { supabase, isMockMode } from '../../../lib/supabase/client';
import { Customer } from '../../../types';
import { useApp } from '../../../contexts/AppContext';
import { MOCK_CUSTOMERS } from '../../../services/mockData';

export const useCustomers = () => {
    const { organization } = useApp();
    const [customers, setCustomers] = useState<Customer[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    const fetchCustomers = async () => {
        if (!organization) return;

        setLoading(true);
        setError(null);

        if (isMockMode) {
            setTimeout(() => {
                const mockData = MOCK_CUSTOMERS.filter(c => c.organization_id === organization.id);
                setCustomers(mockData);
                setLoading(false);
            }, 600);
            return;
        }

        try {
            const { data, error } = await supabase
                .from('customers')
                .select('*')
                .eq('organization_id', organization.id)
                .order('name');

            if (error) throw error;
            setCustomers(data as Customer[]);
        } catch (err: any) {
            console.error("Error fetching customers:", err);
            setError(err.message || 'Erro ao carregar clientes.');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchCustomers();
    }, [organization]);

    return { customers, loading, error, refetch: fetchCustomers };
};