import React from 'react';
import { Truck, MapPin } from 'lucide-react';
import { Button } from '../../../components/shared/Button';
import { useNavigate } from 'react-router-dom';

export const LogisticsPage: React.FC = () => {
    const navigate = useNavigate();

    return (
        <div className="flex flex-col items-center justify-center min-h-[60vh] text-center space-y-6">
            <div className="bg-purple-50 p-6 rounded-full">
                <Truck size={64} className="text-purple-500" />
            </div>
            
            <div className="max-w-md space-y-2">
                <h1 className="text-2xl font-bold text-gray-900">Logística e Expedição</h1>
                <p className="text-gray-500">
                    Gerencie entregas, etiquetas de envio e rastreamento em breve.
                </p>
            </div>

            <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 max-w-lg w-full text-left flex gap-3 opacity-75">
                <MapPin className="text-gray-500 flex-shrink-0" />
                <div>
                    <h4 className="font-bold text-gray-800 text-sm">Funcionalidades Planejadas:</h4>
                    <ul className="list-disc list-inside text-sm text-gray-600 mt-1 space-y-1">
                        <li>Geração de etiquetas de correios/transportadoras</li>
                        <li>Agrupamento de pedidos por região (Ondas)</li>
                        <li>Rastreamento automático para o cliente</li>
                    </ul>
                </div>
            </div>

            <Button variant="outline" onClick={() => navigate('/')}>
                Voltar ao Dashboard
            </Button>
        </div>
    );
};