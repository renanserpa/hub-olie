import React from 'react';
import { Package, AlertTriangle } from 'lucide-react';
import { Button } from '../../../components/shared/Button';
import { useNavigate } from 'react-router-dom';

export const InventoryPage: React.FC = () => {
    const navigate = useNavigate();

    return (
        <div className="flex flex-col items-center justify-center min-h-[60vh] text-center space-y-6">
            <div className="bg-blue-50 p-6 rounded-full">
                <Package size={64} className="text-blue-500" />
            </div>
            
            <div className="max-w-md space-y-2">
                <h1 className="text-2xl font-bold text-gray-900">Gestão de Estoque</h1>
                <p className="text-gray-500">
                    O módulo de controle de insumos e produtos acabados está em desenvolvimento.
                    Na Fase 1, você poderá controlar rolos de tecido, aviamentos e movimentações.
                </p>
            </div>

            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 max-w-lg w-full text-left flex gap-3">
                <AlertTriangle className="text-yellow-600 flex-shrink-0" />
                <div>
                    <h4 className="font-bold text-yellow-800 text-sm">Próximos Recursos:</h4>
                    <ul className="list-disc list-inside text-sm text-yellow-700 mt-1 space-y-1">
                        <li>Cadastro de Materiais (Tecidos, Botões)</li>
                        <li>Controle de Entrada via XML</li>
                        <li>Baixa automática por Ordem de Produção</li>
                    </ul>
                </div>
            </div>

            <Button variant="outline" onClick={() => navigate('/')}>
                Voltar ao Dashboard
            </Button>
        </div>
    );
};