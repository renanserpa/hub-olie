import React from 'react';
import { useApp } from '../../../contexts/AppContext';
import { isMockMode } from '../../../lib/supabase/client';
import { User, Building2, Server } from 'lucide-react';

export const SettingsPage: React.FC = () => {
    const { user, organization } = useApp();

    return (
        <div className="space-y-6">
             <div>
                <h1 className="text-2xl font-bold text-gray-900">Configurações</h1>
                <p className="text-sm text-gray-500">Detalhes da sua conta e ambiente.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* User Profile */}
                <div className="bg-white p-6 shadow-sm rounded-lg border border-gray-200">
                    <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center gap-2">
                        <User size={20} /> Perfil
                    </h3>
                    <dl className="space-y-3 border-t border-gray-100 pt-3">
                        <div className="flex justify-between">
                            <dt className="text-sm font-medium text-gray-500">Nome</dt>
                            <dd className="text-sm text-gray-900">{user?.full_name || 'Usuário'}</dd>
                        </div>
                        <div className="flex justify-between">
                            <dt className="text-sm font-medium text-gray-500">Email</dt>
                            <dd className="text-sm text-gray-900">{user?.email}</dd>
                        </div>
                         <div className="flex justify-between">
                            <dt className="text-sm font-medium text-gray-500">ID do Usuário</dt>
                            <dd className="text-xs text-gray-400 font-mono">{user?.id}</dd>
                        </div>
                    </dl>
                </div>

                {/* Organization */}
                 <div className="bg-white p-6 shadow-sm rounded-lg border border-gray-200">
                    <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center gap-2">
                        <Building2 size={20} /> Organização Ativa
                    </h3>
                     <dl className="space-y-3 border-t border-gray-100 pt-3">
                        <div className="flex justify-between">
                            <dt className="text-sm font-medium text-gray-500">Nome</dt>
                            <dd className="text-sm text-gray-900">{organization?.name}</dd>
                        </div>
                        <div className="flex justify-between">
                            <dt className="text-sm font-medium text-gray-500">Identificador (Slug)</dt>
                            <dd className="text-sm text-gray-900 bg-gray-100 px-2 py-0.5 rounded">{organization?.slug}</dd>
                        </div>
                         <div className="flex justify-between">
                            <dt className="text-sm font-medium text-gray-500">ID da Organização</dt>
                            <dd className="text-xs text-gray-400 font-mono">{organization?.id}</dd>
                        </div>
                    </dl>
                </div>

                {/* System Info */}
                 <div className="bg-white p-6 shadow-sm rounded-lg border border-gray-200">
                    <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center gap-2">
                        <Server size={20} /> Sistema
                    </h3>
                     <dl className="space-y-3 border-t border-gray-100 pt-3">
                        <div className="flex items-center justify-between">
                            <span className="text-sm font-medium text-gray-500">Modo de Operação</span>
                             <span className={`px-2 py-1 text-xs font-bold rounded-full ${isMockMode ? 'bg-yellow-100 text-yellow-800' : 'bg-green-100 text-green-800'}`}>
                                {isMockMode ? 'MOCK MODE (Demonstração)' : 'PRODUCTION (Online)'}
                            </span>
                        </div>
                         <div className="text-xs text-gray-500 mt-2">
                            {isMockMode 
                                ? "O sistema está operando com dados simulados locais. Nenhuma alteração é salva permanentemente." 
                                : "O sistema está conectado ao banco de dados Supabase em tempo real."}
                         </div>
                    </dl>
                </div>
            </div>
        </div>
    );
};