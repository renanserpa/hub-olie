import { useEffect, useState } from 'react';
import { supabase } from '../../../lib/supabase/client';
import { Order } from '../../../types';
import { useApp } from '../../../contexts/AppContext';

export const useOrders = () => {
    const { organization } = useApp();
    const [orders, setOrders] = useState<Order[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const fetchOrders = async () => {
            if (!organization) return;

            setLoading(true);
            setError(null);
            try {
                // Querying 'order' table. 
                // Joining with 'customer' table to get name.
                // NOTE: Check if table name is 'orders' or 'order' in your DB. Assuming 'order' as per prompt.
                const { data, error } = await supabase
                    .from('order')
                    .select('*, customer(name)')
                    .eq('organization_id', organization.id)
                    .order('created_at', { ascending: false });

                if (error) throw error;
                
                // Map the result to ensure TS happiness, especially with joins
                const typedData = (data || []).map((item: any) => ({
                    ...item,
                    // Flatten customer name if possible, or keep structure
                    customer: item.customer // Supabase returns { customer: { name: '...' } } or null
                }));

                setOrders(typedData as Order[]);
            } catch (err: any) {
                console.error("Error fetching orders:", err);
                setError(err.message || 'Erro ao carregar pedidos.');
            } finally {
                setLoading(false);
            }
        };

        fetchOrders();
    }, [organization]);

    return { orders, loading, error };
};