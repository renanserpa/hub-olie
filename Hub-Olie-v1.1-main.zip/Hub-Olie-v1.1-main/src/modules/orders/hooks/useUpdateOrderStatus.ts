import { useState } from 'react';
import { supabase, isMockMode } from '../../../lib/supabase/client';
import { useApp } from '../../../contexts/AppContext';
import { OrderStatus } from '../../../types';

export const useUpdateOrderStatus = () => {
    const { organization } = useApp();
    const [updating, setUpdating] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const updateStatus = async (orderId: string, newStatus: OrderStatus) => {
        if (!organization) return;
        
        setUpdating(true);
        setError(null);

        try {
            if (isMockMode) {
                await new Promise(r => setTimeout(r, 600));
                return true;
            }

            const { error } = await supabase
                .from('orders')
                .update({ status: newStatus })
                .eq('id', orderId)
                .eq('organization_id', organization.id);

            if (error) throw error;
            return true;

        } catch (err: any) {
            console.error("Error updating order status:", err);
            setError(err.message || "Erro ao atualizar status.");
            throw err;
        } finally {
            setUpdating(false);
        }
    };

    return { updateStatus, updating, error };
};