import { useState } from 'react';
import { supabase, isMockMode } from '../../../lib/supabase/client';
import { useApp } from '../../../contexts/AppContext';

export const useDeleteOrder = () => {
    const { organization } = useApp();
    const [deleting, setDeleting] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const deleteOrder = async (orderId: string) => {
        if (!organization) return;
        
        setDeleting(true);
        setError(null);

        try {
            if (isMockMode) {
                // Simulate delay
                await new Promise(r => setTimeout(r, 600));
                return true;
            }

            // First delete items (usually handled by cascade in DB, but good to be explicit or safe)
            // Assuming ON DELETE CASCADE is set on the foreign key in Supabase, 
            // otherwise we'd need to delete order_items first.
            // We will attempt to delete the order directly.
            
            const { error: deleteError } = await supabase
                .from('orders')
                .delete()
                .eq('id', orderId)
                .eq('organization_id', organization.id);

            if (deleteError) throw deleteError;
            
            return true;

        } catch (err: any) {
            console.error("Error deleting order:", err);
            setError(err.message || "Erro ao excluir pedido.");
            throw err;
        } finally {
            setDeleting(false);
        }
    };

    return { deleteOrder, deleting, error };
};