import React from 'react';
import { render, screen } from '@testing-library/react';
import { OrdersListPage } from './OrdersListPage';
import { BrowserRouter } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { describe, it, expect, vi } from 'vitest';

// Mock dependencies
vi.mock('../hooks/useOrders', () => ({
    useOrders: () => ({
        orders: [],
        loading: false,
        error: null,
        refetch: vi.fn()
    })
}));

const queryClient = new QueryClient();

const renderWithProviders = (ui: React.ReactElement) => {
    return render(
        <QueryClientProvider client={queryClient}>
            <BrowserRouter>
                {ui}
            </BrowserRouter>
        </QueryClientProvider>
    );
};

describe('OrdersListPage', () => {
    it('renders the page title', () => {
        renderWithProviders(<OrdersListPage />);
        expect(screen.getByText('Pedidos')).toBeInTheDocument();
    });

    it('renders the New Order button', () => {
        renderWithProviders(<OrdersListPage />);
        expect(screen.getByText('Novo Pedido')).toBeInTheDocument();
    });

    it('shows empty state when no orders', () => {
        renderWithProviders(<OrdersListPage />);
        // Text updated to match TableEmptyState default logic or passed prop
        expect(screen.getByText('Nenhum pedido cadastrado.')).toBeInTheDocument();
    });
});