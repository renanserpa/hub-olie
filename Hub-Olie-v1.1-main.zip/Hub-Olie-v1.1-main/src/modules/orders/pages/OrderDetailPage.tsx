import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useOrder } from '../hooks/useOrder';
import { ORDER_STATUS_LABELS, ORDER_STATUS_COLORS } from '../../../constants';
import { Button } from '../../../components/shared/Button';
import { ChevronLeft, Truck, Scissors, CreditCard } from 'lucide-react';
import { OrderStatus } from '../../../types';

export const OrderDetailPage: React.FC = () => {
    const { id } = useParams<{ id: string }>();
    const navigate = useNavigate();
    const { order, loading, error } = useOrder(id);

    if (loading) return <div className="p-8 text-center text-gray-500">Carregando detalhes...</div>;
    
    if (error || !order) return (
        <div className="p-8 text-center">
            <div className="text-red-500 mb-4">{error || 'Pedido não encontrado.'}</div>
            <Button variant="outline" onClick={() => navigate('/orders')}>Voltar para Lista</Button>
        </div>
    );

    // Safe accessors
    const customerName = (order.customer as any)?.name || 'Cliente N/A';

    return (
        <div className="space-y-6">
            <div className="flex items-center gap-4 mb-6">
                <button onClick={() => navigate('/orders')} className="p-2 hover:bg-gray-100 rounded-full text-gray-500">
                    <ChevronLeft size={20} />
                </button>
                <div>
                    <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-3">
                        {order.code}
                        <span className={`text-sm px-3 py-1 rounded-full font-medium ${ORDER_STATUS_COLORS[order.status as OrderStatus] || 'bg-gray-100'}`}>
                            {ORDER_STATUS_LABELS[order.status as OrderStatus] || order.status}
                        </span>
                    </h1>
                    <p className="text-sm text-gray-500">Cliente: {customerName}</p>
                </div>
                <div className="ml-auto flex gap-2">
                    <Button size="sm">Editar</Button>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Main Content: Items */}
                <div className="lg:col-span-2 space-y-6">
                    <div className="bg-white shadow-sm rounded-lg border border-gray-200 overflow-hidden">
                        <div className="px-6 py-4 border-b border-gray-200 bg-gray-50">
                            <h3 className="text-sm font-medium text-gray-900">Itens do Pedido</h3>
                        </div>
                        <div className="p-6">
                            <table className="min-w-full divide-y divide-gray-200">
                                <thead>
                                    <tr>
                                        <th className="text-left text-xs font-medium text-gray-500 uppercase">Produto</th>
                                        <th className="text-right text-xs font-medium text-gray-500 uppercase">Qtd</th>
                                        <th className="text-right text-xs font-medium text-gray-500 uppercase">Preço Unit.</th>
                                        <th className="text-right text-xs font-medium text-gray-500 uppercase">Total</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-gray-200">
                                    {order.items && order.items.length > 0 ? (
                                        order.items.map(item => (
                                            <tr key={item.id}>
                                                <td className="py-3 text-sm text-gray-900">{item.description || item.product_name}</td>
                                                <td className="py-3 text-sm text-gray-900 text-right">{item.quantity}</td>
                                                <td className="py-3 text-sm text-gray-900 text-right">R$ {item.unit_price.toFixed(2)}</td>
                                                <td className="py-3 text-sm text-gray-900 text-right font-medium">R$ {item.total_price.toFixed(2)}</td>
                                            </tr>
                                        ))
                                    ) : (
                                        <tr>
                                            <td colSpan={4} className="py-4 text-center text-sm text-gray-500">
                                                Nenhum item encontrado.
                                            </td>
                                        </tr>
                                    )}
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colSpan={3} className="pt-4 text-right text-sm font-medium text-gray-500">Total Líquido:</td>
                                        <td className="pt-4 text-right text-lg font-bold text-gray-900">R$ {order.total_net_amount?.toFixed(2)}</td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>

                    {/* Modules Links */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="bg-white p-6 shadow-sm rounded-lg border border-gray-200 opacity-75">
                            <div className="flex items-center gap-2 mb-4 text-gray-900 font-medium">
                                <Scissors size={18} /> Produção (Em breve)
                            </div>
                            <p className="text-sm text-gray-500">Acompanhe o status de confecção.</p>
                        </div>
                         <div className="bg-white p-6 shadow-sm rounded-lg border border-gray-200 opacity-75">
                            <div className="flex items-center gap-2 mb-4 text-gray-900 font-medium">
                                <Truck size={18} /> Logística (Em breve)
                            </div>
                            <p className="text-sm text-gray-500">Gerencie entregas e fretes.</p>
                        </div>
                    </div>
                </div>

                {/* Sidebar: Summary & Finance */}
                <div className="space-y-6">
                    <div className="bg-white p-6 shadow-sm rounded-lg border border-gray-200">
                        <h3 className="text-sm font-medium text-gray-900 mb-4">Resumo</h3>
                        <dl className="space-y-3 text-sm">
                            <div className="flex justify-between">
                                <dt className="text-gray-500">Data do Pedido</dt>
                                <dd className="text-gray-900">{new Date(order.order_date).toLocaleDateString()}</dd>
                            </div>
                            <div className="flex justify-between">
                                <dt className="text-gray-500">Previsão Entrega</dt>
                                <dd className="text-gray-900 font-medium">{new Date(order.due_date).toLocaleDateString()}</dd>
                            </div>
                        </dl>
                    </div>

                     <div className="bg-white p-6 shadow-sm rounded-lg border border-gray-200">
                        <div className="flex items-center gap-2 mb-4 text-gray-900 font-medium">
                            <CreditCard size={18} /> Financeiro
                        </div>
                        <div className="bg-yellow-50 text-yellow-800 p-3 rounded-md text-sm mb-4">
                            Pagamento Pendente
                        </div>
                         <dl className="space-y-2 text-sm border-t border-gray-100 pt-3">
                            <div className="flex justify-between">
                                <dt className="text-gray-500">Total</dt>
                                <dd className="text-gray-900">R$ {order.total_net_amount?.toFixed(2)}</dd>
                            </div>
                            <div className="flex justify-between">
                                <dt className="text-gray-500">Recebido</dt>
                                <dd className="text-gray-900">R$ 0.00</dd>
                            </div>
                        </dl>
                        <Button className="w-full mt-4" variant="secondary" disabled>Registrar Pagamento</Button>
                    </div>
                </div>
            </div>
        </div>
    );
};