import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useOrders } from '../hooks/useOrders';
import { Button } from '../../../components/shared/Button';
import { ORDER_STATUS_LABELS, ORDER_STATUS_COLORS } from '../../../constants';
import { Plus, Search, Filter, ShoppingCart } from 'lucide-react';
import { OrderStatus } from '../../../types';

export const OrdersListPage: React.FC = () => {
    const navigate = useNavigate();
    const { orders, loading, error } = useOrders();

    if (loading) return (
        <div className="flex h-64 items-center justify-center">
            <div className="text-gray-500 animate-pulse">Carregando pedidos...</div>
        </div>
    );
    
    if (error) return (
        <div className="p-8 text-center bg-red-50 rounded-lg border border-red-200 text-red-700 m-4">
            <p>Ocorreu um erro ao carregar os pedidos.</p>
            <p className="text-sm mt-2 font-mono">{error}</p>
        </div>
    );

    return (
        <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900">Pedidos</h1>
                    <p className="text-sm text-gray-500">Gerencie o fluxo de entrada e produção</p>
                </div>
                <div className="flex items-center gap-2">
                    <Button variant="secondary" onClick={() => {}} disabled>
                        Ver Kanban (Em breve)
                    </Button>
                    <Button onClick={() => navigate('/orders/new')}>
                        <Plus size={16} className="mr-2" />
                        Novo Pedido
                    </Button>
                </div>
            </div>

            {/* Filters Bar (Skeleton for now) */}
            <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 flex flex-col sm:flex-row gap-4 items-center">
                <div className="relative flex-1 w-full">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Search size={16} className="text-gray-400" />
                    </div>
                    <input 
                        type="text" 
                        placeholder="Buscar por código..." 
                        className="pl-10 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm h-9 border"
                    />
                </div>
                <Button variant="secondary" className="w-full sm:w-auto">
                    <Filter size={16} className="mr-2" />
                    Filtros
                </Button>
            </div>

            {/* Orders Table */}
            <div className="bg-white shadow-sm rounded-lg border border-gray-200 overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                            <tr>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Código</th>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Cliente</th>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Data Entrega</th>
                                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Valor</th>
                                <th scope="col" className="relative px-6 py-3"><span className="sr-only">Ações</span></th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                            {orders.map((order) => {
                                // Extract customer name safely handling potential join structure
                                const customerName = (order.customer as any)?.name || 'Cliente N/A';
                                
                                return (
                                    <tr key={order.id} className="hover:bg-gray-50 cursor-pointer transition-colors" onClick={() => navigate(`/orders/${order.id}`)}>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-blue-600">
                                            {order.code}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                            {customerName}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${ORDER_STATUS_COLORS[order.status as OrderStatus] || 'bg-gray-100 text-gray-800'}`}>
                                                {ORDER_STATUS_LABELS[order.status as OrderStatus] || order.status}
                                            </span>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                            {new Date(order.due_date).toLocaleDateString()}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right font-medium">
                                            R$ {order.total_net_amount?.toFixed(2)}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                            <span className="text-blue-600 hover:text-blue-900">Ver</span>
                                        </td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </div>
                {orders.length === 0 && (
                    <div className="p-12 text-center">
                        <div className="mx-auto h-12 w-12 text-gray-400">
                            <ShoppingCart size={48} />
                        </div>
                        <h3 className="mt-2 text-sm font-medium text-gray-900">Sem pedidos</h3>
                        <p className="mt-1 text-sm text-gray-500">Nenhum pedido encontrado nesta organização.</p>
                        <div className="mt-6">
                            <Button onClick={() => navigate('/orders/new')}>Novo Pedido</Button>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};