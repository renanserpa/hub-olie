import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useOrders } from '../../orders/hooks/useOrders';
import { useProductionOrders } from '../../production/hooks/useProductionOrders';
import { formatCurrency } from '../../../utils/format';
import { ShoppingCart, Scissors, TrendingUp, AlertCircle } from 'lucide-react';
import { ORDER_STATUS_COLORS, ORDER_STATUS_LABELS } from '../../../constants';
import { OrderStatus } from '../../../types';
import { Skeleton } from '../../../components/shared/Skeleton';

export const DashboardPage: React.FC = () => {
    const navigate = useNavigate();
    const { orders, loading: loadingOrders } = useOrders();
    const { productionOrders, loading: loadingProduction } = useProductionOrders();

    // KPI Calculations
    const activeOrders = orders.filter(o => o.status !== 'COMPLETED' && o.status !== 'CANCELLED');
    const ordersInQuote = orders.filter(o => o.status === 'QUOTE').length;
    const opsInProgress = productionOrders.filter(op => op.status === 'IN_PROGRESS').length;
    
    // Calculate potential revenue (from active non-quote orders)
    const pipelineRevenue = activeOrders
        .filter(o => o.status !== 'QUOTE')
        .reduce((sum, o) => sum + (o.total_net_amount || 0), 0);

    const isLoading = loadingOrders || loadingProduction;

    return (
        <div className="space-y-6">
            <div>
                <h2 className="text-2xl font-bold text-gray-900">Visão Geral</h2>
                <p className="text-gray-500">Acompanhe os indicadores do seu ateliê hoje.</p>
            </div>

            {/* KPI Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-200 flex items-start justify-between">
                    <div>
                        <p className="text-sm font-medium text-gray-500">Pedidos Ativos</p>
                        <h3 className="text-2xl font-bold text-gray-900 mt-1">
                            {isLoading ? <Skeleton className="h-8 w-16" /> : activeOrders.length}
                        </h3>
                        <div className="mt-1">
                            {isLoading ? (
                                <Skeleton className="h-4 w-24" />
                            ) : (
                                <p className="text-xs text-blue-600 cursor-pointer hover:underline" onClick={() => navigate('/orders')}>
                                    {ordersInQuote} em orçamento
                                </p>
                            )}
                        </div>
                    </div>
                    <div className="p-2 bg-blue-50 rounded-lg text-blue-600">
                        <ShoppingCart size={20} />
                    </div>
                </div>

                <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-200 flex items-start justify-between">
                    <div>
                        <p className="text-sm font-medium text-gray-500">Produção Ativa</p>
                        <h3 className="text-2xl font-bold text-gray-900 mt-1">
                            {isLoading ? <Skeleton className="h-8 w-16" /> : opsInProgress}
                        </h3>
                         <p className="text-xs text-green-600 mt-1">
                            Ordens em andamento
                        </p>
                    </div>
                    <div className="p-2 bg-purple-50 rounded-lg text-purple-600">
                        <Scissors size={20} />
                    </div>
                </div>

                <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-200 flex items-start justify-between">
                    <div>
                        <p className="text-sm font-medium text-gray-500">Receita em Pipeline</p>
                        <h3 className="text-2xl font-bold text-gray-900 mt-1">
                            {isLoading ? <Skeleton className="h-8 w-24" /> : formatCurrency(pipelineRevenue)}
                        </h3>
                         <p className="text-xs text-gray-400 mt-1">
                            Pedidos confirmados
                        </p>
                    </div>
                    <div className="p-2 bg-green-50 rounded-lg text-green-600">
                        <TrendingUp size={20} />
                    </div>
                </div>
                 <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-200 flex items-start justify-between opacity-60">
                    <div>
                        <p className="text-sm font-medium text-gray-500">Atrasados</p>
                        <h3 className="text-2xl font-bold text-gray-900 mt-1">0</h3>
                         <p className="text-xs text-gray-400 mt-1">
                            Pedidos fora do prazo
                        </p>
                    </div>
                    <div className="p-2 bg-red-50 rounded-lg text-red-600">
                        <AlertCircle size={20} />
                    </div>
                </div>
            </div>

            {/* Quick Actions */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                    <h3 className="font-bold text-gray-800 mb-4">Acesso Rápido</h3>
                    <div className="space-y-3">
                         <div 
                            className="flex items-center justify-between p-3 bg-gray-50 rounded-md cursor-pointer hover:bg-gray-100 transition-colors"
                            onClick={() => navigate('/orders/new')}
                        >
                            <span className="text-sm font-medium text-gray-700">Criar Novo Pedido</span>
                            <span className="bg-white p-1 rounded shadow-sm text-gray-400">+</span>
                        </div>
                        <div 
                            className="flex items-center justify-between p-3 bg-gray-50 rounded-md cursor-pointer hover:bg-gray-100 transition-colors"
                            onClick={() => navigate('/production')}
                        >
                            <span className="text-sm font-medium text-gray-700">Ver Fila de Produção</span>
                            <span className="bg-white p-1 rounded shadow-sm text-gray-400">→</span>
                        </div>
                    </div>
                </div>

                <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                    <h3 className="font-bold text-gray-800 mb-4">Últimos Pedidos</h3>
                    {isLoading ? (
                         <div className="space-y-3">
                            <Skeleton className="h-12 w-full" />
                            <Skeleton className="h-12 w-full" />
                            <Skeleton className="h-12 w-full" />
                         </div>
                    ) : activeOrders.length === 0 ? (
                        <p className="text-sm text-gray-400">Nenhum pedido recente.</p>
                    ) : (
                        <ul className="space-y-3">
                            {activeOrders.slice(0, 3).map(order => (
                                <li key={order.id} className="flex justify-between items-center text-sm border-b border-gray-50 pb-2 last:border-0 last:pb-0">
                                    <div>
                                        <div className="flex items-center gap-2">
                                            <span className="font-medium text-blue-600 block">{order.code}</span>
                                            <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${ORDER_STATUS_COLORS[order.status as OrderStatus] || 'bg-gray-100'}`}>
                                                {ORDER_STATUS_LABELS[order.status as OrderStatus] || order.status}
                                            </span>
                                        </div>
                                        <span className="text-gray-500 text-xs block mt-0.5">{(order.customer as any)?.name}</span>
                                    </div>
                                    <span className="font-medium text-gray-700">{formatCurrency(order.total_net_amount)}</span>
                                </li>
                            ))}
                        </ul>
                    )}
                    {activeOrders.length > 0 && (
                        <button onClick={() => navigate('/orders')} className="text-xs text-blue-600 mt-4 hover:underline">Ver todos</button>
                    )}
                </div>
            </div>
        </div>
    );
};