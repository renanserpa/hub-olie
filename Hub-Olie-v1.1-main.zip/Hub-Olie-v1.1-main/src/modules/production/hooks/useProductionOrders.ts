import { useEffect, useState } from 'react';
import { supabase, isMockMode } from '../../../lib/supabase/client';
import { ProductionOrder } from '../../../types';
import { useApp } from '../../../contexts/AppContext';
import { MOCK_PRODUCTION_ORDERS } from '../../../services/mockData';

export const useProductionOrders = () => {
    const { organization } = useApp();
    const [productionOrders, setProductionOrders] = useState<ProductionOrder[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    const fetchOrders = async () => {
        if (!organization) return;

        setLoading(true);
        setError(null);

        // Mock Mode Fallback
        if (isMockMode) {
            setTimeout(() => {
                const mockData = MOCK_PRODUCTION_ORDERS.filter(o => o.organization_id === organization.id);
                setProductionOrders(mockData);
                setLoading(false);
            }, 600);
            return;
        }

        try {
            const { data, error } = await supabase
                .from('production_orders')
                .select('*, order:orders(code)')
                .eq('organization_id', organization.id)
                .order('created_at', { ascending: false });

            if (error) throw error;
            
            const typedData = (data || []).map((item: any) => ({
                ...item,
                order: Array.isArray(item.order) ? item.order[0] : item.order
            }));

            setProductionOrders(typedData as ProductionOrder[]);
        } catch (err: any) {
            console.error("Error fetching production orders:", err);
            setError(err.message || 'Erro ao carregar OPs.');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchOrders();
    }, [organization]);

    return { productionOrders, loading, error, refetch: fetchOrders };
};