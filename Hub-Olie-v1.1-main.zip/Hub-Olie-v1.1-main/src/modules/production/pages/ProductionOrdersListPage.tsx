import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useProductionOrders } from '../hooks/useProductionOrders';
import { useDebounce } from '../../../hooks/useDebounce';
import { useTitle } from '../../../hooks/useTitle';
import { Button } from '../../../components/shared/Button';
import { Badge } from '../../../components/shared/Badge';
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell, TableEmptyState, TableSkeleton } from '../../../components/shared/Table';
import { ErrorState } from '../../../components/shared/FeedbackStates';
import { PRODUCTION_STATUS_LABELS, PRODUCTION_STATUS_COLORS, PRODUCTION_PRIORITY_LABELS, PRODUCTION_PRIORITY_COLORS } from '../../../constants';
import { Scissors, Search, Filter } from 'lucide-react';
import { ProductionStatus, ProductionPriority } from '../../../types';

export const ProductionOrdersListPage: React.FC = () => {
    useTitle('Produção | OlieHub');
    const navigate = useNavigate();
    const { productionOrders, loading, error, refetch } = useProductionOrders();
    const [searchTerm, setSearchTerm] = useState('');
    const debouncedSearchTerm = useDebounce(searchTerm, 300);

    const filteredOPs = useMemo(() => {
        return productionOrders.filter(op => {
            const term = debouncedSearchTerm.toLowerCase();
            const code = op.code.toLowerCase();
            const orderRef = op.order?.code?.toLowerCase() || '';
            return code.includes(term) || orderRef.includes(term);
        });
    }, [productionOrders, debouncedSearchTerm]);
    
    if (error) return <ErrorState message={error} onRetry={refetch} />;

    return (
        <div className="space-y-6 animate-in fade-in duration-500">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900">Produção</h1>
                    <p className="text-sm text-gray-500">Gerencie suas Ordens de Produção (OPs)</p>
                </div>
            </div>

            <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 flex flex-col sm:flex-row gap-4 items-center">
                <div className="relative flex-1 w-full">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Search size={16} className="text-gray-400" />
                    </div>
                    <input 
                        type="text" 
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        placeholder="Buscar OP ou Pedido..." 
                        className="pl-10 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm h-9 border"
                    />
                </div>
                <Button variant="secondary" className="w-full sm:w-auto">
                    <Filter size={16} className="mr-2" />
                    Filtros
                </Button>
            </div>

            <Table>
                <TableHeader>
                    <TableHead>Código OP</TableHead>
                    <TableHead>Pedido Ref</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Prioridade</TableHead>
                    <TableHead>Início Plan.</TableHead>
                    <TableHead>Fim Plan.</TableHead>
                    <TableHead align="right"><span className="sr-only">Ações</span></TableHead>
                </TableHeader>
                <TableBody>
                    {loading ? (
                        <TableSkeleton columns={7} rows={5} />
                    ) : filteredOPs.length > 0 ? (
                        filteredOPs.map((op) => (
                            <TableRow 
                                key={op.id} 
                                onClick={() => navigate(`/production/${op.id}`)}
                                className="cursor-pointer"
                            >
                                <TableCell className="font-medium text-blue-600">
                                    {op.code}
                                </TableCell>
                                <TableCell className="text-gray-500">
                                    {op.order?.code || '-'}
                                </TableCell>
                                <TableCell>
                                    <Badge colorClass={PRODUCTION_STATUS_COLORS[op.status as ProductionStatus]}>
                                        {PRODUCTION_STATUS_LABELS[op.status as ProductionStatus] || op.status}
                                    </Badge>
                                </TableCell>
                                <TableCell className="text-gray-900">
                                     <Badge colorClass={PRODUCTION_PRIORITY_COLORS[op.priority as ProductionPriority]}>
                                        {PRODUCTION_PRIORITY_LABELS[op.priority as ProductionPriority] || op.priority}
                                    </Badge>
                                </TableCell>
                                <TableCell className="text-gray-500">
                                    {op.planned_start_date ? new Date(op.planned_start_date).toLocaleDateString() : '-'}
                                </TableCell>
                                <TableCell className="text-gray-500">
                                    {op.planned_end_date ? new Date(op.planned_end_date).toLocaleDateString() : '-'}
                                </TableCell>
                                <TableCell align="right">
                                    <span className="text-blue-600 hover:text-blue-900 font-medium">Detalhes</span>
                                </TableCell>
                            </TableRow>
                        ))
                    ) : (
                        <TableEmptyState colSpan={7} message={searchTerm ? 'Nenhuma OP encontrada para a busca.' : 'Nenhuma OP cadastrada.'}>
                            {!searchTerm && (
                                <div className="mt-4 flex flex-col items-center">
                                    <div className="h-12 w-12 text-gray-400 mb-2">
                                        <Scissors size={48} />
                                    </div>
                                    <Button onClick={() => navigate('/orders')} size="sm">Ir para Pedidos</Button>
                                </div>
                            )}
                        </TableEmptyState>
                    )}
                </TableBody>
            </Table>
        </div>
    );
};