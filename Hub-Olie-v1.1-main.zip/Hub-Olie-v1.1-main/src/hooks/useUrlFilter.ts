import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useDebounce } from './useDebounce';

export function useUrlFilter(paramName: string = 'q', delay: number = 300) {
    const [searchParams, setSearchParams] = useSearchParams();
    
    // Initialize state from URL
    const [searchTerm, setSearchTerm] = useState(searchParams.get(paramName) || '');
    
    // Debounce the input value
    const debouncedSearchTerm = useDebounce(searchTerm, delay);

    // Update URL when debounced value changes
    useEffect(() => {
        if (debouncedSearchTerm) {
            setSearchParams(prev => {
                prev.set(paramName, debouncedSearchTerm);
                return prev;
            });
        } else {
            setSearchParams(prev => {
                prev.delete(paramName);
                return prev;
            });
        }
    }, [debouncedSearchTerm, paramName, setSearchParams]);

    return {
        searchTerm,
        setSearchTerm,
        debouncedSearchTerm
    };
}