import { Order, Organization, UserProfile, ProductionOrder, Customer } from "../types";

// Mock data to ensure the UI looks amazing even without immediate DB connection
export const MOCK_USER: UserProfile = {
    id: 'user-1',
    email: 'demo@oliehub.com',
    full_name: 'Ana Operations'
};

export const MOCK_ORGS: Organization[] = [
    { id: 'org-1', name: 'Ateliê Criativo', slug: 'atelie-criativo', created_at: new Date().toISOString() },
    { id: 'org-2', name: 'Moda Sustentável', slug: 'moda-sustentavel', created_at: new Date().toISOString() }
];

export const MOCK_CUSTOMERS: Customer[] = [
    { id: 'cust-1', name: 'João Silva', email: 'joao@email.com', phone: '11999999999', organization_id: 'org-1' },
    { id: 'cust-2', name: 'Maria Souza', email: 'maria@email.com', phone: '11988888888', organization_id: 'org-1' },
    { id: 'cust-3', name: 'Empresa X', email: 'contato@empresax.com', phone: '1133333333', organization_id: 'org-1' }
];

export const MOCK_ORDERS: Order[] = [
    {
        id: 'ord-1',
        organization_id: 'org-1',
        code: 'PED-2025-001',
        customer_id: 'cust-1',
        customer: MOCK_CUSTOMERS[0],
        status: 'CONFIRMED',
        order_date: '2025-01-10',
        due_date: '2025-01-25',
        total_gross_amount: 1500,
        discount_amount: 0,
        total_net_amount: 1500,
        created_at: '2025-01-10T10:00:00Z',
        items: [
            { 
                id: 'item-1', 
                organization_id: 'org-1',
                order_id: 'ord-1', 
                description: 'Camiseta Personalizada', 
                quantity: 50, 
                unit_price: 30, 
                total_price: 1500 
            }
        ]
    },
    {
        id: 'ord-2',
        organization_id: 'org-1',
        code: 'PED-2025-002',
        customer_id: 'cust-2',
        customer: MOCK_CUSTOMERS[1],
        status: 'IN_PRODUCTION',
        order_date: '2025-01-12',
        due_date: '2025-01-20',
        total_gross_amount: 2500,
        discount_amount: 100,
        total_net_amount: 2400,
        created_at: '2025-01-12T14:30:00Z',
        items: [
            { 
                id: 'item-2', 
                organization_id: 'org-1',
                order_id: 'ord-2', 
                description: 'Ecobag Algodão', 
                quantity: 100, 
                unit_price: 25, 
                total_price: 2500 
            }
        ]
    },
    {
        id: 'ord-3',
        organization_id: 'org-1',
        code: 'PED-2025-003',
        customer_id: 'cust-3',
        customer: MOCK_CUSTOMERS[2],
        status: 'QUOTE',
        order_date: '2025-01-15',
        due_date: '2025-02-01',
        total_gross_amount: 5000,
        discount_amount: 0,
        total_net_amount: 5000,
        created_at: '2025-01-15T09:00:00Z',
        items: []
    }
];

export const MOCK_PRODUCTION_ORDERS: ProductionOrder[] = [
    {
        id: 'op-1',
        organization_id: 'org-1',
        order_id: 'ord-2',
        code: 'OP-1705001',
        status: 'IN_PROGRESS',
        priority: 'HIGH',
        planned_start_date: '2025-01-13',
        planned_end_date: '2025-01-18',
        actual_start_date: '2025-01-13',
        actual_end_date: null,
        notes: 'Estampa em silkscreen',
        created_at: '2025-01-13T08:00:00Z',
        order: { code: 'PED-2025-002' }
    }
];