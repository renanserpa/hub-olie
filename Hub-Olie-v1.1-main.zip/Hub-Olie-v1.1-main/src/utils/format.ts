export const formatCurrency = (value: number | undefined | null) => {
    if (value === undefined || value === null) return 'R$ 0,00';
    return new Intl.NumberFormat('pt-BR', { 
        style: 'currency', 
        currency: 'BRL' 
    }).format(value);
};

export const formatDate = (dateString: string | undefined | null) => {
    if (!dateString) return '-';
    // Fix timezone issues by treating YYYY-MM-DD as UTC or appending time if missing
    const date = new Date(dateString.includes('T') ? dateString : `${dateString}T12:00:00`);
    return new Intl.DateTimeFormat('pt-BR').format(date);
};