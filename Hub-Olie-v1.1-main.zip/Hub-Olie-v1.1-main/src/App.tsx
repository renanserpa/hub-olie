import React from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AppProvider, useApp } from './contexts/AppContext';
import { Layout } from './components/Layout';
import { LoginPage } from './modules/auth/LoginPage';
import { OrganizationSelectPage } from './modules/organizations/OrganizationSelectPage';
import { OrdersListPage } from './modules/orders/pages/OrdersListPage';
import { OrderDetailPage } from './modules/orders/pages/OrderDetailPage';
import { OrderFormPage } from './modules/orders/pages/OrderFormPage';

// Protected Route Wrapper
const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const { user, organization, loading } = useApp();

    if (loading) {
        return <div className="h-screen flex items-center justify-center bg-gray-50">Carregando OlieHub...</div>;
    }

    if (!user) {
        return <Navigate to="/login" replace />;
    }

    if (!organization) {
        return <Navigate to="/select-org" replace />;
    }

    return <Layout>{children}</Layout>;
};

// Route that requires User but NO Organization selected yet
const OrgSelectionRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const { user, loading } = useApp();
    
    if (loading) return <div>...</div>;
    if (!user) return <Navigate to="/login" replace />;
    
    return <>{children}</>;
};

function AppRoutes() {
    return (
        <Routes>
            <Route path="/login" element={<LoginPage />} />
            
            <Route path="/select-org" element={
                <OrgSelectionRoute>
                    <OrganizationSelectPage />
                </OrgSelectionRoute>
            } />

            {/* Orders Module */}
            <Route path="/orders" element={
                <ProtectedRoute>
                    <OrdersListPage />
                </ProtectedRoute>
            } />
            <Route path="/orders/new" element={
                <ProtectedRoute>
                    <OrderFormPage />
                </ProtectedRoute>
            } />
             <Route path="/orders/:id" element={
                <ProtectedRoute>
                    <OrderDetailPage />
                </ProtectedRoute>
            } />

            {/* Fallback for now */}
            <Route path="/" element={<Navigate to="/orders" replace />} />
            
            {/* Placeholders for future routes to avoid 404s if linked */}
            <Route path="/production" element={<ProtectedRoute><div className="p-8">Módulo Produção (Em breve)</div></ProtectedRoute>} />
            <Route path="/inventory" element={<ProtectedRoute><div className="p-8">Módulo Estoque (Em breve)</div></ProtectedRoute>} />
        </Routes>
    );
}

export default function App() {
    return (
        <AppProvider>
            <HashRouter>
                <AppRoutes />
            </HashRouter>
        </AppProvider>
    );
}