import React, { createContext, useContext, useEffect, useState } from 'react';
import { supabase, isMockMode } from '../lib/supabase/client';
import { Organization, UserProfile } from '../types';
import { MOCK_USER, MOCK_ORGS } from '../services/mockData';

interface AppContextType {
    user: UserProfile | null;
    organization: Organization | null;
    availableOrganizations: Organization[];
    loading: boolean;
    setOrganization: (org: Organization) => void;
    signIn: (email: string, password: string) => Promise<{ error: any }>;
    signOut: () => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const [user, setUser] = useState<UserProfile | null>(null);
    const [organization, setOrganizationState] = useState<Organization | null>(null);
    const [availableOrganizations, setAvailableOrganizations] = useState<Organization[]>([]);
    const [loading, setLoading] = useState(true);

    // Initial load logic
    useEffect(() => {
        const initSession = async () => {
            try {
                // 1. Check Mock Mode first
                if (isMockMode) {
                    console.log("Running in Mock Mode");
                    // Simulate auth check delay
                    setTimeout(() => {
                        // For demo purposes, if mock mode, assume logged in if token present or just for demo
                        // Here we start unauthenticated to show login screen
                        setLoading(false);
                    }, 500);
                    return;
                }

                // 1. Get Session (Real)
                const { data: { session } } = await supabase.auth.getSession();
                
                if (session?.user) {
                    const currentUser: UserProfile = { 
                        id: session.user.id, 
                        email: session.user.email || '' 
                    };
                    setUser(currentUser);

                    // 2. Fetch User Organizations
                    // Query assumption: user_organization_role links user to organization
                    const { data: roles, error } = await supabase
                        .from('user_organization_role')
                        .select('organization:organization_id(*)')
                        .eq('user_id', currentUser.id);

                    if (error) {
                        console.error('Error fetching orgs:', error);
                    } else if (roles) {
                        // Extract organizations from the role relation
                        // The query returns { organization: { ... } } structure
                        const orgs = roles
                            .map((r: any) => r.organization)
                            .filter((o: any) => o !== null) as Organization[];
                        
                        setAvailableOrganizations(orgs);

                        // 3. Restore active organization from localStorage if valid
                        const storedOrgId = localStorage.getItem('oliehub_active_org');
                        if (storedOrgId) {
                            const match = orgs.find(o => o.id === storedOrgId);
                            if (match) setOrganizationState(match);
                        }
                    }
                }
            } catch (error) {
                console.error("Auth init error:", error);
            } finally {
                setLoading(false);
            }
        };

        initSession();

        // Listen for auth changes
        const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
             if (event === 'SIGNED_IN' && session?.user) {
                 setUser({ id: session.user.id, email: session.user.email || '' });
                 window.location.reload(); 
             } else if (event === 'SIGNED_OUT') {
                 setUser(null);
                 setOrganizationState(null);
                 setAvailableOrganizations([]);
                 localStorage.removeItem('oliehub_active_org');
             }
        });

        return () => subscription.unsubscribe();
    }, []);

    const setOrganization = (org: Organization) => {
        setOrganizationState(org);
        localStorage.setItem('oliehub_active_org', org.id);
    };

    const signIn = async (email: string, password: string) => {
        if (isMockMode) {
            // Simulate login for mock mode
            await new Promise(resolve => setTimeout(resolve, 800));
            setUser(MOCK_USER);
            setAvailableOrganizations(MOCK_ORGS);
            return { error: null };
        }

        const { data, error } = await supabase.auth.signInWithPassword({
            email,
            password
        });
        return { error };
    };

    const signOut = async () => {
        if (isMockMode) {
            setUser(null);
            setOrganizationState(null);
            setAvailableOrganizations([]);
            localStorage.removeItem('oliehub_active_org');
            return;
        }
        await supabase.auth.signOut();
    };

    return (
        <AppContext.Provider value={{ 
            user, 
            organization, 
            availableOrganizations, 
            loading, 
            setOrganization, 
            signIn, 
            signOut 
        }}>
            {children}
        </AppContext.Provider>
    );
};

export const useApp = () => {
    const context = useContext(AppContext);
    if (!context) throw new Error("useApp must be used within AppProvider");
    return context;
};