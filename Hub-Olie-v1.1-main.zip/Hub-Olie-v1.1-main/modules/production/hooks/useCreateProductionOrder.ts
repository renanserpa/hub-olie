import { useState } from 'react';
import { supabase } from '../../../lib/supabase/client';
import { useApp } from '../../../contexts/AppContext';
import { Order } from '../../../types';

export const useCreateProductionOrder = () => {
    const { organization } = useApp();
    const [creating, setCreating] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const createFromOrder = async (order: Order) => {
        if (!organization) return null;
        
        setCreating(true);
        setError(null);

        try {
            const code = `OP-${Date.now()}`;
            const today = new Date().toISOString().split('T')[0];

            const { data, error } = await supabase
                .from('production_orders')
                .insert({
                    organization_id: organization.id,
                    order_id: order.id,
                    code: code,
                    status: 'PLANNED',
                    priority: 'MEDIUM',
                    planned_start_date: today,
                    planned_end_date: order.due_date,
                    notes: order.notes
                })
                .select()
                .single();

            if (error) throw error;
            return data;

        } catch (err: any) {
            console.error("Error creating OP:", err);
            setError(err.message || "Erro ao criar Ordem de Produção.");
            throw err;
        } finally {
            setCreating(false);
        }
    };

    return { createFromOrder, creating, error };
};