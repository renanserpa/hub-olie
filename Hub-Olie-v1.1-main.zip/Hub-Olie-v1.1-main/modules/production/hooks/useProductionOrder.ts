import { useEffect, useState } from 'react';
import { supabase } from '../../../lib/supabase/client';
import { ProductionOrder, ProductionStatus } from '../../../types';
import { useApp } from '../../../contexts/AppContext';

export const useProductionOrder = (productionOrderId: string | undefined) => {
    const { organization } = useApp();
    const [productionOrder, setProductionOrder] = useState<ProductionOrder | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const fetchOrder = async () => {
            if (!organization || !productionOrderId) return;

            setLoading(true);
            setError(null);
            try {
                const { data, error } = await supabase
                    .from('production_orders')
                    .select('*, order:orders(code)')
                    .eq('id', productionOrderId)
                    .eq('organization_id', organization.id)
                    .single();

                if (error) throw error;

                const typedData: ProductionOrder = {
                    ...data,
                    order: Array.isArray(data.order) ? data.order[0] : data.order
                };

                setProductionOrder(typedData);
            } catch (err: any) {
                console.error("Error fetching production order detail:", err);
                setError(err.message || 'Erro ao carregar detalhes da OP.');
            } finally {
                setLoading(false);
            }
        };

        fetchOrder();
    }, [productionOrderId, organization]);

    const updateStatus = async (newStatus: ProductionStatus) => {
        if (!organization || !productionOrderId) return;

        try {
            const updates: any = { status: newStatus };
            const now = new Date().toISOString();

            if (newStatus === 'IN_PROGRESS') {
                updates.actual_start_date = now;
            } else if (newStatus === 'DONE') {
                updates.actual_end_date = now;
            }

            const { data, error } = await supabase
                .from('production_orders')
                .update(updates)
                .eq('id', productionOrderId)
                .select()
                .single();

            if (error) throw error;
            
            setProductionOrder(prev => prev ? { ...prev, ...data } : null);
            return data;

        } catch (err: any) {
            console.error("Error updating status:", err);
            throw err;
        }
    };

    return { productionOrder, loading, error, updateStatus };
};