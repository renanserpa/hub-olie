import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useProductionOrders } from '../hooks/useProductionOrders';
import { Button } from '../../../components/shared/Button';
import { PRODUCTION_STATUS_LABELS, PRODUCTION_STATUS_COLORS, PRODUCTION_PRIORITY_LABELS } from '../../../constants';
import { Scissors, Search, Filter } from 'lucide-react';
import { ProductionStatus, ProductionPriority } from '../../../types';

export const ProductionOrdersListPage: React.FC = () => {
    const navigate = useNavigate();
    const { productionOrders, loading, error } = useProductionOrders();

    if (loading) return (
        <div className="flex h-64 items-center justify-center">
            <div className="text-gray-500 animate-pulse">Carregando produção...</div>
        </div>
    );
    
    if (error) return (
        <div className="p-8 text-center bg-red-50 rounded-lg border border-red-200 text-red-700 m-4">
            <p>Ocorreu um erro ao carregar as OPs.</p>
            <p className="text-sm mt-2 font-mono">{error}</p>
        </div>
    );

    return (
        <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900">Produção</h1>
                    <p className="text-sm text-gray-500">Gerencie suas Ordens de Produção (OPs)</p>
                </div>
            </div>

            <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 flex flex-col sm:flex-row gap-4 items-center">
                <div className="relative flex-1 w-full">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Search size={16} className="text-gray-400" />
                    </div>
                    <input 
                        type="text" 
                        placeholder="Buscar OP..." 
                        className="pl-10 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm h-9 border"
                    />
                </div>
                <Button variant="secondary" className="w-full sm:w-auto">
                    <Filter size={16} className="mr-2" />
                    Filtros
                </Button>
            </div>

            <div className="bg-white shadow-sm rounded-lg border border-gray-200 overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                            <tr>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Código OP</th>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Pedido Ref</th>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Prioridade</th>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Início Plan.</th>
                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fim Plan.</th>
                                <th scope="col" className="relative px-6 py-3"><span className="sr-only">Ações</span></th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                            {productionOrders.map((op) => (
                                <tr key={op.id} className="hover:bg-gray-50 cursor-pointer transition-colors" onClick={() => navigate(`/production/${op.id}`)}>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-blue-600">
                                        {op.code}
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        {op.order?.code || '-'}
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap">
                                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${PRODUCTION_STATUS_COLORS[op.status as ProductionStatus] || 'bg-gray-100'}`}>
                                            {PRODUCTION_STATUS_LABELS[op.status as ProductionStatus] || op.status}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        {PRODUCTION_PRIORITY_LABELS[op.priority as ProductionPriority] || op.priority}
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        {op.planned_start_date ? new Date(op.planned_start_date).toLocaleDateString() : '-'}
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        {op.planned_end_date ? new Date(op.planned_end_date).toLocaleDateString() : '-'}
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                        <span className="text-blue-600 hover:text-blue-900">Detalhes</span>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
                {productionOrders.length === 0 && (
                    <div className="p-12 text-center">
                        <div className="mx-auto h-12 w-12 text-gray-400">
                            <Scissors size={48} />
                        </div>
                        <h3 className="mt-2 text-sm font-medium text-gray-900">Nenhuma OP</h3>
                        <p className="mt-1 text-sm text-gray-500">Gere Ordens de Produção a partir dos Pedidos.</p>
                        <div className="mt-6">
                            <Button onClick={() => navigate('/orders')}>Ir para Pedidos</Button>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};