import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useProductionOrder } from '../hooks/useProductionOrder';
import { PRODUCTION_STATUS_LABELS, PRODUCTION_STATUS_COLORS, PRODUCTION_PRIORITY_LABELS } from '../../../constants';
import { Button } from '../../../components/shared/Button';
import { ChevronLeft, Calendar, User, ShoppingCart, PlayCircle, CheckCircle } from 'lucide-react';
import { ProductionStatus, ProductionPriority } from '../../../types';

export const ProductionOrderDetailPage: React.FC = () => {
    const { id } = useParams<{ id: string }>();
    const navigate = useNavigate();
    const { productionOrder, loading, error, updateStatus } = useProductionOrder(id);

    if (loading) return <div className="p-8 text-center text-gray-500">Carregando OP...</div>;
    
    if (error || !productionOrder) return (
        <div className="p-8 text-center">
            <div className="text-red-500 mb-4">{error || 'OP não encontrada.'}</div>
            <Button variant="outline" onClick={() => navigate('/production')}>Voltar para Lista</Button>
        </div>
    );

    const handleStatusChange = async (status: ProductionStatus) => {
        try {
            await updateStatus(status);
        } catch (e) {
            console.error("Failed status update", e);
            alert("Erro ao atualizar status");
        }
    };

    return (
        <div className="space-y-6">
            <div className="flex items-center gap-4 mb-6">
                <button onClick={() => navigate('/production')} className="p-2 hover:bg-gray-100 rounded-full text-gray-500">
                    <ChevronLeft size={20} />
                </button>
                <div>
                    <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-3">
                        {productionOrder.code}
                        <span className={`text-sm px-3 py-1 rounded-full font-medium ${PRODUCTION_STATUS_COLORS[productionOrder.status as ProductionStatus]}`}>
                            {PRODUCTION_STATUS_LABELS[productionOrder.status as ProductionStatus]}
                        </span>
                    </h1>
                    <div className="flex items-center gap-2 mt-1">
                        <span className="text-sm text-gray-500">Prioridade: {PRODUCTION_PRIORITY_LABELS[productionOrder.priority as ProductionPriority]}</span>
                    </div>
                </div>
                
                <div className="ml-auto flex gap-2">
                    {productionOrder.status === 'PLANNED' && (
                        <Button onClick={() => handleStatusChange('IN_PROGRESS')}>
                            <PlayCircle size={16} className="mr-2" />
                            Iniciar Produção
                        </Button>
                    )}
                    {productionOrder.status === 'IN_PROGRESS' && (
                        <Button onClick={() => handleStatusChange('DONE')} className="bg-green-600 hover:bg-green-700 focus:ring-green-500">
                            <CheckCircle size={16} className="mr-2" />
                            Concluir
                        </Button>
                    )}
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 space-y-6">
                    <div className="bg-white shadow-sm rounded-lg border border-gray-200 p-6">
                        <h3 className="text-lg font-medium text-gray-900 mb-4">Detalhes da Produção</h3>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-500">Pedido Associado</label>
                                <button 
                                    onClick={() => navigate(`/orders/${productionOrder.order_id}`)}
                                    className="mt-1 flex items-center text-blue-600 hover:text-blue-800"
                                >
                                    <ShoppingCart size={16} className="mr-1" />
                                    {productionOrder.order?.code || 'Ver Pedido'}
                                </button>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-500">Notas</label>
                                <p className="mt-1 text-sm text-gray-900">{productionOrder.notes || 'Sem notas.'}</p>
                            </div>
                        </div>
                    </div>

                    <div className="bg-white shadow-sm rounded-lg border border-gray-200 p-6 opacity-75">
                         <h3 className="text-lg font-medium text-gray-900 mb-2">Etapas de Produção</h3>
                         <p className="text-sm text-gray-500 mb-4">Corte, Costura, Acabamento, etc.</p>
                         <div className="bg-gray-50 p-4 rounded text-center text-gray-400 text-sm border border-dashed border-gray-300">
                            Funcionalidade de etapas em desenvolvimento.
                         </div>
                    </div>
                </div>

                <div className="space-y-6">
                    <div className="bg-white p-6 shadow-sm rounded-lg border border-gray-200">
                        <h3 className="text-sm font-medium text-gray-900 mb-4 flex items-center gap-2">
                            <Calendar size={18} /> Cronograma
                        </h3>
                        <dl className="space-y-3 text-sm">
                            <div className="flex justify-between">
                                <dt className="text-gray-500">Início Planejado</dt>
                                <dd className="text-gray-900">{productionOrder.planned_start_date ? new Date(productionOrder.planned_start_date).toLocaleDateString() : '-'}</dd>
                            </div>
                            <div className="flex justify-between">
                                <dt className="text-gray-500">Fim Planejado</dt>
                                <dd className="text-gray-900">{productionOrder.planned_end_date ? new Date(productionOrder.planned_end_date).toLocaleDateString() : '-'}</dd>
                            </div>
                            <div className="border-t border-gray-100 my-2 pt-2"></div>
                             <div className="flex justify-between">
                                <dt className="text-gray-500">Início Real</dt>
                                <dd className="text-blue-700 font-medium">{productionOrder.actual_start_date ? new Date(productionOrder.actual_start_date).toLocaleDateString() : '-'}</dd>
                            </div>
                            <div className="flex justify-between">
                                <dt className="text-gray-500">Fim Real</dt>
                                <dd className="text-green-700 font-medium">{productionOrder.actual_end_date ? new Date(productionOrder.actual_end_date).toLocaleDateString() : '-'}</dd>
                            </div>
                        </dl>
                    </div>

                     <div className="bg-white p-6 shadow-sm rounded-lg border border-gray-200">
                        <h3 className="text-sm font-medium text-gray-900 mb-4 flex items-center gap-2">
                            <User size={18} /> Equipe
                        </h3>
                        <p className="text-sm text-gray-500">Responsável não atribuído.</p>
                        <Button variant="outline" size="sm" className="mt-3 w-full" disabled>Atribuir</Button>
                    </div>
                </div>
            </div>
        </div>
    );
};