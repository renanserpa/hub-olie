import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../../../contexts/AppContext';
import { supabase } from '../../../lib/supabase/client';
import { useUpsertOrder } from '../hooks/useUpsertOrder';
import { Customer, OrderItemInput, OrderStatus } from '../../../types';
import { Button } from '../../../components/shared/Button';
import { ChevronLeft, Trash2, Plus, AlertCircle } from 'lucide-react';

interface OrderItemDraft {
    id: number; // local temp id
    product_name: string;
    quantity: number;
    unit_price: number;
}

export const OrderFormPage: React.FC = () => {
    const navigate = useNavigate();
    const { organization } = useApp();
    const { upsertOrder, loading: saving, error: saveError } = useUpsertOrder();
    
    // Data Loading State
    const [customers, setCustomers] = useState<Customer[]>([]);
    const [loadingCustomers, setLoadingCustomers] = useState(true);

    // Form State
    const [customerId, setCustomerId] = useState('');
    const [status, setStatus] = useState<OrderStatus>('QUOTE');
    const [orderDate, setOrderDate] = useState(new Date().toISOString().split('T')[0]);
    const [dueDate, setDueDate] = useState('');
    const [discount, setDiscount] = useState<number>(0);
    const [notes, setNotes] = useState('');
    
    const [items, setItems] = useState<OrderItemDraft[]>([
        { id: Date.now(), product_name: '', quantity: 1, unit_price: 0 }
    ]);

    // Validation Feedback
    const [formError, setFormError] = useState<string | null>(null);

    // Fetch Customers on Mount
    useEffect(() => {
        const fetchCustomers = async () => {
            if (!organization) return;
            try {
                const { data, error } = await supabase
                    .from('customer')
                    .select('*')
                    .eq('organization_id', organization.id)
                    .order('name');
                
                if (error) throw error;
                setCustomers(data as Customer[]);
            } catch (err) {
                console.error("Error fetching customers:", err);
            } finally {
                setLoadingCustomers(false);
            }
        };
        fetchCustomers();
    }, [organization]);

    // Item Management Handlers
    const handleAddItem = () => {
        setItems([...items, { id: Date.now(), product_name: '', quantity: 1, unit_price: 0 }]);
    };

    const handleRemoveItem = (id: number) => {
        if (items.length > 1) {
            setItems(items.filter(i => i.id !== id));
        }
    };

    const updateItem = (id: number, field: keyof OrderItemDraft, value: string | number) => {
        setItems(items.map(i => i.id === id ? { ...i, [field]: value } : i));
    };

    // Calculations
    const totalGross = items.reduce((sum, item) => sum + (item.quantity * item.unit_price), 0);
    const totalNet = Math.max(0, totalGross - discount);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setFormError(null);

        // Validations
        if (!customerId) {
            setFormError("Por favor, selecione um cliente.");
            return;
        }
        if (!dueDate) {
            setFormError("Por favor, defina a data de entrega.");
            return;
        }
        
        const invalidItems = items.filter(i => !i.product_name.trim() || i.quantity <= 0 || i.unit_price <= 0);
        if (invalidItems.length > 0) {
            setFormError("Existem itens inválidos. Verifique descrição, quantidade e preço.");
            return;
        }

        // Map to API Input
        const itemsInput: OrderItemInput[] = items.map(i => ({
            description: i.product_name,
            quantity: i.quantity,
            unit_price: i.unit_price
        }));

        try {
            await upsertOrder({
                customer_id: customerId,
                status: status,
                order_date: orderDate,
                due_date: dueDate,
                discount_amount: discount,
                notes: notes,
                items: itemsInput
            });
            // On success, redirect
            navigate('/orders');
        } catch (err) {
            // Error is handled by hook and displayed via saveError, 
            // but we catch here to prevent unhandled promise rejection in console
        }
    };

    return (
        <div className="max-w-4xl mx-auto space-y-6 pb-20">
            <div className="flex items-center gap-4">
                <button onClick={() => navigate('/orders')} className="p-2 hover:bg-gray-100 rounded-full text-gray-500">
                    <ChevronLeft size={20} />
                </button>
                <div>
                    <h1 className="text-2xl font-bold text-gray-900">Novo Pedido</h1>
                    <p className="text-sm text-gray-500">Preencha os dados para criar um novo pedido ou orçamento.</p>
                </div>
            </div>

            {/* Global Errors */}
            {(formError || saveError) && (
                <div className="bg-red-50 border-l-4 border-red-400 p-4 rounded-md flex items-center">
                    <AlertCircle className="text-red-500 mr-2" size={20} />
                    <p className="text-red-700 font-medium">{formError || saveError}</p>
                </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
                
                {/* Section 1: General Info */}
                <div className="bg-white p-6 shadow-sm rounded-lg border border-gray-200">
                    <h2 className="text-lg font-medium text-gray-900 mb-4 pb-2 border-b border-gray-100">Informações Gerais</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        
                        {/* Customer Select */}
                        <div>
                            <label className="block text-sm font-medium text-gray-700">Cliente <span className="text-red-500">*</span></label>
                            {loadingCustomers ? (
                                <div className="mt-1 text-sm text-gray-400">Carregando clientes...</div>
                            ) : customers.length === 0 ? (
                                <div className="mt-1 text-sm text-red-500 border border-red-200 bg-red-50 p-2 rounded">
                                    Nenhum cliente encontrado. Cadastre um cliente primeiro no banco de dados.
                                </div>
                            ) : (
                                <select 
                                    value={customerId}
                                    onChange={(e) => setCustomerId(e.target.value)}
                                    className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md border"
                                    required
                                >
                                    <option value="">Selecione um cliente...</option>
                                    {customers.map(c => (
                                        <option key={c.id} value={c.id}>{c.name}</option>
                                    ))}
                                </select>
                            )}
                        </div>

                        {/* Status Select */}
                        <div>
                            <label className="block text-sm font-medium text-gray-700">Status Inicial</label>
                            <select 
                                value={status}
                                onChange={(e) => setStatus(e.target.value as OrderStatus)}
                                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md border"
                            >
                                <option value="QUOTE">Orçamento</option>
                                <option value="CONFIRMED">Confirmado</option>
                            </select>
                        </div>

                        {/* Dates */}
                        <div>
                            <label className="block text-sm font-medium text-gray-700">Data do Pedido</label>
                            <input 
                                type="date" 
                                required
                                value={orderDate}
                                onChange={(e) => setOrderDate(e.target.value)}
                                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700">Previsão de Entrega <span className="text-red-500">*</span></label>
                            <input 
                                type="date" 
                                required
                                value={dueDate}
                                onChange={(e) => setDueDate(e.target.value)}
                                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                            />
                        </div>
                    </div>

                    {/* Notes */}
                    <div className="mt-6">
                        <label className="block text-sm font-medium text-gray-700">Observações</label>
                        <textarea
                            rows={3}
                            value={notes}
                            onChange={(e) => setNotes(e.target.value)}
                            placeholder="Detalhes de personalização, entrega, etc."
                            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                        />
                    </div>
                </div>

                {/* Section 2: Items */}
                <div className="bg-white p-6 shadow-sm rounded-lg border border-gray-200">
                    <div className="flex justify-between items-center mb-4">
                        <h2 className="text-lg font-medium text-gray-900">Itens do Pedido</h2>
                        <Button type="button" variant="secondary" size="sm" onClick={handleAddItem}>
                            <Plus size={16} className="mr-1" /> Adicionar Item
                        </Button>
                    </div>
                    
                    <div className="space-y-4">
                        {items.map((item, index) => (
                            <div key={item.id} className="flex flex-col sm:flex-row gap-4 items-end bg-gray-50 p-4 rounded-md border border-gray-200">
                                <div className="flex-1 w-full">
                                    <label className="block text-xs font-medium text-gray-500 mb-1">Descrição do Produto</label>
                                    <input 
                                        type="text" 
                                        required
                                        placeholder="Ex: Camiseta Branca M"
                                        value={item.product_name}
                                        onChange={(e) => updateItem(item.id, 'product_name', e.target.value)}
                                        className="block w-full border border-gray-300 rounded-md shadow-sm py-1.5 px-3 sm:text-sm focus:ring-blue-500 focus:border-blue-500"
                                    />
                                </div>
                                <div className="w-24">
                                    <label className="block text-xs font-medium text-gray-500 mb-1">Qtd</label>
                                    <input 
                                        type="number" 
                                        min="1"
                                        required
                                        value={item.quantity}
                                        onChange={(e) => updateItem(item.id, 'quantity', parseInt(e.target.value) || 0)}
                                        className="block w-full border border-gray-300 rounded-md shadow-sm py-1.5 px-3 sm:text-sm focus:ring-blue-500 focus:border-blue-500"
                                    />
                                </div>
                                <div className="w-32">
                                    <label className="block text-xs font-medium text-gray-500 mb-1">Preço Unit.</label>
                                    <input 
                                        type="number" 
                                        min="0"
                                        step="0.01"
                                        required
                                        value={item.unit_price}
                                        onChange={(e) => updateItem(item.id, 'unit_price', parseFloat(e.target.value) || 0)}
                                        className="block w-full border border-gray-300 rounded-md shadow-sm py-1.5 px-3 sm:text-sm focus:ring-blue-500 focus:border-blue-500"
                                    />
                                </div>
                                <div className="w-24 text-right pb-2 font-medium text-gray-700 text-sm">
                                    R$ {(item.quantity * item.unit_price).toFixed(2)}
                                </div>
                                <div className="pb-1.5">
                                    <button 
                                        type="button" 
                                        onClick={() => handleRemoveItem(item.id)}
                                        className="text-red-500 hover:text-red-700 p-1"
                                        title="Remover item"
                                        disabled={items.length === 1}
                                    >
                                        <Trash2 size={18} />
                                    </button>
                                </div>
                            </div>
                        ))}
                    </div>

                    {/* Totals Section */}
                    <div className="mt-6 flex flex-col items-end border-t border-gray-200 pt-4 gap-2">
                        <div className="flex justify-between w-64 text-sm">
                            <span className="text-gray-500">Subtotal:</span>
                            <span className="font-medium text-gray-900">R$ {totalGross.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between w-64 items-center">
                            <span className="text-sm text-gray-500">Desconto:</span>
                            <div className="flex items-center w-32">
                                <span className="text-gray-500 mr-1">R$</span>
                                <input 
                                    type="number" 
                                    min="0"
                                    step="0.01"
                                    value={discount}
                                    onChange={(e) => setDiscount(parseFloat(e.target.value) || 0)}
                                    className="block w-full border border-gray-300 rounded-md shadow-sm py-1 px-2 text-right text-sm focus:ring-blue-500 focus:border-blue-500"
                                />
                            </div>
                        </div>
                        <div className="flex justify-between w-64 text-lg font-bold mt-2 pt-2 border-t border-gray-100">
                            <span className="text-gray-900">Total Líquido:</span>
                            <span className="text-blue-600">R$ {totalNet.toFixed(2)}</span>
                        </div>
                    </div>
                </div>

                <div className="flex justify-end gap-4">
                    <Button type="button" variant="ghost" onClick={() => navigate('/orders')} disabled={saving}>
                        Cancelar
                    </Button>
                    <Button type="submit" isLoading={saving}>
                        {status === 'CONFIRMED' ? 'Criar Pedido' : 'Salvar Orçamento'}
                    </Button>
                </div>
            </form>
        </div>
    );
};