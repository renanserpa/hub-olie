import { useState } from 'react';
import { supabase } from '../../../lib/supabase/client';
import { UpsertOrderInput } from '../../../types';
import { useApp } from '../../../contexts/AppContext';

export const useUpsertOrder = () => {
    const { organization } = useApp();
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const upsertOrder = async (input: UpsertOrderInput) => {
        if (!organization) {
            const msg = "Organização não definida.";
            setError(msg);
            return null;
        }

        setLoading(true);
        setError(null);

        try {
            // 1. Calculate Totals
            const totalGross = input.items.reduce((sum, item) => sum + (item.quantity * item.unit_price), 0);
            const discount = input.discount_amount ?? 0;
            const totalNet = totalGross - discount;

            // 2. Generate Code (Simple strategy for MVP)
            const code = `ORD-${Date.now()}`;

            // 3. Insert Order Header
            // Using table 'orders' to avoid SQL reserved word conflicts with 'order'
            // Assumes columns: id, organization_id, customer_id, code, status, order_date, due_date, total_gross_amount, discount_amount, total_net_amount, notes
            const { data: orderData, error: orderError } = await supabase
                .from('orders')
                .insert({
                    organization_id: organization.id,
                    customer_id: input.customer_id,
                    code: code,
                    status: input.status,
                    order_date: input.order_date,
                    due_date: input.due_date,
                    total_gross_amount: totalGross,
                    discount_amount: discount,
                    total_net_amount: totalNet,
                    notes: input.notes ?? null
                })
                .select()
                .single();

            if (orderError) throw orderError;
            if (!orderData) throw new Error("Erro ao criar pedido: Nenhum dado retornado.");

            const newOrderId = orderData.id;

            // 4. Insert Order Items
            // Using table 'order_items'
            // Assumes columns: id, organization_id, order_id, description, quantity, unit_price, total_price
            if (input.items.length > 0) {
                const itemsPayload = input.items.map(item => ({
                    organization_id: organization.id,
                    order_id: newOrderId,
                    description: item.description,
                    quantity: item.quantity,
                    unit_price: item.unit_price,
                    total_price: item.quantity * item.unit_price
                }));

                const { error: itemsError } = await supabase
                    .from('order_items')
                    .insert(itemsPayload);

                if (itemsError) {
                    console.error("Failed to insert items", itemsError);
                    // In a real scenario, we might want to delete the created order header here (rollback)
                    throw itemsError;
                }
            }

            return orderData;

        } catch (err: any) {
            console.error("Error in upsertOrder:", err);
            setError(err.message || "Erro ao salvar pedido.");
            throw err;
        } finally {
            setLoading(false);
        }
    };

    return { upsertOrder, loading, error };
};