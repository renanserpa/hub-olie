import { useEffect, useState } from 'react';
import { supabase } from '../../../lib/supabase/client';
import { Order, OrderItem } from '../../../types';
import { useApp } from '../../../contexts/AppContext';

export const useOrder = (orderId: string | undefined) => {
    const { organization } = useApp();
    const [order, setOrder] = useState<Order | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const fetchOrder = async () => {
            if (!organization || !orderId) return;

            setLoading(true);
            setError(null);
            try {
                // 1. Fetch Order + Customer
                const { data: orderData, error: orderError } = await supabase
                    .from('order')
                    .select('*, customer(name, email, phone)')
                    .eq('id', orderId)
                    .eq('organization_id', organization.id)
                    .single();

                if (orderError) throw orderError;

                // 2. Fetch Order Items
                // Assuming table 'order_item'
                const { data: itemsData, error: itemsError } = await supabase
                    .from('order_item')
                    .select('*')
                    .eq('order_id', orderId)
                    .eq('organization_id', organization.id);

                if (itemsError) throw itemsError;

                // Combine data
                const fullOrder: Order = {
                    ...orderData,
                    items: itemsData as OrderItem[]
                };

                setOrder(fullOrder);

            } catch (err: any) {
                console.error("Error fetching order detail:", err);
                setError(err.message || 'Erro ao carregar detalhes do pedido.');
            } finally {
                setLoading(false);
            }
        };

        fetchOrder();
    }, [orderId, organization]);

    return { order, loading, error };
};
