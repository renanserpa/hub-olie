import { Order, Organization, UserProfile } from "../types";

// Mock data to ensure the UI looks amazing even without immediate DB connection
export const MOCK_USER: UserProfile = {
    id: 'user-1',
    email: 'demo@oliehub.com',
    full_name: 'Ana Operations'
};

export const MOCK_ORGS: Organization[] = [
    { id: 'org-1', name: 'Ateliê Criativo', slug: 'atelie-criativo', created_at: new Date().toISOString() },
    { id: 'org-2', name: 'Moda Sustentável', slug: 'moda-sustentavel', created_at: new Date().toISOString() }
];

export const MOCK_ORDERS: Order[] = [
    {
        id: 'ord-1',
        organization_id: 'org-1',
        code: 'PED-2025-001',
        customer_id: 'cust-1',
        customer: { id: 'cust-1', name: 'João Silva', organization_id: 'org-1' },
        status: 'CONFIRMED',
        order_date: '2025-01-10',
        due_date: '2025-01-25',
        total_gross_amount: 1500,
        discount_amount: 0,
        total_net_amount: 1500,
        created_at: '2025-01-10T10:00:00Z',
        items: [
            { 
                id: 'item-1', 
                organization_id: 'org-1',
                order_id: 'ord-1', 
                product_name: 'Camiseta Personalizada', 
                description: 'Camiseta Personalizada', 
                quantity: 50, 
                unit_price: 30, 
                total_price: 1500 
            }
        ]
    },
    {
        id: 'ord-2',
        organization_id: 'org-1',
        code: 'PED-2025-002',
        customer_id: 'cust-2',
        customer: { id: 'cust-2', name: 'Maria Souza', organization_id: 'org-1' },
        status: 'IN_PRODUCTION',
        order_date: '2025-01-12',
        due_date: '2025-01-20',
        total_gross_amount: 2500,
        discount_amount: 100,
        total_net_amount: 2400,
        created_at: '2025-01-12T14:30:00Z',
        items: [
            { 
                id: 'item-2', 
                organization_id: 'org-1',
                order_id: 'ord-2', 
                product_name: 'Ecobag Algodão', 
                description: 'Ecobag Algodão', 
                quantity: 100, 
                unit_price: 25, 
                total_price: 2500 
            }
        ]
    },
    {
        id: 'ord-3',
        organization_id: 'org-1',
        code: 'PED-2025-003',
        customer_id: 'cust-3',
        customer: { id: 'cust-3', name: 'Empresa X', organization_id: 'org-1' },
        status: 'QUOTE',
        order_date: '2025-01-15',
        due_date: '2025-02-01',
        total_gross_amount: 5000,
        discount_amount: 0,
        total_net_amount: 5000,
        created_at: '2025-01-15T09:00:00Z',
        items: []
    }
];