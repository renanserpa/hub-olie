import React from 'react';

// Organization & Auth Types
export interface Organization {
    id: string;
    name: string;
    slug: string;
    created_at: string;
}

export interface UserProfile {
    id: string;
    email: string;
    full_name?: string;
}

export interface UserOrganizationRole {
    id: string;
    user_id: string;
    organization_id: string;
    role: 'owner' | 'admin' | 'operations' | 'production' | 'finance' | 'viewer';
    organization?: Organization;
}

// Order Types
export type OrderStatus = 'QUOTE' | 'CONFIRMED' | 'IN_PRODUCTION' | 'READY' | 'SHIPPED' | 'COMPLETED' | 'CANCELLED';

export interface Customer {
    id: string;
    name: string;
    email?: string;
    phone?: string;
    organization_id: string;
}

export interface OrderItem {
    id: string;
    organization_id: string;
    order_id: string;
    description: string; // Mapped to product_name in UI logic often
    quantity: number;
    unit_price: number;
    total_price: number;
    product_name?: string; // UI convenience
}

export interface Order {
    id: string;
    organization_id: string;
    code: string;
    customer_id: string;
    customer?: Customer | { name: string } | null; 
    status: OrderStatus;
    order_date: string;
    due_date: string;
    total_gross_amount: number;
    discount_amount: number;
    total_net_amount: number;
    notes?: string | null;
    items?: OrderItem[];
    created_at: string;
}

// Production Types
export type ProductionStatus = 'PLANNED' | 'IN_PROGRESS' | 'DONE';
export type ProductionPriority = 'LOW' | 'MEDIUM' | 'HIGH';

export interface ProductionOrder {
    id: string;
    organization_id: string;
    order_id: string;
    code: string;
    status: ProductionStatus;
    priority: ProductionPriority;
    planned_start_date: string | null;
    planned_end_date: string | null;
    actual_start_date: string | null;
    actual_end_date: string | null;
    notes?: string;
    created_at: string;
    // Joined fields
    order?: { code: string }; 
}

// Inputs for Mutations (Create/Update)
export interface OrderItemInput {
    product_id?: string | null;
    description: string; // Corresponds to product_name in UI
    quantity: number;
    unit_price: number;
}

export interface UpsertOrderInput {
    id?: string; // If present, update; else create
    customer_id: string;
    status: OrderStatus; 
    order_date: string; // ISO date YYYY-MM-DD
    due_date: string; // ISO date YYYY-MM-DD
    discount_amount?: number;
    notes?: string;
    items: OrderItemInput[];
}

// UI Types
export interface NavItem {
    label: string;
    path: string;
    icon: React.ElementType;
}