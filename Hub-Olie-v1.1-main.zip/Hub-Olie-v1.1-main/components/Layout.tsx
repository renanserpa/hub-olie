import React from 'react';
import { NavLink } from 'react-router-dom'; // Using HashRouter in App.tsx
import { 
  LayoutDashboard, 
  ShoppingCart, 
  Package, 
  Scissors, 
  Truck, 
  CreditCard, 
  Settings, 
  LogOut,
  Building2
} from 'lucide-react';
import { useApp } from '../contexts/AppContext';

const NAV_ITEMS = [
    { label: 'Dashboard', path: '/', icon: LayoutDashboard },
    { label: 'Pedidos', path: '/orders', icon: ShoppingCart },
    { label: 'Produção', path: '/production', icon: Scissors },
    { label: 'Estoque', path: '/inventory', icon: Package },
    { label: 'Logística', path: '/logistics', icon: Truck },
    { label: 'Financeiro', path: '/finance', icon: CreditCard },
    { label: 'Configurações', path: '/settings', icon: Settings },
];

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const { organization, user, signOut, setOrganization, availableOrganizations } = useApp();

    return (
        <div className="flex h-screen bg-gray-50">
            {/* Sidebar */}
            <aside className="w-64 bg-white border-r border-gray-200 flex flex-col hidden md:flex">
                <div className="p-4 border-b border-gray-200 flex items-center gap-2">
                    <div className="bg-blue-600 p-1.5 rounded text-white">
                        <Building2 size={20} />
                    </div>
                    <div>
                        <h1 className="font-bold text-gray-800 text-sm leading-tight">OlieHub</h1>
                        <p className="text-xs text-gray-500 truncate w-32">{organization?.name}</p>
                    </div>
                </div>

                <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
                    {NAV_ITEMS.map((item) => (
                        <NavLink
                            key={item.path}
                            to={item.path}
                            className={({ isActive }) => `
                                flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors
                                ${isActive 
                                    ? 'bg-blue-50 text-blue-700' 
                                    : 'text-gray-700 hover:bg-gray-100'
                                }
                            `}
                        >
                            <item.icon size={18} className="mr-3" />
                            {item.label}
                        </NavLink>
                    ))}
                </nav>

                <div className="p-4 border-t border-gray-200">
                    <div className="flex items-center gap-3 mb-4">
                        <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-700 font-bold">
                            {user?.email?.charAt(0).toUpperCase()}
                        </div>
                        <div className="overflow-hidden">
                            <p className="text-sm font-medium text-gray-700 truncate">{user?.full_name || 'Usuário'}</p>
                            <p className="text-xs text-gray-500 truncate">{user?.email}</p>
                        </div>
                    </div>
                    
                    {availableOrganizations.length > 1 && (
                        <button 
                            onClick={() => setOrganization(availableOrganizations.find(o => o.id !== organization?.id) || organization!)}
                            className="text-xs text-blue-600 hover:underline mb-2 block"
                        >
                            Trocar Organização
                        </button>
                    )}

                    <button 
                        onClick={() => signOut()}
                        className="flex items-center w-full text-sm text-gray-500 hover:text-red-600 transition-colors"
                    >
                        <LogOut size={16} className="mr-2" />
                        Sair
                    </button>
                </div>
            </aside>

            {/* Mobile Header (Simplified for MVP) */}
            <div className="md:hidden absolute top-0 left-0 right-0 h-16 bg-white border-b z-10 flex items-center px-4">
                <span className="font-bold">OlieHub</span>
            </div>

            {/* Main Content */}
            <main className="flex-1 overflow-y-auto pt-16 md:pt-0">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 py-6">
                    {children}
                </div>
            </main>
        </div>
    );
};
