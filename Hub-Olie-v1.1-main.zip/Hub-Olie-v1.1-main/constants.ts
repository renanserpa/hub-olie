import { OrderStatus, ProductionPriority, ProductionStatus } from "./types";

export const APP_NAME = "OlieHub";

export const ORDER_STATUS_LABELS: Record<OrderStatus, string> = {
    QUOTE: 'Orçamento',
    CONFIRMED: 'Confirmado',
    IN_PRODUCTION: 'Em Produção',
    READY: 'Pronto',
    SHIPPED: 'Enviado',
    COMPLETED: 'Concluído',
    CANCELLED: 'Cancelado',
};

export const ORDER_STATUS_COLORS: Record<OrderStatus, string> = {
    QUOTE: 'bg-gray-100 text-gray-800',
    CONFIRMED: 'bg-blue-100 text-blue-800',
    IN_PRODUCTION: 'bg-yellow-100 text-yellow-800',
    READY: 'bg-indigo-100 text-indigo-800',
    SHIPPED: 'bg-purple-100 text-purple-800',
    COMPLETED: 'bg-green-100 text-green-800',
    CANCELLED: 'bg-red-100 text-red-800',
};

export const PRODUCTION_STATUS_LABELS: Record<ProductionStatus, string> = {
    PLANNED: 'Planejada',
    IN_PROGRESS: 'Em Produção',
    DONE: 'Concluída',
};

export const PRODUCTION_STATUS_COLORS: Record<ProductionStatus, string> = {
    PLANNED: 'bg-gray-100 text-gray-800',
    IN_PROGRESS: 'bg-blue-100 text-blue-800',
    DONE: 'bg-green-100 text-green-800',
};

export const PRODUCTION_PRIORITY_LABELS: Record<ProductionPriority, string> = {
    LOW: 'Baixa',
    MEDIUM: 'Média',
    HIGH: 'Alta',
};