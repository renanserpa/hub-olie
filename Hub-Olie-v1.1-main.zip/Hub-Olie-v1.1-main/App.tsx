import React from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AppProvider, useApp } from './contexts/AppContext';
import { Layout } from './components/Layout';
import { LoginPage } from './modules/auth/LoginPage';
import { OrganizationSelectPage } from './modules/organizations/OrganizationSelectPage';
import { OrdersListPage } from './modules/orders/pages/OrdersListPage';
import { OrderDetailPage } from './modules/orders/pages/OrderDetailPage';
import { OrderFormPage } from './modules/orders/pages/OrderFormPage';
import { ProductionOrdersListPage } from './modules/production/pages/ProductionOrdersListPage';
import { ProductionOrderDetailPage } from './modules/production/pages/ProductionOrderDetailPage';

// Protected Route Wrapper
const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const { user, organization, loading } = useApp();

    if (loading) {
        return <div className="h-screen flex items-center justify-center bg-gray-50">Carregando OlieHub...</div>;
    }

    if (!user) {
        return <Navigate to="/login" replace />;
    }

    if (!organization) {
        return <Navigate to="/select-org" replace />;
    }

    return <Layout>{children}</Layout>;
};

// Route that requires User but NO Organization selected yet
const OrgSelectionRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const { user, loading } = useApp();
    
    if (loading) return <div>...</div>;
    if (!user) return <Navigate to="/login" replace />;
    
    return <>{children}</>;
};

function AppRoutes() {
    return (
        <Routes>
            <Route path="/login" element={<LoginPage />} />
            
            <Route path="/select-org" element={
                <OrgSelectionRoute>
                    <OrganizationSelectPage />
                </OrgSelectionRoute>
            } />

            {/* Orders Module */}
            <Route path="/orders" element={
                <ProtectedRoute>
                    <OrdersListPage />
                </ProtectedRoute>
            } />
            <Route path="/orders/new" element={
                <ProtectedRoute>
                    <OrderFormPage />
                </ProtectedRoute>
            } />
             <Route path="/orders/:id" element={
                <ProtectedRoute>
                    <OrderDetailPage />
                </ProtectedRoute>
            } />

            {/* Production Module */}
            <Route path="/production" element={
                <ProtectedRoute>
                    <ProductionOrdersListPage />
                </ProtectedRoute>
            } />
            <Route path="/production/:id" element={
                <ProtectedRoute>
                    <ProductionOrderDetailPage />
                </ProtectedRoute>
            } />

            {/* Dashboard / Fallback */}
            <Route path="/" element={
                <ProtectedRoute>
                    <div className="text-center py-20">
                        <h2 className="text-2xl font-bold text-gray-700">Bem-vindo ao OlieHub</h2>
                        <p className="text-gray-500 mt-2">Selecione um módulo no menu lateral para começar.</p>
                        <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-4xl mx-auto text-left px-4">
                            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 cursor-pointer hover:shadow-md transition-shadow" onClick={() => window.location.hash = '#/orders'}>
                                <h3 className="font-bold text-blue-600 mb-2">Pedidos</h3>
                                <p className="text-sm text-gray-600">Gerencie orçamentos e pedidos confirmados.</p>
                            </div>
                            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 cursor-pointer hover:shadow-md transition-shadow" onClick={() => window.location.hash = '#/production'}>
                                <h3 className="font-bold text-blue-600 mb-2">Produção</h3>
                                <p className="text-sm text-gray-600">Controle de OPs e chão de fábrica.</p>
                            </div>
                            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 opacity-50">
                                <h3 className="font-bold text-gray-800 mb-2">Estoque</h3>
                                <p className="text-sm text-gray-600">Em breve: Controle de insumos e materiais.</p>
                            </div>
                        </div>
                    </div>
                </ProtectedRoute>
            } />

            {/* Catch all */}
            <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
    );
}

export default function App() {
    return (
        <AppProvider>
            <HashRouter>
                <AppRoutes />
            </HashRouter>
        </AppProvider>
    );
}